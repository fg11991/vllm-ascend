"""CPU-only observation; forwards every scheduler operation unchanged."""
import json
import os
import time
from pathlib import Path


def install():
    from startup_audit import install as startup_install
    from vllm.v1.core.kv_cache_manager import KVCacheManager
    from vllm.v1.core.single_type_kv_cache_manager import SlidingWindowManager

    startup_install()
    root = Path(__file__).parent
    tag = os.environ['DSPARK_FOLLOWUP_TAG']
    path = root / f'{tag}.scheduler.jsonl'

    def record(event, **data):
        with path.open('a') as f:
            f.write(json.dumps(dict(event=event, time=time.time(), pid=os.getpid(), **data)) + '\n')

    lookup = KVCacheManager.get_computed_blocks

    def computed(self, request):
        result = lookup(self, request)
        record('lookup', request_id=request.request_id, prompt_tokens=request.num_tokens,
               enabled=self.enable_caching, hit_tokens=result[1], shared_boundary=result[2],
               groups=[[b.block_id if not b.is_null else None for b in g] for g in result[0].blocks])
        return result

    KVCacheManager.get_computed_blocks = computed
    remove = SlidingWindowManager.remove_skipped_blocks

    def removed(self, request_id, *args, **kwargs):
        before = [b.block_id if not b.is_null else None for b in self.req_to_blocks[request_id]]
        result = remove(self, request_id, *args, **kwargs)
        after = [b.block_id if not b.is_null else None for b in self.req_to_blocks[request_id]]
        freed = [x for x, y in zip(before, after) if x is not None and y is None]
        if freed:
            record('window_reclaim', request_id=request_id, processed_tokens=args[0] if args else kwargs,
                   retention=self.sliding_window, block_size=self.block_size, freed=freed,
                   remaining=after)
        return result

    SlidingWindowManager.remove_skipped_blocks = removed
