import collections
import json
import re
from pathlib import Path

root = Path(__file__).parent


def metrics(path):
    values = collections.defaultdict(float)
    for line in path.read_text().splitlines():
        if line.startswith('#'):
            continue
        match = re.match(r'(vllm:[^ {]+)(?:\{.*\})? ([^ ]+)', line)
        if match and any(k in match[1] for k in ['prefix_cache', 'spec_decode', 'num_preemptions']):
            if not match[1].endswith('_created'):
                values[match[1]] += float(match[2])
    return values


def compare(a, b):
    pos = next((i for i, (x,y) in enumerate(zip(a,b)) if x != y), min(len(a),len(b)))
    return dict(identical=a == b, common_output_prefix_tokens=pos, lengths=[len(a),len(b)])


out = {}
for tag in ['off', 'on']:
    files = sorted(root.glob(f'{tag}.*.result.json'))
    rows = [json.loads(p.read_text()) for p in files]
    if not rows:
        continue
    events = [json.loads(x) for x in (root / f'{tag}.scheduler.jsonl').read_text().splitlines()]
    lookup = [e for e in events if e['event'] == 'lookup']
    reclaim = [e for e in events if e['event'] == 'window_reclaim']
    before = metrics(root / f'{tag}.before.metrics.txt')
    phases = {}
    previous = before
    for phase in ['after_single_r0', 'after_single_r1', 'after_single_r2', 'after_concurrent']:
        path = root / f'{tag}.{phase}.metrics.txt'
        if path.exists():
            current = metrics(path)
            delta = {k: v-previous.get(k,0) for k,v in current.items()}
            steps = delta.get('vllm:spec_decode_num_drafts_total', 0)
            accepted = delta.get('vllm:spec_decode_num_accepted_tokens_total',0)
            phases[phase] = dict(delta=delta, mean_acceptance_length=1+accepted/steps if steps else None)
            previous = current
    singles = sorted([r for r in rows if r['label'].startswith('single')],key=lambda r:r['label'])
    out[tag] = dict(requests=[{k:v for k,v in r.items() if k not in ['output_ids','chunks','payload_sha256']} for r in rows],
                    lookups=lookup, reclaimed_blocks=sum(len(e['freed']) for e in reclaim),
                    reclaim_events=len(reclaim), retention_windows=sorted(set(e['retention'] for e in reclaim)),
                    phases=phases, single_comparisons=[compare(singles[0]['output_ids'],s['output_ids']) for s in singles[1:]])
if all(t in out for t in ['off','on']):
    comparisons=[]
    for p in root.glob('off.*.result.json'):
        q=root/p.name.replace('off.','on.',1)
        if q.exists():
            a,b=json.loads(p.read_text()),json.loads(q.read_text())
            comparisons.append(dict(label=a['label'],**compare(a['output_ids'],b['output_ids'])))
    out['cross_apc_comparisons']=comparisons
(root/'results_summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps(out,ensure_ascii=False,indent=2))
