"""Bounded CPU scheduler observation; never changes cache policy or GPU inputs."""
import json
import math
import os
import time
from pathlib import Path


def install():
    from startup_audit import install as startup_install
    from vllm.v1.core.kv_cache_manager import KVCacheManager
    from vllm.v1.core.single_type_kv_cache_manager import SlidingWindowManager
    from vllm.v1.core.block_pool import BlockPool
    if getattr(KVCacheManager, '_apc_drop_audit', False):
        return
    KVCacheManager._apc_drop_audit = True
    startup_install()
    root = Path(__file__).parent
    tag = os.environ['DSPARK_FOLLOWUP_TAG']
    path = root / 'evidence' / f'{tag}.scheduler.jsonl'
    reclaimed = {}

    def record(event, **data):
        with path.open('a') as f:
            f.write(json.dumps(dict(event=event, time=time.time(), pid=os.getpid(), **data)) + '\n')

    initialize = KVCacheManager.__init__
    def initialized(self, *args, **kwargs):
        initialize(self, *args, **kwargs)
        c = self.coordinator
        record('coordinator', cls=type(c).__name__, caching=self.enable_caching,
               skips_eagle_block_drop=getattr(c, 'skips_eagle_block_drop', None),
               eagle_group_ids=sorted(getattr(c, 'eagle_group_ids', [])),
               managers=[dict(gid=i, cls=type(m).__name__, block_size=m.block_size,
                              use_eagle=getattr(m,'use_eagle',None), retention=getattr(m,'sliding_window',None))
                         for i,m in enumerate(c.single_type_managers)])
    KVCacheManager.__init__ = initialized

    lookup = KVCacheManager.get_computed_blocks
    def computed(self, request):
        result = lookup(self, request)
        groups = [[b.block_id if not b.is_null else None for b in g] for g in result[0].blocks]
        checks=[]
        if result[1]:
            for i,m in enumerate(self.coordinator.single_type_managers):
                if isinstance(m, SlidingWindowManager):
                    need=min(len(groups[i]), math.ceil((m.sliding_window-1)/m.block_size))
                    checks.append(dict(gid=i, needed=need, tail=groups[i][-need:] if need else [],
                                       valid=bool(need) and all(b is not None for b in groups[i][-need:])))
        record('lookup', request_id=request.request_id, prompt_tokens=request.num_prompt_tokens,
               enabled=self.enable_caching, hit_tokens=result[1], shared_boundary=result[2],
               groups=groups, window_checks=checks)
        assert all(c['valid'] for c in checks), checks
        return result
    KVCacheManager.get_computed_blocks = computed

    remove = SlidingWindowManager.remove_skipped_blocks
    def removed(self, request_id, *args, **kwargs):
        before=list(self.req_to_blocks[request_id])
        refs={b.block_id:b.ref_cnt for b in before if not b.is_null}
        result=remove(self,request_id,*args,**kwargs)
        after=self.req_to_blocks[request_id]
        freed=[(i,b) for i,(b,a) in enumerate(zip(before,after)) if not b.is_null and a.is_null]
        if freed:
            processed=args[0] if args else kwargs['processed_computed_tokens']
            boundary=max(0,processed-self.sliding_window+1-self.extra_retained_tokens)
            rows=[dict(column=i, block_id=b.block_id, before_refs=refs[b.block_id], after_refs=b.ref_cnt,
                       block_end=(i+1)*self.block_size, before_boundary=(i+1)*self.block_size<=boundary) for i,b in freed]
            record('window_reclaim',request_id=request_id,gid=self.kv_cache_group_id,
                   processed_tokens=processed,retention=self.sliding_window,block_size=self.block_size,
                   boundary=boundary,freed=rows)
            assert all(r['before_boundary'] and r['after_refs']==r['before_refs']-1 for r in rows),rows
            reclaimed.setdefault(id(self.block_pool),set()).update(b.block_id for _,b in freed)
        return result
    SlidingWindowManager.remove_skipped_blocks = removed

    alloc = BlockPool.get_new_blocks
    def allocated(self,*args,**kwargs):
        result=alloc(self,*args,**kwargs)
        ids=reclaimed.get(id(self),set())
        reused=[dict(block_id=b.block_id,refs=b.ref_cnt) for b in result if b.block_id in ids]
        if reused:
            record('reclaimed_block_reused',blocks=reused)
            ids.difference_update(b['block_id'] for b in reused)
        return result
    BlockPool.get_new_blocks = allocated

    touch=BlockPool.touch
    def touched(self,blocks):
        rows=[dict(block_id=b.block_id,before_refs=b.ref_cnt) for b in blocks if not b.is_null]
        result=touch(self,blocks)
        if rows:
            record('cache_touch',blocks=rows)
        return result
    BlockPool.touch=touched
