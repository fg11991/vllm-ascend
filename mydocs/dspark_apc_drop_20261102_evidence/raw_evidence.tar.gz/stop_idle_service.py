import json,signal,sys,time
from pathlib import Path
import psutil,requests
root=Path(__file__).parent
tag=sys.argv[1]
summary=json.loads((root/'evidence'/f'{tag}.summary.json').read_text())
assert len(summary['rows'])==21 and all(r['ok'] for r in summary['rows'])
r=requests.get('http://127.0.0.1:8874/metrics',timeout=10);r.raise_for_status()
rows=[l for l in r.text.splitlines() if l.startswith(('vllm:num_requests_running{','vllm:num_requests_waiting{'))]
assert len(rows)==2 and all(float(l.rsplit(' ',1)[1])==0 for l in rows),rows
matches=[]
for p in psutil.process_iter(['cmdline']):
 if str(root/'run_vllm.py') in (p.info['cmdline'] or []):matches.append(p)
assert len(matches)==1, matches
p=matches[0]
assert p.environ()['DSPARK_FOLLOWUP_TAG']==tag
procs=[p]+p.children(recursive=True)
data=[dict(pid=q.pid,created=q.create_time(),cmd=q.cmdline()) for q in procs]
(root/'evidence'/f'{tag}.stopped_processes.json').write_text(json.dumps(data,indent=2))
p.send_signal(signal.SIGINT)
_,alive=psutil.wait_procs(procs,timeout=45)
alive=[q for q in alive if q.status()!=psutil.STATUS_ZOMBIE]
print(json.dumps(dict(event='service_stop',tag=tag,alive=[q.pid for q in alive])),flush=True)
assert not alive, 'inspect remaining verified processes before next start'
