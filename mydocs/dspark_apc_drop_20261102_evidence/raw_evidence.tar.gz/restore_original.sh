#!/usr/bin/env bash
set -euo pipefail
export ASCEND_RT_VISIBLE_DEVICES=4,5,6,7
export VLLM_USE_V2_MODEL_RUNNER=1
export VLLM_ASCEND_ENABLE_DSPARK_FIA_SINK=2
export VLLM_ASCEND_KV_GROUP_MIN_SIZE=8
export VLLM_CACHE_ROOT=/workspace/dspark_ctxwin_validation/apc_20261031_round01/cache-on
export TRITON_CACHE_DIR=/workspace/dspark_ctxwin_validation/apc_20261031_round01/cache-on/triton
export TORCHINDUCTOR_CACHE_DIR=/workspace/dspark_ctxwin_validation/apc_20261031_round01/cache-on/inductor
export TORCH_EXTENSIONS_DIR=/workspace/dspark_ctxwin_validation/apc_20261031_round01/cache-on/torch_extensions
export ASCEND_CACHE_PATH=/workspace/dspark_ctxwin_validation/apc_20261031_round01/cache-on/ascend
export TORCHAIR_CACHE_HOME=/workspace/dspark_ctxwin_validation/apc_20261031_round01/cache-on/torchair
export OMP_NUM_THREADS=1
export PYTHONPATH=/opt/w00958190/flash-attention-npu:/usr/local/Ascend/cann-9.2.0/python/site-packages:/usr/local/Ascend/cann-9.2.0/opp/built-in/op_impl/ai_core/tbe:/usr/local/Ascend/ascend-toolkit/latest/python/site-packages:/usr/local/Ascend/ascend-toolkit/latest/opp/built-in/op_impl/ai_core/tbe:
export LD_LIBRARY_PATH=/opt/w00958190/vllm-ascend/vllm_ascend/lib64:/usr/local/Ascend/cann-9.2.0/lib64:/usr/local/Ascend/cann-9.2.0/lib64/plugin/opskernel:/usr/local/Ascend/cann-9.2.0/lib64/plugin/nnengine:/usr/local/Ascend/cann-9.2.0/opp/built-in/op_impl/ai_core/tbe/op_tiling:/usr/local/Ascend/driver/lib64:/usr/local/Ascend/driver/lib64/common:/usr/local/Ascend/driver/lib64/driver:/usr/local/Ascend/nnal/atb/latest/atb/cxx_abi_1/lib:/usr/local/Ascend/nnal/atb/latest/atb/cxx_abi_1/examples:/usr/local/Ascend/nnal/atb/latest/atb/cxx_abi_1/tests/atbopstest:/usr/local/Ascend/ascend-toolkit/latest/tools/aml/lib64:/usr/local/Ascend/ascend-toolkit/latest/tools/aml/lib64/plugin:/usr/local/Ascend/ascend-toolkit/latest/lib64:/usr/local/Ascend/ascend-toolkit/latest/lib64/plugin/opskernel:/usr/local/Ascend/ascend-toolkit/latest/lib64/plugin/nnengine:/usr/local/Ascend/ascend-toolkit/latest/opp/built-in/op_impl/ai_core/tbe/op_tiling::/usr/local/lib
export DSPARK_FOLLOWUP_TAG=on
cd /workspace/dspark_ctxwin_validation/apc_20261031_round01/cache-on/runtime
/workspace/dspark_ctxwin_validation/apc_20261031_round01/runtime/bin/python /workspace/dspark_ctxwin_validation/apc_20261031_round01/runtime/bin/vllm serve /opt/models/Qwen3.8-27B --served-model-name dspark-apc-experiment --host 127.0.0.1 --port 8873 --dtype bfloat16 --seed 42 --max-model-len 32768 --max-num-seqs 8 --max-num-batched-tokens 8192 --tensor-parallel-size 4 --gpu-memory-utilization 0.9 --trust-remote-code --enable-prefix-caching --async-scheduling --tool-call-parser qwen3_coder --enable-auto-tool-choice --reasoning-parser qwen3 --default-chat-template-kwargs '{"enable_thinking":false}' --speculative-config '{"num_speculative_tokens":7,"method":"dspark","model":"/workspace/dspark_ctxwin_validation/apc_20261031_round01/models/trained-window-2048"}' --compilation-config '{"cudagraph_mode":"FULL","cudagraph_capture_sizes":[8,16,24,32,40,48,56,64]}' 2>&1 | tee /opt/w00958190/log/dspark_apc_drop_20261102_round01_restored_serve.log
