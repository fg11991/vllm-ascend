import hashlib,json,time
from pathlib import Path
import psutil,requests
root=Path(__file__).parent;e=root/'evidence'
assert len(json.loads((e/'D.summary.json').read_text())['rows'])==21
h=requests.get('http://127.0.0.1:8874/health',timeout=10);h.raise_for_status()
m=requests.get('http://127.0.0.1:8874/metrics',timeout=10);m.raise_for_status();(e/'final_idle.metrics.txt').write_text(m.text)
rows=[l for l in m.text.splitlines() if l.startswith(('vllm:num_requests_running{','vllm:num_requests_waiting{'))]
assert len(rows)==2 and all(float(l.rsplit(' ',1)[1])==0 for l in rows),rows
manifest=json.loads((e/'runtime_manifest.json').read_text())
for file,digest in manifest['source_sha256'].items():assert hashlib.sha256((root/'source/vllm_ascend'/file).read_bytes()).hexdigest()==digest
matches=[p for p in psutil.process_iter(['cmdline']) if str(root/'run_vllm.py') in (p.info['cmdline'] or [])];assert len(matches)==1
p=matches[0];env=p.environ();assert env['DSPARK_FOLLOWUP_TAG']=='D' and env['ASCEND_RT_VISIBLE_DEVICES']=='4,5,6,7'
result=dict(remote_time=time.time(),health=h.status_code,endpoint='http://127.0.0.1:8874',model=requests.get('http://127.0.0.1:8874/v1/models',timeout=10).json(),idle=rows,retained=True,pid=p.pid,cmd=p.cmdline(),devices=env['ASCEND_RT_VISIBLE_DEVICES'],children=[dict(pid=q.pid,cmd=q.cmdline()) for q in p.children(recursive=True)],critical_source_hashes_unchanged=True)
(e/'final_service.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(health=h.status_code,pid=p.pid,idle=True,retained=True,source_unchanged=True)))
