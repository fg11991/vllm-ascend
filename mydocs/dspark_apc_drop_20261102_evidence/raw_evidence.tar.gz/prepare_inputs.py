import hashlib
import json
from pathlib import Path
from transformers import AutoTokenizer

root=Path(__file__).parent
old=json.loads((root/'inputs.json').read_text())
tok=AutoTokenizer.from_pretrained('/opt/models/Qwen3.8-27B',trust_remote_code=True,local_files_only=True)

def chat(text):
    ids=tok.apply_chat_template([{'role':'user','content':text}],tokenize=True,add_generation_prompt=True,enable_thinking=False)
    if hasattr(ids,'keys'): ids=ids['input_ids']
    if ids and isinstance(ids[0],list):ids=ids[0]
    return ids

paragraph='Observatory staff record temperature, rainfall, cloud cover, and wind speed. They inspect each sensor weekly and keep the original measurements.\n'
filler=tok.decode(tok.encode('\n'.join(f'Record {i:04d}: {paragraph}' for i in range(500)))[:9950])
ledger='This is a lookup task. The authoritative keys are: ALPHA = ORBIT731; BETA = MAPLE482; GAMMA = RIVER905; DELTA = CLOUD216.\n'
qa=[]
for key,value in [('ALPHA','ORBIT731'),('BETA','MAPLE482'),('GAMMA','RIVER905'),('DELTA','CLOUD216')]:
    qa.append(dict(tokens=chat(ledger+filler+f'\nWhat is the authoritative value for {key}? Return only that value, with no explanation.'),gold=value))
long=chat('Staggered scheduling experiment: use these field notes.\n'+filler+'\nWrite a detailed numbered checklist of 40 distinct data-quality procedures, with at least 15 words for each item. Continue through all 40 items. Do not add a preamble.')
boundaries=[]
for size in (9855,9856,9857):
    # Preserve the full question/template suffix while changing only filler length.
    base=chat(f'Boundary suite {size}. Read these field notes.\n'+filler+'\nSummarize the quality-control procedures in three concise bullet points.')
    assert len(base)>size
    remove=len(base)-size
    ids=base[:200]+base[200+remove:]
    assert len(ids)==size
    boundaries.append(dict(tokens=ids,length=size))
fixture=dict(single=old[0],qa=qa,stagger=dict(tokens=long),boundaries=boundaries)
(root/'fixtures.json').write_text(json.dumps(fixture))
print(json.dumps(dict(single=len(old[0]['tokens']),qa=[len(x['tokens']) for x in qa],stagger=len(long),boundaries=[len(x['tokens']) for x in boundaries],sha256=hashlib.sha256((root/'fixtures.json').read_bytes()).hexdigest()),indent=2))
