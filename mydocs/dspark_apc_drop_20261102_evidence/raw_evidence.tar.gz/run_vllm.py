from vllm.entrypoints.cli.main import main
from apc_audit import install
install()
if __name__ == '__main__':
    main()
