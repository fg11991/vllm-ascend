"""One-time scheduler cache-layout logging, with no per-step instrumentation."""
import json,os,sys,importlib.util
from pathlib import Path

def install():
 from vllm.v1.core.kv_cache_manager import KVCacheManager
 from vllm.v1.kv_cache_interface import UniformTypeKVCacheSpecs
 if getattr(KVCacheManager,'_followup_startup_audit',False):return
 KVCacheManager._followup_startup_audit=True
 original=KVCacheManager.__init__
 def initialized(self,*a,**kw):
  original(self,*a,**kw)
  cfg=self.kv_cache_config;groups=[]
  for g in cfg.kv_cache_groups:
   s=g.kv_cache_spec
   inner=list(s.kv_cache_specs.values()) if isinstance(s,UniformTypeKVCacheSpecs) else [s]*len(g.layer_names)
   groups.append(dict(spec=type(s).__name__,layers=list(g.layer_names),block_size=s.block_size,pages=[x.page_size_bytes for x in inner],retention=[getattr(x,'sliding_window',None) for x in inner]))
  row=dict(pid=os.getpid(),num_blocks=cfg.num_blocks,groups=groups,python=sys.executable,ascend=importlib.util.find_spec('vllm_ascend').origin,vllm=importlib.util.find_spec('vllm').origin)
  print('FOLLOWUP_STARTUP_CACHE_AUDIT '+json.dumps(row),flush=True)
 KVCacheManager.__init__=initialized
 # Audits run only during initialization, never in a decode step.
 from vllm_ascend.worker.v2.model_runner import NPUModelRunner
 def audit_worker(phase):
  import triton
  expected=os.environ['VLLM_CACHE_ROOT']
  cache_values={k:os.environ.get(k) for k in ['VLLM_CACHE_ROOT','TRITON_CACHE_DIR','TORCHINDUCTOR_CACHE_DIR','TORCH_EXTENSIONS_DIR','ASCEND_CACHE_PATH','TORCHAIR_CACHE_HOME']}
  cache_values['actual_triton_cache_dir']=str(triton.knobs.cache.dir)
  cache_values['static_kernel_working_directory']=str(Path.cwd())
  for key,value in cache_values.items():
   assert value and Path(value).is_relative_to(Path(expected)),(key,value,expected)
  loaded_probes=[name for name in sys.modules if 'kv_probe' in name or name=='diagnostics']
  if not os.environ.get('DSPARK_FOLLOWUP_DIAGNOSTICS'):
   assert not loaded_probes,loaded_probes
  print('FOLLOWUP_WORKER_CACHE_AUDIT '+json.dumps(dict(pid=os.getpid(),phase=phase,paths=cache_values,loaded_probes=loaded_probes)),flush=True)
 capture=NPUModelRunner.capture_model
 def captured(self,*a,**kw):
  result=capture(self,*a,**kw)
  audit_worker('capture_model')
  return result
 NPUModelRunner.capture_model=captured
 kv_init=NPUModelRunner.initialize_kv_cache
 def kv_initialized(self,*a,**kw):
  result=kv_init(self,*a,**kw)
  audit_worker('initialize_kv_cache')
  return result
 NPUModelRunner.initialize_kv_cache=kv_initialized
