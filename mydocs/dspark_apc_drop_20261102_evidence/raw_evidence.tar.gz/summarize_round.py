import collections
import json
import re
from pathlib import Path

root=Path(__file__).parent
e=root/'evidence'

def metric(path):
    out=collections.defaultdict(float)
    if not path.exists():return {}
    for line in path.read_text().splitlines():
        m=re.match(r'(vllm:[^ {]+)(?:\{.*\})? ([^ ]+)',line)
        if m and not m[1].endswith('_created') and any(s in m[1] for s in ['prefix_cache','spec_decode','num_preemptions']):out[m[1]]+=float(m[2])
    return dict(out)

def comparison(a,b):
    x,y=a['output_ids'],b['output_ids']
    n=next((i for i,(p,q) in enumerate(zip(x,y)) if p!=q),min(len(x),len(y)))
    result=dict(equal=x==y,lengths=[len(x),len(y)],common_prefix=n)
    if x!=y:
        result['next_ids']=[x[n:n+8],y[n:n+8]]
        for name,row in [('a',a),('b',b)]:
            tops=[p for chunk in row.get('logprobs',[]) for p in (chunk.get('top_logprobs') or [])]
            if n<len(tops):result[name+'_first_difference_top5']=tops[n]
    return result

out={};allrows={}
for tag in 'ABCD':
    rows={p.name[len(tag)+1:-len('.result.json')]:json.loads(p.read_text()) for p in e.glob(f'{tag}.*.result.json')}
    if not rows:continue
    allrows[tag]=rows
    p=e/f'{tag}.scheduler.jsonl'
    events=[json.loads(l) for l in p.read_text().splitlines()] if p.exists() else []
    lookup=[x for x in events if x['event']=='lookup']
    reclaim=[x for x in events if x['event']=='window_reclaim']
    shared=[dict(request_id=x['request_id'],**b) for x in reclaim for b in x['freed'] if b['after_refs']>0]
    before=metric(e/f'{tag}.before.metrics.txt')
    phases={};prior=before
    for phase in ['after_single_r0','after_single_r1','after_single_r2','after_cold4','after_warm4','after_stagger','after_boundaries']:
        current=metric(e/f'{tag}.{phase}.metrics.txt')
        if not current:continue
        delta={k:v-prior.get(k,0) for k,v in current.items()}
        drafts=delta.get('vllm:spec_decode_num_drafts_total',0)
        phases[phase]=dict(delta=delta,acceptance_length=1+delta.get('vllm:spec_decode_num_accepted_tokens_total',0)/drafts if drafts else None)
        prior=current
    out[tag]=dict(request_count=len(rows),ok=all(r['ok'] for r in rows.values()),
                  requests={label:{k:r.get(k) for k in ['prompt_tokens','usage','ok','finish_reason','gold','gold_exact','seconds','text']} for label,r in rows.items()},
                  lookup_event_hit_tokens=sum(x['hit_tokens'] for x in lookup),
                  request_hit_tokens=sum({x['request_id']:x['hit_tokens'] for x in lookup}.values()),lookups=lookup,
                  reclaimed_block_occurrences=sum(len(x['freed']) for x in reclaim),
                  shared_reclaim_occurrences=len(shared),shared_reclaim_examples=shared[:20],
                  reused_reclaimed_blocks=sum(len(x['blocks']) for x in events if x['event']=='reclaimed_block_reused'),
                  coordinator=[x for x in events if x['event']=='coordinator'],phases=phases,
                  single_repeats={k:comparison(rows['single_r0'],rows[k]) for k in ['single_r1','single_r2'] if k in rows},
                  qa_cold_warm={str(i):comparison(rows[f'cold4_{i}'],rows[f'warm4_{i}']) for i in range(4) if f'warm4_{i}' in rows},
                  stagger_repeats={str(i):comparison(rows['stagger_0'],rows[f'stagger_{i}']) for i in range(1,4) if f'stagger_{i}' in rows},
                  boundary_repeats={str(n):comparison(rows[f'boundary_{n}_r0'],rows[f'boundary_{n}_r1']) for n in [9855,9856,9857] if f'boundary_{n}_r1' in rows})
for a,b in [('A','B'),('C','D'),('A','C'),('B','D')]:
    if a in allrows and b in allrows:
        out[a+'_'+b]={k:comparison(allrows[a][k],allrows[b][k]) for k in sorted(allrows[a].keys()&allrows[b].keys())}
(root/'results_summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({k:({'count':v['request_count'],'ok':v['ok'],'hits':v['request_hit_tokens'],'reclaimed':v['reclaimed_block_occurrences'],'shared_reclaim':v['shared_reclaim_occurrences'],'reused':v['reused_reclaimed_blocks'],'gold':[r['gold_exact'] for r in v['requests'].values() if r['gold'] is not None],'single':v['single_repeats']} if len(k)==1 else {'equal':sum(r['equal'] for r in v.values()),'total':len(v),'differences':{label:r for label,r in v.items() if not r['equal']}}) for k,v in out.items()},ensure_ascii=False,indent=2))
