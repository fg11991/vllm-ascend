import concurrent.futures
import hashlib
import json
import sys
import time
from pathlib import Path

import requests

ROOT = Path(__file__).parent
BASE = 'http://127.0.0.1:8873'
TAG = sys.argv[1]


def metrics(label):
    r = requests.get(BASE + '/metrics', timeout=10)
    r.raise_for_status()
    (ROOT / f'{TAG}.{label}.metrics.txt').write_text(r.text)


def run(item, label):
    payload = dict(model='dspark-apc-experiment', request_id=f'{TAG}_{label}',
                   prompt=item['tokens'], max_tokens=128, temperature=0, top_p=1,
                   seed=42, return_token_ids=True, stream=True,
                   stream_options={'include_usage': True})
    (ROOT / f'{TAG}.{label}.request.json').write_text(json.dumps(payload))
    start = time.monotonic()
    row = dict(label=label, prompt_tokens=len(item['tokens']), payload_sha256=hashlib.sha256(json.dumps(payload).encode()).hexdigest())
    ids, text, chunks = [], '', []
    try:
        with requests.post(BASE + '/v1/completions', json=payload, stream=True, timeout=(10, 600)) as r:
            row['http_status'] = r.status_code
            if not r.ok:
                row['error_body'] = r.text
            r.raise_for_status()
            for line in r.iter_lines(decode_unicode=True):
                if not line.startswith('data:'):
                    continue
                line = line[5:].strip()
                if line == '[DONE]':
                    break
                obj = json.loads(line)
                if obj.get('error'):
                    raise RuntimeError(obj)
                row['server_request_id'] = obj.get('id')
                if obj.get('usage'):
                    row['usage'] = obj['usage']
                for choice in obj.get('choices', []):
                    new = choice.get('token_ids') or []
                    ids.extend(new)
                    text += choice.get('text', '')
                    if new:
                        chunks.append([time.monotonic() - start, len(new)])
                    if choice.get('finish_reason'):
                        row['finish_reason'] = choice['finish_reason']
        assert row.get('usage') and len(ids) == row['usage']['completion_tokens'] and ids, row
        row['ok'] = True
    except Exception as e:
        row.update(ok=False, error=repr(e))
    row.update(output_ids=ids, text=text, chunks=chunks, seconds=time.monotonic()-start)
    (ROOT / f'{TAG}.{label}.result.json').write_text(json.dumps(row, ensure_ascii=False, indent=2))
    print(json.dumps({k:v for k,v in row.items() if k not in ['output_ids', 'chunks', 'text']}, ensure_ascii=False), flush=True)
    return row


fixture = ROOT / 'inputs.json'
if not fixture.exists():
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained('/opt/models/Qwen3.8-27B', trust_remote_code=True)
    paragraph = ('The observatory records temperature, rainfall, wind speed, and cloud cover. '
                 'Technicians inspect the sensors weekly, compare independent measurements, '
                 'and preserve the original records before correcting any errors. '
                 'The project uses these observations to study seasonal weather patterns.\n')
    archive = '\n'.join(f'Record {i:04d}: {paragraph}' for i in range(220))
    archive = tokenizer.decode(tokenizer.encode(archive)[:10000])
    common = 'Read the following field notes.\n' + archive
    questions = ['Summarize the observation and quality control process in five concise bullet points.',
                 'Explain why the team keeps original records in three sentences.',
                 'List four measurements made by the observatory.',
                 'Describe the weekly sensor inspection in three sentences.',
                 'Explain how this project can reveal seasonal patterns in three sentences.']
    items = []
    for i, question in enumerate(questions):
        tokens = tokenizer.apply_chat_template([{'role':'user','content':common+'\n\n'+question}], tokenize=True,
                                               add_generation_prompt=True, enable_thinking=False)
        if hasattr(tokens, 'keys'):
            tokens = tokens['input_ids']
        if tokens and isinstance(tokens[0], list):
            tokens = tokens[0]
        items.append(dict(id=i, tokens=tokens))
    fixture.write_text(json.dumps(items))
items = json.loads(fixture.read_text())
metrics('before')
rows = []
for repeat in range(3):
    row = run(items[0], f'single_r{repeat}')
    rows.append(row)
    metrics(f'after_single_r{repeat}')
    if not row['ok']:
        sys.exit(2)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    rows.extend(pool.map(lambda item: run(item, f'concurrent_{item["id"]}'), items[1:]))
metrics('after_concurrent')
(ROOT / f'{TAG}.summary.json').write_text(json.dumps(dict(rows=rows, single_identical=[rows[0]['output_ids']==r['output_ids'] for r in rows[1:3]]), ensure_ascii=False, indent=2))
assert all(r['ok'] for r in rows)
