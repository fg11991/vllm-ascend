import json
from pathlib import Path
root=Path(__file__).parent;e=root/'evidence'
s=json.loads((root/'results_summary.json').read_text());out={'groups':{},'comparisons':{},'sampling_verified':True,'requests':0}
for tag in 'ABCD':
 if tag not in s:continue
 d=s[tag];rows=[json.loads(p.read_text()) for p in e.glob(f'{tag}.*.result.json')]
 for p in e.glob(f'{tag}.*.request.json'):
  q=json.loads(p.read_text());assert(q['temperature'],q['top_p'],q['seed'])==(0,1,42)
  label=p.name[2:-len('.request.json')];other=e/f'A.{label}.request.json'
  if other.exists():assert q['prompt']==json.loads(other.read_text())['prompt']
 phases=d['phases'];drafts=sum(p['delta'].get('vllm:spec_decode_num_drafts_total',0) for p in phases.values());accepted=sum(p['delta'].get('vllm:spec_decode_num_accepted_tokens_total',0) for p in phases.values())
 hits=sum(p['delta'].get('vllm:prefix_cache_hits_total',0) for p in phases.values())
 unique_lookups={x['request_id']:x for x in d['lookups']}
 assert hits==sum(x['hit_tokens'] for x in unique_lookups.values()),(tag,hits,unique_lookups)
 events=[json.loads(l) for l in (e/f'{tag}.scheduler.jsonl').read_text().splitlines()]
 checks=[c for ev in events if ev['event']=='lookup' for c in ev['window_checks']]
 frees=[b for ev in events if ev['event']=='window_reclaim' for b in ev['freed']]
 assert all(c['valid'] for c in checks)
 assert all(b['before_boundary'] and b['after_refs']==b['before_refs']-1 for b in frees)
 out['groups'][tag]={'requests':len(rows),'all_ok':all(r['ok'] for r in rows),'output_tokens':sum(len(r['output_ids']) for r in rows),'gold_correct':sum(r.get('gold_exact',False) for r in rows),'gold_total':sum(r.get('gold') is not None for r in rows),'hits':hits,'raw_lookup_hit_tokens':d['lookup_event_hit_tokens'],'lookup_count':len(d['lookups']),'unique_lookup_requests':len(unique_lookups),'window_tail_checks':len(checks),'reclaims':len(frees),'shared_reclaims':d['shared_reclaim_occurrences'],'reallocated_reclaimed':d['reused_reclaimed_blocks'],'drafts':drafts,'accepted':accepted,'mean_acceptance_length':1+accepted/drafts,'preemptions':sum(p['delta'].get('vllm:num_preemptions_total',0) for p in phases.values()),'single_lengths':[len(json.loads((e/f'{tag}.single_r{i}.result.json').read_text())['output_ids']) for i in range(3)],'boundary_self_equal':all(c['equal'] for c in d['boundary_repeats'].values())}
 out['requests']+=len(rows)
for name in ['A_B','A_C','B_D','C_D']:
 if name not in s:continue
 c=s[name];diff=[]
 for label,v in c.items():
  if v['equal']:continue
  gaps=[]
  for side in ['a','b']:
   vals=sorted(v.get(side+'_first_difference_top5',{}).values(),reverse=True)
   gaps.append(vals[0]-vals[1] if len(vals)>1 else None)
  diff.append(dict(label=label,first_difference_zero_based=v['common_prefix'],lengths=v['lengths'],top1_top2_gaps=gaps))
 out['comparisons'][name]={'equal':sum(v['equal'] for v in c.values()),'total':len(c),'differences':diff}
(root/'final_analysis.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
