# 2026-11-02 DSpark context window、APC 与 KV 回收验证

状态：84个请求已完成，最终结果见 `REPORT.md`。本目录是独立实验产物，不属于源码提交。

## 复现条件

- 主机：`ssh 910b3`；容器：`wyd_va_030rc2_1028`；物理 NPU 4、5、6、7，TP4。
- Ascend 源码：`47cff9175f50f47b78c9bf479f8c22b72bf6964e`，分支 `030_dspark_ctxwin_tmp`。
- vLLM：`ced6857afa0ea7b2e3f0846a62e1394e90f15607`。
- 远端实验根目录：`/workspace/dspark_ctxwin_validation/apc_drop_20261102_round01`。
- target：`/opt/models/Qwen3.8-27B`。
- draft：`/workspace/dspark_ctxwin_validation/apc_20261031_round01/models/trained-window-2048`，复用已有窗口增训权重，不修改原模型配置。
- MRV2、BF16、async scheduling、FA4 sink=2、7 speculative tokens、窗口 2048/128、hybrid KV manager。
- max_model_len=32768，max_num_seqs=8，max_num_batched_tokens=8192，memory utilization=0.9。
- target 实际图模式 FULL_DECODE_ONLY，draft FULL；每组独立编译缓存。
- 所有请求：temperature=0、top_p=1、seed=42，保存 output token IDs 和 output logprobs=5；未启用会影响 APC 的 prompt logprobs。

## 对照矩阵

| 组 | APC | dspark_drop_outside_window_kv |
| --- | --- | --- |
| A | false | false |
| B | false | true |
| C | true | false |
| D | true | true |

每组 21 个请求：10035 token 的单请求冷/重复/重复；约 10028 token 的共享前缀取值题并发4、重复并发4；10014 token 的同前缀错峰并发4，各输出最多512 token；9855/9856/9857 token 三种块边界各重复两次。

错峰请求在第一个请求输出约96、192、288 token时启动，用于观察不同窗口位置下的共享引用。取值题答案位于2048窗口之外，验证 target 仍能使用长前缀信息。只有4个不同取值题，并非通用精度数据集。

## 运行方法

`serve.sh A|B|C|D` 在容器内前台运行并 tee 日志；`run_matrix.py TAG` 向8874发送固定 `fixtures.json` 请求。切换前 `stop_idle_service.py TAG` 会校验21个请求完成、服务空闲、进程命令及实验标签，保存进程树后只向该 API 进程发送 SIGINT。不得按进程名称批量终止。

`apc_audit.py` 只包装 CPU 缓存管理调用：记录联合命中、窗口尾部有效块、回收边界、引用计数与已回收块再分配。未改变模型输入、KV策略或联合命中逻辑。日志会影响调度时序，因此本轮不作性能结论。CPU 审计不能独立证明设备端所有 KV 内容和读写时序正确。

## 环境问题

首次 A 启动因 git archive 不含未跟踪的编译产物，导致自定义算子未启用，fallback 报 `aclnnAddRmsNormBias ... not in libopapi.so`。补齐与原健康服务相同的扩展及 vendor 目录软链接后，`enable_custom_op()` 预检通过，重新启动 A。没有升级依赖或修改生产算法。首次失败完整日志保留为 `logs/dspark_apc_drop_20261102_round01_A_startup_missing_binaries.log`，链接清单见 `evidence/compiled_runtime_links.json`。

B 组主动关停后有 `AsyncLLM output_handler failed / EngineDeadError`，出现在请求全部完成、空闲并发出退出信号之后；不计为推理失败，保留原始日志。

## 证据说明

- `evidence/*.request.json` / `*.result.json`：精确输入、输出 token、文本、logprobs、完成原因、时序。
- `evidence/*.metrics.txt`：各阶段 metrics 快照。
- `evidence/*.scheduler.jsonl`：联合命中、回收、引用计数与再分配事件。
- `evidence/runtime_manifest.json`：依赖版本、源码和模型配置哈希。
- `results_summary.json`：由 `summarize_round.py` 从原始数据派生，可重算。
- 服务器日志使用其自身时钟，落后本地时钟约5分钟；两小时截止按本地 UTC 04:24:13（台北12:24:13）执行。

不会将本轮小样本、HTTP成功、或已有CPU UT当作通用精度保证。未覆盖长时间压力、内存耗尽/抢占、PD、DCP/PCP、所有窗口长度或其他模型。
