#!/usr/bin/env bash
set -euo pipefail
root=/workspace/dspark_ctxwin_validation/apc_drop_20261102_round01
tag=${1:?A B C D}
case "$tag" in
 A) apc=--no-enable-prefix-caching; drop=false;;
 B) apc=--no-enable-prefix-caching; drop=true;;
 C) apc=--enable-prefix-caching; drop=false;;
 D) apc=--enable-prefix-caching; drop=true;;
 *) exit 2;;
esac
export ASCEND_RT_VISIBLE_DEVICES=4,5,6,7
export VLLM_USE_V2_MODEL_RUNNER=1
export VLLM_ASCEND_ENABLE_DSPARK_FIA_SINK=2
export VLLM_ASCEND_KV_GROUP_MIN_SIZE=8
export DSPARK_FOLLOWUP_TAG="$tag"
export VLLM_CACHE_ROOT="$root/cache-$tag"
export TRITON_CACHE_DIR="$VLLM_CACHE_ROOT/triton"
export TORCHINDUCTOR_CACHE_DIR="$VLLM_CACHE_ROOT/inductor"
export TORCH_EXTENSIONS_DIR="$VLLM_CACHE_ROOT/torch_extensions"
export ASCEND_CACHE_PATH="$VLLM_CACHE_ROOT/ascend"
export TORCHAIR_CACHE_HOME="$VLLM_CACHE_ROOT/torchair"
export OMP_NUM_THREADS=1
export PYTHONPATH="/opt/w00958190/flash-attention-npu:${PYTHONPATH:-}"
export LD_LIBRARY_PATH="$root/source/vllm_ascend/lib64:${LD_LIBRARY_PATH:-}"
mkdir -p "$TRITON_CACHE_DIR" "$TORCHINDUCTOR_CACHE_DIR" "$TORCH_EXTENSIONS_DIR" "$ASCEND_CACHE_PATH" "$TORCHAIR_CACHE_HOME" "$VLLM_CACHE_ROOT/runtime"
cd "$VLLM_CACHE_ROOT/runtime"
"$root/runtime/bin/python" "$root/run_vllm.py" serve /opt/models/Qwen3.8-27B \
 --served-model-name dspark-apc-experiment --host 127.0.0.1 --port 8874 \
 --dtype bfloat16 --seed 42 --max-model-len 32768 --max-num-seqs 8 --max-num-batched-tokens 8192 \
 --tensor-parallel-size 4 --gpu-memory-utilization 0.9 --trust-remote-code "$apc" --async-scheduling \
 --tool-call-parser qwen3_coder --enable-auto-tool-choice --reasoning-parser qwen3 \
 --default-chat-template-kwargs '{"enable_thinking":false}' \
 --speculative-config "{\"method\":\"dspark\",\"num_speculative_tokens\":7,\"model\":\"/workspace/dspark_ctxwin_validation/apc_20261031_round01/models/trained-window-2048\",\"dspark_drop_outside_window_kv\":$drop}" \
 --compilation-config '{"cudagraph_mode":"FULL","cudagraph_capture_sizes":[8,16,24,32,40,48,56,64]}' \
 2>&1 | tee "/opt/w00958190/log/dspark_apc_drop_20261102_round01_${tag}_serve.log"
