import concurrent.futures
import hashlib
import json
import sys
import threading
import time
from pathlib import Path
import requests

ROOT=Path(__file__).parent
TAG=sys.argv[1]
BASE='http://127.0.0.1:8874'
EVIDENCE=ROOT/'evidence'
FIXTURE=json.loads((ROOT/'fixtures.json').read_text())
progress={}
lock=threading.Lock()


def metrics(label):
    r=requests.get(BASE+'/metrics',timeout=10);r.raise_for_status()
    (EVIDENCE/f'{TAG}.{label}.metrics.txt').write_text(r.text)


def run(item,label,max_tokens=128):
    payload=dict(model='dspark-apc-experiment',request_id=f'{TAG}_{label}',prompt=item['tokens'],
                 max_tokens=max_tokens,temperature=0,top_p=1,seed=42,return_token_ids=True,
                 logprobs=5,stream=True,stream_options={'include_usage':True})
    path=EVIDENCE/f'{TAG}.{label}.result.json'
    assert not path.exists(),path
    (EVIDENCE/f'{TAG}.{label}.request.json').write_text(json.dumps(payload))
    row=dict(label=label,prompt_tokens=len(item['tokens']),max_tokens=max_tokens,gold=item.get('gold'),
             payload_sha256=hashlib.sha256(json.dumps(payload).encode()).hexdigest(),start_time=time.time())
    start=time.monotonic();ids=[];text='';logs=[];chunks=[]
    with lock:progress[label]=dict(tokens=0,done=False)
    try:
        with requests.post(BASE+'/v1/completions',json=payload,stream=True,timeout=(10,300)) as r:
            row['http_status']=r.status_code
            if not r.ok:row['error_body']=r.text
            r.raise_for_status()
            for line in r.iter_lines(decode_unicode=True):
                if not line.startswith('data:'):continue
                line=line[5:].strip()
                if line=='[DONE]':break
                obj=json.loads(line)
                if obj.get('error'):raise RuntimeError(obj['error'])
                row['server_request_id']=obj.get('id')
                if obj.get('usage'):row['usage']=obj['usage']
                for choice in obj.get('choices',[]):
                    new=choice.get('token_ids') or []
                    ids.extend(new);text+=choice.get('text','')
                    if choice.get('logprobs'):logs.append(choice['logprobs'])
                    if new:chunks.append([time.monotonic()-start,len(new)])
                    if choice.get('finish_reason'):row['finish_reason']=choice['finish_reason']
                with lock:progress[label]['tokens']=len(ids)
        assert row.get('usage') and len(ids)==row['usage']['completion_tokens'] and ids,row
        row['ok']=True
    except Exception as e:row.update(ok=False,error=repr(e))
    finally:
        with lock:progress[label]['done']=True
    row.update(output_ids=ids,text=text,logprobs=logs,chunks=chunks,seconds=time.monotonic()-start,end_time=time.time())
    if row['gold'] is not None:row['gold_exact']=text.strip()==row['gold']
    path.write_text(json.dumps(row,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in row.items() if k not in ('output_ids','text','logprobs','chunks')},ensure_ascii=False),flush=True)
    return row


def idle():
    r=requests.get(BASE+'/metrics',timeout=10);r.raise_for_status()
    rows=[l for l in r.text.splitlines() if l.startswith(('vllm:num_requests_running{','vllm:num_requests_waiting{'))]
    return len(rows)==2 and all(float(l.rsplit(' ',1)[1])==0 for l in rows)

assert idle(),'service is not idle'
assert not (EVIDENCE/f'{TAG}.before.metrics.txt').exists(),'refuse overwrite'
metrics('before');results=[]
for i in range(3):
    results.append(run(FIXTURE['single'],f'single_r{i}'))
    metrics(f'after_single_r{i}')
    assert results[-1]['ok']
for phase in ('cold4','warm4'):
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results.extend(pool.map(lambda pair:run(pair[1],f'{phase}_{pair[0]}'),enumerate(FIXTURE['qa'])))
    metrics('after_'+phase)
    assert all(x['ok'] for x in results)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    pending=[pool.submit(run,FIXTURE['stagger'],'stagger_0',512)]
    for i,threshold in enumerate((96,192,288),start=1):
        deadline=time.monotonic()+180
        while time.monotonic()<deadline:
            with lock:p=dict(progress.get('stagger_0',{}))
            if p.get('tokens',0)>=threshold or p.get('done'):break
            time.sleep(.02)
        else:raise TimeoutError('stagger launch threshold')
        print(json.dumps(dict(event='stagger_launch',index=i,threshold=threshold,observed=p,time=time.time())),flush=True)
        pending.append(pool.submit(run,FIXTURE['stagger'],f'stagger_{i}',512))
    results.extend(f.result() for f in pending)
metrics('after_stagger');assert all(x['ok'] for x in results)
for item in FIXTURE['boundaries']:
    for repeat in range(2):
        results.append(run(item,f'boundary_{item["length"]}_r{repeat}'))
        assert results[-1]['ok']
metrics('after_boundaries')
(EVIDENCE/f'{TAG}.summary.json').write_text(json.dumps(dict(rows=[{k:v for k,v in r.items() if k!='logprobs'} for r in results]),ensure_ascii=False,indent=2))
print(json.dumps(dict(event='matrix_complete',tag=TAG,count=len(results),ok=all(x['ok'] for x in results))),flush=True)
