import json
import time
from pathlib import Path
import psutil
import requests
root=Path('/workspace/dspark_ctxwin_validation/retention_isolation_20261102_round02')
base='http://127.0.0.1:8874'
r=requests.get(base+'/health',timeout=10);r.raise_for_status()
models=requests.get(base+'/v1/models',timeout=10);models.raise_for_status()
metrics=requests.get(base+'/metrics',timeout=10);metrics.raise_for_status()
lines=[l for l in metrics.text.splitlines() if l.startswith(('vllm:num_requests_running{','vllm:num_requests_waiting{'))]
assert len(lines)==2 and all(float(l.rsplit(' ',1)[1])==0 for l in lines),lines
procs=[p for p in psutil.process_iter(['cmdline']) if str(root/'run_vllm.py') in (p.info['cmdline'] or [])]
assert len(procs)==1
p=procs[0];env=p.environ();assert env['DSPARK_FOLLOWUP_TAG']=='I' and env['ASCEND_RT_VISIBLE_DEVICES']=='4,5,6,7'
row={'health':r.status_code,'api_pid':p.pid,'cmd':p.cmdline(),'physical_devices':env['ASCEND_RT_VISIBLE_DEVICES'],
     'tag':env['DSPARK_FOLLOWUP_TAG'],'models':models.json(),'idle_metrics':lines,'time':time.time(),
     'children':[{'pid':c.pid,'cmd':c.cmdline()} for c in p.children(recursive=True)]}
(root/'evidence/retained_service.json').write_text(json.dumps(row,indent=2))
(root/'evidence/final_idle.metrics.txt').write_text(metrics.text)
print(json.dumps(row),flush=True)
