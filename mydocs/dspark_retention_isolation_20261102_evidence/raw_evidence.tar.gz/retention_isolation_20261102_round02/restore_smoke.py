import json
import time
from pathlib import Path
import requests
root=Path('/workspace/dspark_ctxwin_validation/retention_isolation_20261102_round02')
payload={'model':'dspark-apc-experiment','prompt':'The capital of France is','temperature':0,'top_p':1,'seed':42,'max_tokens':16,'return_token_ids':True,'cache_salt':'retention_round02_final_smoke'}
start=time.time();r=requests.post('http://127.0.0.1:8874/v1/completions',json=payload,timeout=(10,240))
record={'request':payload,'http_status':r.status_code,'response':r.json(),'seconds':time.time()-start,'purpose':'Restore health smoke only, excluded from acceptance matrix'}
(root/'evidence/restore_smoke.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
r.raise_for_status();assert record['response']['usage']['completion_tokens']>0
print(json.dumps(record,ensure_ascii=False),flush=True)
