import ast
import hashlib
import json
import shutil
import subprocess
from pathlib import Path
old=Path('/workspace/dspark_ctxwin_validation/acceptance_20261102_round01')
root=Path('/workspace/dspark_ctxwin_validation/retention_isolation_20261102_round02')
root.mkdir(exist_ok=False);(root/'evidence').mkdir()
shutil.copytree(old/'source',root/'source',symlinks=True,ignore=shutil.ignore_patterns('__pycache__'))
subprocess.run(['/usr/local/python3.12.13/bin/python3','-m','venv','--copies','--without-pip','--system-site-packages',str(root/'runtime')],check=True)
(root/'runtime/lib/python3.12/site-packages/source.pth').write_text(f"import sys; sys.path.insert(0, {str(root/'source')!r})\n")
for name in ['startup_audit.py','run_vllm.py','fixtures.json']:
 shutil.copy2(old/name,root/name)
audit=(old/'apc_audit.py').read_text().split('    # Diagnostic E only:')[0]
audit=audit.replace('CPU observation for B/C/D; E only adds a diagnostic retirement override.','Same-group retention diagnostic; per-request release/hold mode, default release.')
audit=audit.replace('    reclaimed = {}','    reclaimed = {}\n    policies = {}')
audit=audit.replace('    def computed(self, request):\n        result = lookup(self, request)', '''    def computed(self, request):
        mode = (root / 'retention_mode.txt').read_text().strip()
        assert mode in ('release', 'hold'), mode
        previous = policies.setdefault(request.request_id, mode)
        assert previous == mode, 'Cannot change policy for an active request'
        record('retention_policy', request_id=request.request_id, mode=mode)
        result = lookup(self, request)''')
audit=audit.replace('''        before=list(self.req_to_blocks[request_id])
        refs=''','''        mode = policies.get(request_id, 'release')
        if mode == 'hold':
            assert self.kv_cache_group_id == 2 and self.sliding_window == 2191
            processed = args[0] if args else kwargs['processed_computed_tokens']
            boundary = self.get_num_skipped_tokens(processed)
            before = list(self.req_to_blocks[request_id])
            candidates = [dict(column=i, block_id=b.block_id, refs=b.ref_cnt)
                          for i,b in enumerate(before[:boundary // self.block_size]) if not b.is_null]
            if candidates:
                record('retirement_suppressed', request_id=request_id, gid=self.kv_cache_group_id,
                       processed_tokens=processed, boundary=boundary, candidates=candidates)
            return None
        before=list(self.req_to_blocks[request_id])
        refs=''')
assert 'retain_same_layout' not in audit and 'retirement_suppressed' in audit
(root/'apc_audit.py').write_text(audit)
(root/'retention_mode.txt').write_text('release\n')
serve=(old/'serve.sh').read_text().replace(str(old),str(root)).replace('dspark_acceptance_20261102_round01_', 'dspark_retention_isolation_20261102_round02_')
# One fixed launch configuration; the experiment varies only the request-local retirement policy.
start=serve.index('tag=${1:');end=serve.index('export ASCEND_RT_VISIBLE_DEVICES')
serve=serve[:start]+'tag=I\napc=--enable-prefix-caching\ndrop=true\n'+serve[end:]
(root/'serve.sh').write_text(serve)
s=(old/'wait_ready.py').read_text().replace(str(old),str(root));(root/'wait_ready.py').write_text(s)
s=(old/'final_health.py').read_text().replace(str(old),str(root)).replace("=='D_restore'","=='I'");(root/'final_health.py').write_text(s)
(root/'restore_smoke.py').write_text((old/'restore_smoke.py').read_text().replace(str(old),str(root)).replace('acceptance_round01_restore_smoke','retention_round02_final_smoke'))
manifest=json.loads((old/'manifest.json').read_text())
manifest={k:manifest[k] for k in ['draft_config','draft_weight','draft_config_sha256','source_hashes','vllm_commit']}
manifest.update(root=str(root),previous_root=str(old),apc=True,drop_config=True,context_window=2048,retention=2191,
 comparison='Single engine and identical groups; request-local release vs suppression of SlidingWindowManager.remove_skipped_blocks; cache lookup unchanged',
 planned_sequence=['release_a','hold_a','hold_b','release_b'],requests_per_group=3,case='agent_long_0',
 private_checkpoint_reproduced=False)
assert subprocess.check_output(['git','-C','/vllm-workspace/vllm','rev-parse','HEAD'],text=True).strip()==manifest['vllm_commit']
assert not subprocess.check_output(['git','-C','/vllm-workspace/vllm','status','--porcelain'],text=True).strip()
for name,h in manifest['source_hashes'].items():assert hashlib.sha256((root/'source/vllm_ascend'/name).read_bytes()).hexdigest()==h
manifest['draft_weight_sha256']=json.loads((old/'manifest.json').read_text()).get('draft_weight_sha256')
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
(root/'evidence/npu_before.txt').write_text(subprocess.check_output(['npu-smi','info'],text=True))
shutil.copy2(old/'evidence/retained_service.json',root/'evidence/previous_retained_service.json')
shutil.copy2('/opt/w00958190/log/dspark_acceptance_20261102_round01_D_restore_serve.log',root/'evidence/previous_service_exit.log')
print('Prepared',root)
