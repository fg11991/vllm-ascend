import json
from collections import Counter
from pathlib import Path
root=Path(__file__).parent;e=root/'evidence'
sets={name:json.loads((e/file).read_text())['rows'] for name,file in [('main','I.summary.json'),('cross','I.cross.summary.json'),('reverse','I.reverse.summary.json')]}
rows=[r for xs in sets.values() for r in xs]
events=[json.loads(line) for line in (e/'I.scheduler.jsonl').read_text().splitlines()]
coord=[x for x in events if x['event']=='coordinator']
assert len(coord)==1 and len(coord[0]['managers'])==9
assert coord[0]['managers'][2]['cls']=='SlidingWindowManager' and coord[0]['managers'][2]['retention']==2191
assert len(rows)==20 and all(r['ok'] and r['metrics_match_audit'] for r in rows)
assert len({s['pid'] for r in rows for s in r['steps']})==1
assert len({r['prompt_sha256'] for r in rows})==1
assert all(r['drop'] and r['apc'] and r['metric_delta']['vllm:num_preemptions_total']==0 for r in rows)
for r in rows:
 assert r['metric_delta']['vllm:prefix_cache_hits_total']==(0 if r['repeat']==0 else 14336)
 if r['retention_mode']=='hold':assert r['actual_freed_blocks']==0 and r['suppressed_calls']>0
 else:assert r['actual_freed_blocks']>0 and r['suppressed_calls']==0

def aggregate(xs):
 a=sum(r['stats']['accepted'] for r in xs);d=sum(r['stats']['drafted'] for r in xs);n=sum(r['stats']['steps'] for r in xs)
 return dict(requests=len(xs),accepted=a,drafted=d,steps=n,acceptance=a/d,mean_acceptance_length=1+a/n)
def compare(a,b):
 n=next((i for i,(x,y) in enumerate(zip(a['output_ids'],b['output_ids'])) if x!=y),min(len(a['output_ids']),len(b['output_ids'])))
 aa={s['output_tokens_before']:s for s in a['steps']};bb={s['output_tokens_before']:s for s in b['steps']}
 diffs=[{'output_tokens_before':pos,'release_accepted':aa[pos]['accepted'],'hold_accepted':bb[pos]['accepted']} for pos in sorted(aa.keys()&bb.keys()) if pos<=n and aa[pos]['accepted']!=bb[pos]['accepted']]
 free=[x for x in a['retention_events'] if x['event']=='window_reclaim']
 return {'release':a['label'],'hold':b['label'],'same_output_ids':a['output_ids']==b['output_ids'],'common_output_tokens':n,'lengths':[len(a['output_ids']),len(b['output_ids'])],
 'same_cached_block_ids':a['lookup'][0]['groups']==b['lookup'][0]['groups'],
 'release_minus_hold_pp':100*(a['stats']['acceptance']-b['stats']['acceptance']),
 'first_same_history_step_difference':diffs[:1],
 'first_release_processed_tokens':free[0]['processed_tokens'] if free else None,
 'first_release_processed_tokens_minus_prompt':free[0]['processed_tokens']-a['prompt_tokens'] if free else None}
s={'completed_requests':20,'coordinator':coord[0],'event_counts':dict(Counter(x['event'] for x in events)),
 'actual_freed_blocks':sum(r['actual_freed_blocks'] for r in rows),'suppressed_calls':sum(r['suppressed_calls'] for r in rows),
 'total_cache_hits':sum(r['metric_delta']['vllm:prefix_cache_hits_total'] for r in rows),
 'phases':{},'pairs':[],'rows':[]}
for phase,xs in sets.items():
 s['phases'][phase]={mode:{part:aggregate([r for r in xs if r['retention_mode']==mode and (r['repeat']>0 if part=='hot' else r['repeat']==0)]) for part in (['cold','hot'] if phase=='main' else ['hot'])} for mode in ['release','hold']}
for phase in ['cross','reverse']:
 for cache in ['release_a','hold_b']:
  xs=[r for r in sets[phase] if r['cache_group']==cache]
  a=next(r for r in xs if r['retention_mode']=='release');b=next(r for r in xs if r['retention_mode']=='hold')
  ref=next(r for r in sets['main'] if r['group']==cache and r['repeat']==1)
  pair=compare(a,b);pair.update(phase=phase,cache=cache,cached_blocks_match_original=all(r['lookup'][0]['groups']==ref['lookup'][0]['groups'] for r in xs))
  assert pair['same_cached_block_ids'] and pair['cached_blocks_match_original']
  s['pairs'].append(pair)
for r in rows:s['rows'].append({k:r[k] for k in ['label','group','retention_mode','repeat','stats','usage','metric_delta','actual_freed_blocks','suppressed_calls']})
(root/'final_summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2))
print(json.dumps({k:s[k] for k in ['completed_requests','actual_freed_blocks','suppressed_calls','total_cache_hits','event_counts','phases','pairs']},ensure_ascii=False,indent=2))
