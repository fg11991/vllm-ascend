import json
import sys
import time
from pathlib import Path
import psutil
import requests
root=Path('/workspace/dspark_ctxwin_validation/retention_isolation_20261102_round02');tag=sys.argv[1]
deadline=time.monotonic()+1200
while time.monotonic()<deadline:
    try:
        r=requests.get('http://127.0.0.1:8874/health',timeout=5)
        if r.ok:
            procs=[p for p in psutil.process_iter(['cmdline']) if str(root/'run_vllm.py') in (p.info['cmdline'] or [])]
            assert len(procs)==1 and procs[0].environ()['DSPARK_FOLLOWUP_TAG']==tag
            models=requests.get('http://127.0.0.1:8874/v1/models',timeout=10);models.raise_for_status()
            data={'tag':tag,'pid':procs[0].pid,'command':procs[0].cmdline(),'models':models.json(),'time':time.time()}
            (root/'evidence'/f'{tag}{sys.argv[2] if len(sys.argv)>2 else ""}.ready.json').write_text(json.dumps(data,indent=2))
            print('READY',tag,procs[0].pid,flush=True);break
    except requests.RequestException:pass
    time.sleep(5)
else:raise TimeoutError('Service startup exceeded 20 minutes')
