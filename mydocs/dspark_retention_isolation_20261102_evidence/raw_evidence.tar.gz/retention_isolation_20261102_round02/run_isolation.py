import hashlib
import json
import re
import sys
import time
from pathlib import Path
import requests
ROOT=Path(__file__).parent
E=ROOT/'evidence';TAG='I';BASE='http://127.0.0.1:8874'
SEQUENCE=[('release_a','release'),('hold_a','hold'),('hold_b','hold'),('release_b','release')]
CASES=json.loads((ROOT/'fixtures.json').read_text())['cases']
CASES=CASES[:1]
DEADLINE=time.monotonic()+1800

def snapshot(label):
    r=requests.get(BASE+'/metrics',timeout=10);r.raise_for_status()
    (E/f'{TAG}.{label}.metrics.txt').write_text(r.text)
    counts={}
    for line in r.text.splitlines():
        if line.startswith('#') or not line:continue
        name=line.split('{')[0].split()[0]
        value=float(line.rsplit(' ',1)[1])
        if name in ('vllm:spec_decode_num_drafts_total','vllm:spec_decode_num_draft_tokens_total','vllm:spec_decode_num_accepted_tokens_total','vllm:prefix_cache_hits_total','vllm:prefix_cache_queries_total','vllm:num_preemptions_total'):
            counts[name]=counts.get(name,0)+value
        if name in ('vllm:num_requests_running','vllm:num_requests_waiting'):
            assert value==0,(name,value)
    return counts

def events(label):
    path=E/f'{TAG}.scheduler.jsonl'
    return [r for line in path.read_text().splitlines() if (r:=json.loads(line)).get('request_id','').find(label)>=0]

def stats(steps):
    drafted=sum(r['proposed'] for r in steps);accepted=sum(r['accepted'] for r in steps)
    return dict(steps=len(steps),drafted=drafted,accepted=accepted,acceptance=accepted/drafted if drafted else None,
                mean_acceptance_length=1+accepted/len(steps) if steps else None,
                accepted_per_position=[sum(r['accepted']>i for r in steps) for i in range(7)])

rows=[]
try:
    for group,mode in SEQUENCE:
        snapshot(group+'.before_policy_switch')
        temp=ROOT/'retention_mode.next';temp.write_text(mode+'\n');temp.replace(ROOT/'retention_mode.txt')
        for item in CASES:
            # Isolate each prompt's cache key; repeated requests reuse the same salt.
            for repeat in range(3):
                assert time.monotonic()<DEADLINE,'client time budget exhausted'
                label=f'{TAG}_{group}_{item["label"]}_r{repeat}'
                out=E/f'{label}.result.json';assert not out.exists(),out
                before=snapshot(label+'.before')
                payload=dict(model='dspark-apc-experiment',request_id=label,prompt=item['tokens'],max_tokens=512,
                             temperature=0,top_p=1,seed=42,return_token_ids=True,stream=True,
                             stream_options={'include_usage':True})
                if TAG!='B':
                    payload['cache_salt']='retention_isolation_round02_'+group+'_'+item['label']
                (E/f'{label}.request.json').write_text(json.dumps(payload))
                row=dict(label=label,group=group,retention_mode=mode,case=item['label'],repeat=repeat,apc=TAG!='B',drop=TAG!='C',
                         prompt_tokens=len(item['tokens']),prompt_sha256=item['tokens_sha256'],started=time.time())
                ids=[];text='';chunks=[];start=time.monotonic();done=False
                try:
                    with requests.post(BASE+'/v1/completions',json=payload,stream=True,timeout=(10,240)) as response:
                        row['http_status']=response.status_code
                        response.raise_for_status()
                        for line in response.iter_lines(decode_unicode=True):
                            if not line.startswith('data:'):continue
                            line=line[5:].strip()
                            if line=='[DONE]':done=True;break
                            obj=json.loads(line)
                            if obj.get('error'):raise RuntimeError(obj['error'])
                            row['server_request_id']=obj.get('id')
                            if obj.get('usage'):row['usage']=obj['usage']
                            for choice in obj.get('choices',[]):
                                new=choice.get('token_ids') or [];ids.extend(new);text+=choice.get('text','')
                                if new:chunks.append([time.monotonic()-start,len(new)])
                                if choice.get('finish_reason'):row['finish_reason']=choice['finish_reason']
                    assert done and ids and len(ids)==row['usage']['completion_tokens'],row
                    row['ok']=True
                except Exception as exc:
                    row.update(ok=False,error=repr(exc))
                row.update(output_ids=ids,text=text,chunks=chunks,seconds=time.monotonic()-start)
                time.sleep(1)
                audit=events(label);steps=[r for r in audit if r['event']=='spec_step'];lookups=[r for r in audit if r['event']=='lookup']
                row['stats']=stats(steps);row['first_8_steps']=stats(steps[:8]);row['after_8_steps']=stats(steps[8:])
                row['lookup']=lookups;row['steps']=steps
                row['retention_events']=[r for r in audit if r['event'] in ('retention_policy','window_reclaim','retirement_suppressed')]
                assert [r['mode'] for r in audit if r['event']=='retention_policy'] == [mode]
                row['actual_freed_blocks']=sum(len(r['freed']) for r in audit if r['event']=='window_reclaim')
                row['suppressed_calls']=sum(r['event']=='retirement_suppressed' for r in audit)
                assert not (mode=='hold' and any(r['event']=='window_reclaim' for r in audit))
                after=snapshot(label+'.after')
                row['metric_delta']={k:after.get(k,0)-before.get(k,0) for k in set(after)|set(before)}
                row['metrics_match_audit']=all(row['metric_delta'].get(k)==v for k,v in [
                    ('vllm:spec_decode_num_drafts_total',len(steps)),('vllm:spec_decode_num_draft_tokens_total',row['stats']['drafted']),
                    ('vllm:spec_decode_num_accepted_tokens_total',row['stats']['accepted'])])
                out.write_text(json.dumps(row,ensure_ascii=False,indent=2));rows.append(row)
                print(json.dumps({k:v for k,v in row.items() if k not in ('output_ids','text','chunks','steps','lookup','retention_events')},ensure_ascii=False),flush=True)
                assert row['ok'] and steps and lookups,row.get('error','missing audit')
                assert row['metrics_match_audit'],'Metrics delta and per-request scheduler counters disagree'
                if repeat==0 or TAG=='B':assert all(r['hit_tokens']==0 for r in lookups),lookups
                else:assert any(r['hit_tokens']>0 for r in lookups),'Expected a real warm prefix hit'
finally:
    temp=ROOT/'retention_mode.next';temp.write_text('release\n');temp.replace(ROOT/'retention_mode.txt')
(E/f'{TAG}.summary.json').write_text(json.dumps({'rows':rows},ensure_ascii=False,indent=2))
print('COMPLETE',TAG,len(rows),flush=True)
