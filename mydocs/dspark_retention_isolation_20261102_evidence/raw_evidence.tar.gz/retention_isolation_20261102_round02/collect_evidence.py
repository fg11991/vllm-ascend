"""Snapshot this experiment only; excludes weights and runtime/build caches."""
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path
root=Path('/workspace/dspark_ctxwin_validation/retention_isolation_20261102_round02')
logs=root/'service_logs';logs.mkdir(exist_ok=True)
for p in Path('/opt/w00958190/log').glob('dspark_retention_isolation_20261102_round02_*'):
    if p.is_file():shutil.copy2(p,logs/p.name)
config=Path('/workspace/dspark_ctxwin_validation/apc_20261031_round01/models/trained-window-2048/config.json')
shutil.copy2(config,root/'draft_config.json')
(root/'evidence/final_npu_smi.txt').write_text(subprocess.check_output(['npu-smi','info'],text=True))
manifest=json.loads((root/'manifest.json').read_text())
with Path(manifest['draft_weight']).open('rb') as f:
    observed=hashlib.file_digest(f,'sha256').hexdigest()
assert observed==manifest['draft_weight_sha256']
assert hashlib.sha256(Path(manifest['draft_config']).read_bytes()).hexdigest()==manifest['draft_config_sha256']
for name,expected in manifest['source_hashes'].items():
    assert hashlib.sha256((root/'source/vllm_ascend'/name).read_bytes()).hexdigest()==expected
from importlib.metadata import version, PackageNotFoundError
versions={}
for name in ['torch','torch-npu','triton','transformers','vllm','vllm-ascend']:
    try:versions[name]=version(name)
    except PackageNotFoundError:versions[name]=None
manifest['packages']=versions
manifest['final_mode']=(root/'retention_mode.txt').read_text().strip()
assert manifest['final_mode']=='release'
manifest['final_hashes_reverified']=True
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
files=[p for p in root.iterdir() if p.is_file() and p.name!='SHA256SUMS']
files+=list((root/'evidence').rglob('*'))+list(logs.rglob('*'))
files=sorted(p for p in files if p.is_file())
(root/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(root))+'\n' for p in files))
files.append(root/'SHA256SUMS')
archive=root.parent/(root.name+'_evidence.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
    for p in files:tar.add(p,arcname=str(Path(root.name)/p.relative_to(root)),recursive=False)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)}))
