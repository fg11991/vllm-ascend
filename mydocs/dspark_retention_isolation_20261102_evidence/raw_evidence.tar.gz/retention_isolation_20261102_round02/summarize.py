import json
from collections import Counter
from pathlib import Path
root=Path(__file__).parent;e=root/'evidence'
rows=[json.loads(p.read_text()) for p in sorted(e.glob('I_*_agent_long_0_r*.result.json'))]
rows=[r for r in rows if r['group'] in ('release_a','hold_a','hold_b','release_b')]
events=[json.loads(line) for line in (e/'I.scheduler.jsonl').read_text().splitlines()]
coordinators=[r for r in events if r['event']=='coordinator']
assert len(coordinators)==1 and len(coordinators[0]['managers'])==9
assert coordinators[0]['managers'][2]['cls']=='SlidingWindowManager' and coordinators[0]['managers'][2]['retention']==2191
assert len(rows)==12 and all(r['ok'] and r['metrics_match_audit'] for r in rows)
assert len({s['pid'] for r in rows for s in r['steps']})==1
assert len({r['prompt_sha256'] for r in rows})==1
assert all(r['drop'] and r['apc'] for r in rows)
for r in rows:
 assert r['metric_delta']['vllm:num_preemptions_total']==0
 assert r['metric_delta']['vllm:prefix_cache_hits_total']==(0 if r['repeat']==0 else 14336)
 if r['retention_mode']=='hold':assert r['actual_freed_blocks']==0
 if r['repeat']==0:
  assert r['actual_freed_blocks']>0 if r['retention_mode']=='release' else r['suppressed_calls']>0

def aggregate(xs):
 a=sum(r['stats']['accepted'] for r in xs);d=sum(r['stats']['drafted'] for r in xs);n=sum(r['stats']['steps'] for r in xs)
 return dict(requests=len(xs),accepted=a,drafted=d,steps=n,acceptance=a/d,mean_acceptance_length=1+a/n)
def common(a,b):return next((i for i,(x,y) in enumerate(zip(a,b)) if x!=y),min(len(a),len(b)))
def pair(a,b):
 n=common(a['output_ids'],b['output_ids'])
 aa={s['output_tokens_before']:s for s in a['steps']};bb={s['output_tokens_before']:s for s in b['steps']}
 diffs=[{'output_tokens_before':pos,'a_accepted':aa[pos]['accepted'],'b_accepted':bb[pos]['accepted']} for pos in sorted(aa.keys()&bb.keys()) if pos<=n and aa[pos]['accepted']!=bb[pos]['accepted']]
 return {'a':a['label'],'b':b['label'],'same_output_ids':a['output_ids']==b['output_ids'],'common_output_tokens':n,'lengths':[len(a['output_ids']),len(b['output_ids'])],'acceptance_difference_pp':100*(b['stats']['acceptance']-a['stats']['acceptance']),'first_same_history_step_difference':diffs[:1]}
s={'completed_requests':len(rows),'coordinator':coordinators[0],'scheduler_pid':coordinators[0]['pid'],'event_counts':dict(Counter(r['event'] for r in events)),
 'groups':{},'modes':{},'rows':[],'pairs':[],'previous_round_pairs':[]}
for g in ['release_a','hold_a','hold_b','release_b']:
 xs=[r for r in rows if r['group']==g]
 s['groups'][g]={p:aggregate(ys) for p,ys in [('cold',[r for r in xs if r['repeat']==0]),('hot',[r for r in xs if r['repeat']>0])]}
for mode in ['release','hold']:
 xs=[r for r in rows if r['retention_mode']==mode]
 s['modes'][mode]={p:aggregate(ys) for p,ys in [('cold',[r for r in xs if r['repeat']==0]),('hot',[r for r in xs if r['repeat']>0])]}
for r in rows:
 s['rows'].append({k:r[k] for k in ['label','retention_mode','repeat','stats','usage','metric_delta','actual_freed_blocks','suppressed_calls']})
for ag,bg in [('release_a','hold_a'),('release_b','hold_b'),('release_a','release_b'),('hold_a','hold_b')]:
 for rep in range(3):
  a=next(r for r in rows if r['group']==ag and r['repeat']==rep);b=next(r for r in rows if r['group']==bg and r['repeat']==rep)
  s['pairs'].append(pair(a,b))
previous=Path('/workspace/dspark_ctxwin_validation/acceptance_20261102_round01/evidence')
for tag in ['C','D']:
 for r in rows:
  if r['repeat']==1:
   p=previous/f'{tag}_agent_long_0_r1.result.json'
   s['previous_round_pairs'].append(pair(json.loads(p.read_text()),r))
(root/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2))
print(json.dumps({'groups':s['groups'],'modes':s['modes'],'pairs':s['pairs'],'events':s['event_counts'],'rows':s['rows']},ensure_ascii=False,indent=2))
