import ast
import json
from pathlib import Path
from types import SimpleNamespace
root=Path(__file__).parent
module=ast.parse((root/'apc_audit.py').read_text())
fn=next(n for n in ast.walk(module) if isinstance(n,ast.FunctionDef) and n.name=='removed')
records=[];calls=[];policies={};reclaimed={}
null=SimpleNamespace(is_null=True,block_id=0,ref_cnt=1)
def original(self,request_id,processed_computed_tokens,num_prompt_tokens=None):
 calls.append([request_id,processed_computed_tokens,num_prompt_tokens])
 limit=self.get_num_skipped_tokens(processed_computed_tokens)//self.block_size
 for i,b in enumerate(self.req_to_blocks[request_id][:limit]):
  if not b.is_null:b.ref_cnt-=1;self.req_to_blocks[request_id][i]=null
ns={'remove':original,'record':lambda event,**kw:records.append({'event':event,**kw}),'policies':policies,'reclaimed':reclaimed}
exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'hook_test','exec'),ns)
def manager():
 return SimpleNamespace(kv_cache_group_id=2,sliding_window=2191,extra_retained_tokens=0,block_size=896,block_pool=object(),req_to_blocks={'x':[SimpleNamespace(is_null=False,block_id=i+1,ref_cnt=1) for i in range(10)]},get_num_skipped_tokens=lambda n:max(0,n-2191+1))
for mode in ('hold','release'):
 policies['x']=mode;m=manager();before=list(m.req_to_blocks['x']);calls.clear();records.clear()
 ns['removed'](m,'x',8192,14512)
 if mode=='hold':
  assert not calls and m.req_to_blocks['x']==before and all(b.ref_cnt==1 for b in before)
  assert len(records)==1 and records[0]['event']=='retirement_suppressed' and len(records[0]['candidates'])==6
 else:
  assert calls==[['x',8192,14512]] and sum(b.is_null for b in m.req_to_blocks['x'])==6
  assert records[0]['event']=='window_reclaim' and len(records[0]['freed'])==6
policies['x']='release';m=manager();calls.clear()
ns['removed'](m,'x',processed_computed_tokens=0,num_prompt_tokens=14512)
assert calls==[['x',0,14512]] and not any(b.is_null for b in m.req_to_blocks['x'])
result={'passed':True,'checks':['exact coordinator four positional arguments','hold keeps block references/table and skips original','release calls original with unchanged args and frees exact eligible blocks','zero boundary and keyword arguments']}
(root/'evidence/hook_test.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
