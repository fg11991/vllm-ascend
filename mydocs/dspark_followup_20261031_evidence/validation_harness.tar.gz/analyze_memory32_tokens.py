"""Token comparisons for the two 32-request memory/free-writing waves."""
import json,itertools
from pathlib import Path
root=Path(__file__).parent
loaded={p.stem.removesuffix('_memory32'):json.loads(p.read_text()) for p in (root/'results').glob('memory32_*_memory32.json')}
waves={}
for tag,data in loaded.items():
 for wave in [0,1]:
  rows=sorted([x for x in data['requests'] if x['name'].startswith(f'wave{wave}_')],key=lambda x:int(x['name'].split('request')[1]));assert len(rows)==32
  waves[(tag,wave)]=rows
comparisons=[]
for (a,ra),(b,rb) in itertools.combinations(waves,2):
 if a!=b and ra!=rb:continue
 detail=[]
 for i,(u,v) in enumerate(zip(waves[(a,ra)],waves[(b,rb)])):
  assert u['prompt_sha256']==v['prompt_sha256'] and u['prompt_tokens']==v['prompt_tokens']
  x,y=u['output_ids'],v['output_ids'];n=next((i for i,(q,w) in enumerate(zip(x,y)) if q!=w),min(len(x),len(y)))
  ea=next((i for i,t in enumerate(x) if t in [248044,248046]),None);eb=next((i for i,t in enumerate(y) if t in [248044,248046]),None)
  detail.append(dict(request=i,prompt_tokens=u['prompt_tokens'],equal=x==y,lcp=n,first_eos_a=ea,first_eos_b=eb,token_a=x[n] if n<len(x) else None,token_b=y[n] if n<len(y) else None))
 comparisons.append(dict(a=a,wave_a=ra,b=b,wave_b=rb,count=32,exact=sum(x['equal'] for x in detail),requests=detail))
(root/'memory32_token_comparisons.json').write_text(json.dumps(comparisons,indent=2))
print('MEMORY32_TOKEN_COMPARISONS',[(x['a'],x['wave_a'],x['b'],x['wave_b'],x['exact']) for x in comparisons])
