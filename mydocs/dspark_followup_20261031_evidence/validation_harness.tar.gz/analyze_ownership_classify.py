"""Join worker capture timestamps with scheduler pool ownership, without equating host time to device completion."""
import json,sys,collections
from pathlib import Path
root=Path(__file__).parent;tag=sys.argv[1];events=[];config=None
for p in Path('/opt/w00958190/log').glob(f'dspark_20261031_diag_{tag}_*.jsonl'):
 for line in p.open():
  e=json.loads(line);kind=e['kind']
  if kind=='config':config=e
  if kind in ['allocate','free']:events.append((e['time'],kind,e))
  elif kind=='draft' and 'starts' in e:
   rows=[]
   for i,rid in enumerate(e['requests']):
    for gi,gid in enumerate(e['window_tables']):
     kb=e['kernel_blocks'][gid];n=(e['window_lengths'][i]+kb-1)//kb
     # Save kernel IDs now; convert using the logged scheduler group block size below.
     reads=e['window_tables'][gid][i][:n]
     lo,hi=e['query_start_loc'][i:i+2]
     writes=[s//kb for s in e['context_slots'][gi][lo:hi] if s>=0]+[s//kb for s in e['query_slots'][gid][i*7:(i+1)*7] if s>=0]
     rows.append(dict(request=rid,group=int(gid),kernel_size=kb,reads=reads,writes=writes))
   events.append((e['capture_time'],'capture',dict(pid=e['pid'],step=e['step'],rows=rows)))
assert config is not None
owners={};last_free={};stats=collections.Counter();mismatches=[]
for when,kind,e in sorted(events,key=lambda x:x[0]):
 if kind=='allocate':
  ctx=e.get('context') or {}
  for bid in e['ids']:owners[bid]=(ctx.get('request'),ctx.get('group'))
 elif kind=='free':
  for bid,ref in e['after']:
   if ref==0:
    owners.pop(bid,None);last_free[bid]=dict(time=when,context=e.get('context'))
 else:
  for row in e['rows']:
   ratio=config['groups'][row['group']]['block_size']//row['kernel_size']
   expected=(row['request'],row['group'])
   for op in ['reads','writes']:
    for bid in {k//ratio for k in row[op]}:
     stats[op+'_physical_block_checks']+=1
     actual=owners.get(bid)
     if actual!=expected:
      stats[op+'_host_timestamp_owner_mismatches']+=1
      previous=last_free.get(bid) or {};ctx=previous.get('context') or {}
      classification='terminal_release' if actual is None and ctx.get('method')=='free' and (ctx.get('request'),ctx.get('group'))==expected else 'other'
      stats[classification]+=1
      if len(mismatches)<100:mismatches.append(dict(time=when,pid=e['pid'],step=e['step'],operation=op,block=bid,expected=expected,actual=actual,last_free=previous,classification=classification))
result=dict(tag=tag,counts=dict(stats),mismatches=mismatches,note='Ownership is reconstructed at CPU capture_time, not actual NPU read completion. Any mismatch needs event-order investigation; zero mismatches plus logical mapping checks are device-path evidence, not a replacement for the scheduler in-flight proof.')
(root/'results'/f'{tag}_ownership_summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['counts'],indent=2))

assert not mismatches,'Host-timestamp ownership mismatches require inspection before proceeding; not yet proof of an NPU invalid read.'
