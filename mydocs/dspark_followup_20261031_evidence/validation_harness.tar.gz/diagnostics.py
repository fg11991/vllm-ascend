"""Isolated validation instrumentation; NEVER loaded by performance entrypoints."""
import os,json,time,functools
from pathlib import Path

def emit(kind,**data):
    tag=os.environ['DSPARK_FOLLOWUP_TAG']
    p=Path('/opt/w00958190/log')/f'dspark_20261031_diag_{tag}_{os.getpid()}.jsonl'
    with p.open('a') as f:f.write(json.dumps(dict(kind=kind,time=time.time(),pid=os.getpid(),**data))+'\n')

def install():
    mode=os.environ.get('DSPARK_FOLLOWUP_DIAGNOSTICS','')
    from vllm.v1.core.single_type_kv_cache_manager import SlidingWindowManager,SingleTypeKVCacheManager
    if getattr(SlidingWindowManager,'_followup_installed',False):return
    SlidingWindowManager._followup_installed=True
    if 'keepfull' in mode:
        init=SlidingWindowManager.__init__
        def full_init(self,*a,**kw):
            init(self,*a,**kw)
            self._max_admission_blocks_per_request=None
            emit('keepfull_manager',group=self.kv_cache_group_id,retention=self.sliding_window,block_size=self.block_size)
        SlidingWindowManager.__init__=full_init
        SlidingWindowManager.get_num_skipped_tokens=lambda self,num_computed_tokens:0
    if 'pool' in mode:
        from vllm.v1.core.block_pool import BlockPool
        alloc=BlockPool.get_new_blocks;free=BlockPool.free_blocks
        def allocate(self,num_blocks):
            result=alloc(self,num_blocks)
            emit('allocate',ids=[b.block_id for b in result],context=getattr(self,'_followup_context',None),free=self.get_num_free_blocks())
            return result
        def release(self,ordered_blocks):
            blocks=list(ordered_blocks)
            before=[(b.block_id,b.ref_cnt) for b in blocks]
            free(self,blocks)
            emit('free',before=before,after=[(b.block_id,b.ref_cnt) for b in blocks],context=getattr(self,'_followup_context',None),free=self.get_num_free_blocks())
        BlockPool.get_new_blocks=allocate;BlockPool.free_blocks=release
        def wrap_context(name):
            original=getattr(SingleTypeKVCacheManager,name)
            @functools.wraps(original)
            def wrapped(self,request_id,*a,**kw):
                old=getattr(self.block_pool,'_followup_context',None)
                self.block_pool._followup_context=dict(method=name,request=request_id,group=self.kv_cache_group_id)
                try:
                    before=[b.block_id for b in self.req_to_blocks.get(request_id,())] if name=='remove_skipped_blocks' and isinstance(self,SlidingWindowManager) else None
                    result=original(self,request_id,*a,**kw)
                    if before is not None:
                        emit('skip_boundary',request=request_id,group=self.kv_cache_group_id,computed=a[0] if a else kw.get('num_computed_tokens'),before=before,after=[b.block_id for b in self.req_to_blocks.get(request_id,())],retention=self.sliding_window,block_size=self.block_size)
                    return result
                finally:self.block_pool._followup_context=old
            setattr(SingleTypeKVCacheManager,name,wrapped)
        for name in ['allocate_new_blocks','remove_skipped_blocks','free','add_local_computed_blocks']:
            wrap_context(name)
        from vllm.v1.core.sched.scheduler import Scheduler
        update_original=Scheduler._update_after_schedule
        def update(self,output):
            update_original(self,output)
            km=self.kv_cache_manager;pool=km.block_pool
            if not hasattr(self,'_followup_config_logged'):
                self._followup_config_logged=True
                from vllm.v1.kv_cache_interface import UniformTypeKVCacheSpecs
                groups=[]
                for g in km.kv_cache_config.kv_cache_groups:
                    s=g.kv_cache_spec
                    inner=list(s.kv_cache_specs.values()) if isinstance(s,UniformTypeKVCacheSpecs) else [s]*len(g.layer_names)
                    groups.append(dict(spec=type(s).__name__,layers=g.layer_names,block_size=s.block_size,pages=[x.page_size_bytes for x in inner],retention=[getattr(x,'sliding_window',None) for x in inner]))
                emit('config',groups=groups,num_blocks=pool.num_gpu_blocks,null_id=pool.null_block.block_id,managers=[dict(type=type(m).__name__,retention=getattr(m,'sliding_window',None),extra_retained_tokens=getattr(m,'extra_retained_tokens',None),admission_cap=getattr(m,'_max_admission_blocks_per_request',None)) for m in km.coordinator.single_type_managers])
            rows=[]
            for req in self.running:
                tables=[[b.block_id for b in m.req_to_blocks.get(req.request_id,())] for m in km.coordinator.single_type_managers]
                rows.append(dict(id=req.request_id,prompt=req.num_prompt_tokens,computed=req.num_computed_tokens,inflight=req.num_in_flight_tokens,output=req.num_output_tokens,tables=tables))
            live=[b.block_id for b in pool.blocks if b.ref_cnt>0 and not b.is_null]
            emit('scheduler',requests=rows,free=pool.get_num_free_blocks(),live=live,total=pool.num_gpu_blocks,waiting=len(self.waiting),scheduled=dict(output.num_scheduled_tokens),spec={k:len(v) for k,v in output.scheduled_spec_decode_tokens.items()})
        Scheduler._update_after_schedule=update
        preempt=Scheduler._preempt_request
        def preemption(self,request,*a,**kw):
            emit('preempt_before',request=request.request_id,computed=request.num_computed_tokens,inflight=request.num_in_flight_tokens,output=request.num_output_tokens)
            result=preempt(self,request,*a,**kw)
            emit('preempt_after',request=request.request_id,computed=request.num_computed_tokens,inflight=request.num_in_flight_tokens,output=request.num_output_tokens,preemptions=request.num_preemptions)
            return result
        Scheduler._preempt_request=preemption
        finish=Scheduler._free_request
        def finished(self,request,*a,**kw):
            result=finish(self,request,*a,**kw)
            pool=self.kv_cache_manager.block_pool
            emit('finished',request=request.request_id,status=str(request.status),inflight=request.num_in_flight_tokens,output=request.num_output_tokens,free=pool.get_num_free_blocks(),total=pool.num_gpu_blocks,live=[b.block_id for b in pool.blocks if b.ref_cnt>0 and not b.is_null])
            return result
        Scheduler._free_request=finished
    if 'trace' in mode:
        # Queue device-side copies; explicit flush requests transfer them after
        # the measured trajectory. Avoid per-step D2H synchronization hiding
        # async timing. Additional device ops still perturb execution: diagnostic
        # results are not used for speed claims.
        pending=[]
        def buffered(kind,**data):
            pending.append((kind,time.time(),data))
        def flush():
            import torch
            def cpu(value):
                if isinstance(value,torch.Tensor):return value.detach().cpu().tolist()
                if isinstance(value,dict):return {k:cpu(v) for k,v in value.items()}
                if isinstance(value,(list,tuple)):return [cpu(v) for v in value]
                return value
            for kind,when,data in pending:
                emit(kind,capture_time=when,**cpu(data))
            emit('trace_flush',records=len(pending))
            pending.clear()
        active_context={}
        from vllm_ascend.worker.v2.model_runner import NPUModelRunner
        prepare=NPUModelRunner.prepare_inputs
        def prepared(self,scheduler_output,batch_req_state,batch_desc):
            result=prepare(self,scheduler_output,batch_req_state,batch_desc)
            if any(r.startswith(('cmpl-','chatcmpl-')) for r in result.req_ids):
                from vllm.distributed import get_tp_group
                active_context.update(step=active_context.get('step',0)+1,requests=list(result.req_ids),mode=str(batch_desc.cg_mode),tp_rank=get_tp_group().rank_in_group)
                state_extra={}
                if hasattr(self.model_state,'num_accepted_tokens_gpu'):
                    state_extra['mamba_previous_accepted']=self.model_state.num_accepted_tokens_gpu[result.idx_mapping].detach().clone()
                buffered('target_shape',**active_context,idx=result.idx_mapping_np.tolist(),tokens=result.num_tokens,padded_tokens=result.num_tokens_after_padding,num_reqs=result.num_reqs,padded_reqs=result.num_reqs_after_padding,scheduled=result.num_scheduled_tokens.tolist(),computed=result.num_computed_tokens_np.tolist(),**state_extra)
            return result
        NPUModelRunner.prepare_inputs=prepared
        from vllm_ascend.worker.v2.spec_decode.dspark.speculator import AscendDSparkSpeculator
        from vllm.v1.worker.gpu.spec_decode.rejection_sampler import RejectionSampler
        propose_original=AscendDSparkSpeculator.propose
        def propose(self,*args,**kwargs):
            result=propose_original(self,*args,**kwargs)
            batch=args[0] if args else kwargs['input_batch']
            dummy=kwargs.get('dummy_run',args[12] if len(args)>12 else False)
            if dummy or not any(r.startswith(('cmpl-','chatcmpl-')) for r in batch.req_ids):return result
            import torch
            if torch.npu.is_current_stream_capturing():return result
            n=batch.num_reqs
            data=dict(step=active_context.get('step'),mode=active_context.get('mode'),tp_rank=active_context.get('tp_rank'),requests=list(batch.req_ids),idx=batch.idx_mapping_np.tolist(),computed=batch.num_computed_tokens_np.tolist(),prefill=batch.is_prefilling_np.tolist(),proposals=result[:n].detach().clone(),sampled=args[5][:n].detach().clone(),rejected=args[6][:n].detach().clone(),target_positions=batch.positions[:batch.num_tokens].detach().clone(),target_input_ids=batch.input_ids[:batch.num_tokens].detach().clone(),target_padded_tokens=batch.num_tokens_after_padding,query_start_loc=batch.query_start_loc_np.tolist(),context_positions=self.context_positions[:batch.num_tokens].detach().clone(),draft_positions=self.input_buffers.positions[:n*self.num_query_per_req].detach().clone(),draft_input_ids=self.input_buffers.input_ids[:n*self.num_query_per_req].detach().clone(),query_slots={str(g):self.block_tables.slot_mappings[g][:n*self.num_query_per_req].detach().clone() for g in self.draft_kv_cache_group_ids},context_slots=self._context_slot_mappings[:,:batch.num_tokens].detach().clone())
            window=self._context_window
            if window is not None:
                data.update(starts=window._starts[:n].detach().clone(),seq_lens=self.input_buffers.seq_lens[:n].detach().clone(),window_lengths=window.windowed_seq_lens[:n].detach().clone(),kernel_blocks=window.kernel_block_sizes,window_tables={str(g):t[:n].detach().clone() for g,t in window.block_table_clones.items()},full_tables={str(g):t[:n].detach().clone() for g,t in window._full_block_tables.items()})
            buffered('draft',**data)
            if any('flush_trace' in rid for rid in batch.req_ids):flush()
            return result
        AscendDSparkSpeculator.propose=propose
        # Eager-only draft head trace. FULL replay does not execute this Python
        # method; do not claim head-logit coverage for replayed graphs.
        head_sample=AscendDSparkSpeculator._sample_logits
        def sample_head(self,logits,idx_map,sample_pos,step):
            result=head_sample(self,logits,idx_map,sample_pos,step)
            import torch
            if active_context.get('requests') and not torch.npu.is_current_stream_capturing():
                values,indices=logits.float().topk(5,dim=-1)
                buffered('eager_draft_head',context=active_context.copy(),markov_step=step,positions=sample_pos.detach().clone(),idx=idx_map.detach().clone(),top_draft_ids=indices.detach().clone(),top_target_ids=self.model.map_draft_to_target(indices).detach().clone(),top_logits=values.detach().clone(),sampled=result.detach().clone())
            return result
        AscendDSparkSpeculator._sample_logits=sample_head
        verify=RejectionSampler._verify
        def verification(self,logits,draft_logits,draft_sampled,pos,cu_num_logits,idx_mapping,idx_mapping_np,expanded_idx_mapping,expanded_local_pos):
            result=verify(self,logits,draft_logits,draft_sampled,pos,cu_num_logits,idx_mapping,idx_mapping_np,expanded_idx_mapping,expanded_local_pos)
            import torch
            if not active_context.get('requests') or torch.npu.is_current_stream_capturing():return result
            values,indices=logits.float().topk(5,dim=-1)
            processed_values,processed_indices=result[0].topk(5,dim=-1)
            buffered('verify',context=active_context.copy(),idx=idx_mapping_np.tolist(),positions=pos.detach().clone(),cu=cu_num_logits.detach().clone(),draft=draft_sampled.detach().clone(),top_ids=indices.detach().clone(),top_logits=values.detach().clone(),processed_top_ids=processed_indices.detach().clone(),processed_top_logits=processed_values.detach().clone(),sampled=result[1].detach().clone(),num_sampled=result[2].detach().clone())
            return result
        RejectionSampler._verify=verification
        from vllm.v1.worker.gpu.sample.sampler import Sampler
        sample=Sampler.__call__
        def initial_sample(self,logits,input_batch):
            result=sample(self,logits,input_batch)
            import torch
            real=any(r.startswith(('cmpl-','chatcmpl-')) for r in input_batch.req_ids)
            if real and not torch.npu.is_current_stream_capturing():
                values,indices=logits.float().topk(5,dim=-1)
                buffered('initial_target',step=active_context.get('step'),mode=active_context.get('mode'),tp_rank=active_context.get('tp_rank'),requests=list(input_batch.req_ids),idx=input_batch.idx_mapping_np.tolist(),positions=input_batch.positions[input_batch.logits_indices].detach().clone(),top_ids=indices.detach().clone(),top_logits=values.detach().clone(),sampled=result.sampled_token_ids.detach().clone(),padded_tokens=input_batch.num_tokens_after_padding)
            return result
        Sampler.__call__=initial_sample
