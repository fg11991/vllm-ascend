#!/workspace/dspark_ctxwin_validation/runtime-tmp/bin/python
from vllm.entrypoints.cli.main import main
if __name__ == '__main__':
    main()
