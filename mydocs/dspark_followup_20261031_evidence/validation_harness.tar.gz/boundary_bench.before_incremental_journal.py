import asyncio,json,sys,time,math,hashlib
from pathlib import Path
import aiohttp
root=Path(__file__).parent;tag=sys.argv[1];window=int(sys.argv[2]);mode=sys.argv[3] if len(sys.argv)>3 else 'boundaries'
base=json.loads(Path('/workspace/dspark_ctxwin_validation/prompt_32768.json').read_text())
url='http://127.0.0.1:8873'
def prompt(n):
    assert 128<=n<=32768
    tail=min(256,n//2)
    return base[:n-tail]+base[-tail:]
async def request(session,name,n,limit,cancel_after=None,delay=0):
    await asyncio.sleep(delay)
    payload=dict(model='dspark-trained-followup',request_id=f'{tag}_{name}',prompt=prompt(n),max_tokens=limit,ignore_eos=True,temperature=0,top_p=1,seed=42,return_token_ids=True,stream=True,stream_options={'include_usage':True},logprobs=1)
    start=time.time();ids=[];usage=None;finish=None;rid=None
    async with session.post(url+'/v1/completions',json=payload) as response:
        if response.status!=200:raise RuntimeError((response.status,(await response.text())[:1000]))
        async for raw in response.content:
            line=raw.decode().strip()
            if not line.startswith('data:'):continue
            text=line[5:].strip()
            if text=='[DONE]':break
            data=json.loads(text)
            if data.get('error'):raise RuntimeError(data)
            rid=data.get('id',rid);usage=data.get('usage') or usage
            for choice in data.get('choices',[]):
                ids+=choice.get('token_ids') or []
                finish=choice.get('finish_reason') or finish
                for lp in (choice.get('logprobs') or {}).get('token_logprobs',[]):assert lp is None or math.isfinite(lp)
            if cancel_after is not None and len(ids)>=cancel_after:
                response.close();break
    if cancel_after is None:
        assert usage and len(ids)==usage['completion_tokens']==limit,(name,usage,len(ids),limit)
        assert usage['prompt_tokens']==n
    result=dict(name=name,request_id=rid,prompt_tokens=n,prompt_sha256=hashlib.sha256(json.dumps(payload['prompt']).encode()).hexdigest(),requested_output=limit,start=start,end=time.time(),output_ids=ids,usage=usage,finish=finish,expected_cancel=cancel_after is not None)
    print('BOUNDARY_REQUEST_DONE',name,len(ids),'cancel' if cancel_after else '',flush=True)
    return result
async def metrics(s):
    async with s.get(url+'/metrics') as response:return await response.text()
async def flush(s):
    data=dict(model='dspark-trained-followup',request_id=f'{tag}_flush_trace',prompt=[248044,100],max_tokens=1,temperature=0,seed=42)
    async with s.post(url+'/v1/completions',json=data) as response:
        response.raise_for_status();return await response.json()
async def main():
    rows=[]
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=2400),connector=aiohttp.TCPConnector(limit=40)) as s:
        before=await metrics(s)
        if mode=='boundaries':
            lengths=sorted(set([window+127,window+128,window+129,window+895,window+896,window+897,8191,8192,8193,32640]))
            for i in range(0,len(lengths),4):
                chunk=lengths[i:i+4]
                rows+=await asyncio.gather(*[request(s,f'edge_{n}',n,min(512,32768-n)) for n in chunk])
                await flush(s)
        elif mode=='reuse':
            rows.append(await request(s,'cancel_first',24576,6000,cancel_after=32))
            await asyncio.sleep(2)
            rows.append(await request(s,'after_cancel',1024,64))
            long_tasks=[asyncio.create_task(request(s,f'continuing_long_{i}',24576,6000,delay=i*0.5)) for i in range(2)]
            await asyncio.sleep(2)
            for wave in range(12):
                rows+=await asyncio.gather(*[request(s,f'short_wave{wave}_{i}',768+128*i,64,delay=i*0.25) for i in range(2)])
            rows+=await asyncio.gather(*long_tasks)
            await flush(s)
            for wave in range(3):
                rows+=await asyncio.gather(*[request(s,f'exit_reuse{wave}_{i}',4096+128*i,256) for i in range(4)])
                await flush(s)
        elif mode=='preemption':
            rows+=await asyncio.gather(*[request(s,f'grow_{i}',512,16000) for i in range(2)])
            await flush(s)
        elif mode=='memory32':
            for wave in range(2):
                rows+=await asyncio.gather(*[request(s,f'wave{wave}_request{i}',31744,1024) for i in range(32)])
                await flush(s)
                await asyncio.sleep(12)
        else:raise ValueError(mode)
        await asyncio.sleep(12)
        after=await metrics(s)
    path=root/'results'/f'{tag}_{mode}.json';assert not path.exists()
    path.write_text(json.dumps(dict(tag=tag,window=window,mode=mode,before=before,after=after,requests=rows)))
    print('BOUNDARY_DONE',str(path),flush=True)
asyncio.run(main())
