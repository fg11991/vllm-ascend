import json,itertools
from pathlib import Path
root=Path(__file__).parent
files=list((root/'results').glob('*_fixed_c*_r*.json'))
loaded={p.stem:json.loads(p.read_text()) for p in files}
def split(name):
    config,suffix=name.rsplit('_fixed_',1)
    c,r=suffix.split('_');return config,int(c[1:]),int(r[1:])
def compare(a,b):
    x,y=loaded[a],loaded[b]
    assert x['fixture_sha256']==y['fixture_sha256']
    rows=[]
    for u,v in zip(x['requests'],y['requests']):
        assert u['id']==v['id']
        aa,bb=u['output_ids'],v['output_ids']
        n=next((i for i,(p,q) in enumerate(zip(aa,bb)) if p!=q),min(len(aa),len(bb)))
        ea=next((i for i,t in enumerate(aa) if t in [248044,248046]),None);eb=next((i for i,t in enumerate(bb) if t in [248044,248046]),None)
        rows.append(dict(first_eos_a=ea,first_eos_b=eb,divergence_after_either_eos=(n>min(v for v in [ea,eb] if v is not None)) if ea is not None or eb is not None else False,id=u['id'],prompt_tokens=u['prompt_tokens'],equal=aa==bb,lcp=n,first_divergence_output_index=None if aa==bb else n,absolute_next_position=u['prompt_tokens']+n,token_a=aa[n] if n<len(aa) else None,token_b=bb[n] if n<len(bb) else None))
    return dict(a=a,b=b,exact=sum(x['equal'] for x in rows),count=len(rows),requests=rows)
comparisons=[]
for a,b in itertools.combinations(loaded,2):
    if loaded[a]['fixture_sha256']!=loaded[b]['fixture_sha256']:continue
    ca,na,ra=split(a);cb,nb,rb=split(b)
    if (ca==cb and na==nb) or (ca!=cb and na==nb and ra==rb):comparisons.append(compare(a,b))
(root/'fixed_comparisons.json').write_text(json.dumps(comparisons,indent=2))
for x in comparisons:print(x['a'],x['b'],f"{x['exact']}/{x['count']}",[r['lcp'] for r in x['requests']])
