"""Run boundary/reuse/memory phases after diagnostic traces have been checked."""
import json,time,requests
from pathlib import Path
import diagnostic_driver as d
root=Path(__file__).parent
assert any(json.loads(x)['event']=='diagnostic_matrix_complete' for x in (root/'diagnostic_progress.jsonl').read_text().splitlines())
try:
 for W,model in [(2048,'trained-window-2048')]:
  tag=f'boundary_isocache_trained_window_W{W}_reclaim8_pool384'
  d.start(tag,model=model,blocks=384)
  d.run('python3','boundary_bench.py',tag,str(W),'boundaries')
  d.analyze(tag,W)
  d.run('python3','boundary_bench.py',tag,str(W),'reuse')
  d.analyze(tag,W)
  d.record('boundary_reuse_completed',tag=tag)
 for variant,kind,diagnostics in [('baseline','readonly','pool'),('tmp','samegroups_full8','pool,keepfull'),('tmp','reclaim8','pool')]:
  tag=f'memory32_isocache_trained_window2048_{kind}'
  blocks=None
  if kind=='reclaim8':
   paired=json.loads((root/'results'/'memory32_isocache_trained_window2048_samegroups_full8_pool_summary.json').read_text())
   blocks=paired['config']['num_blocks']
  d.start(tag,variant=variant,diagnostics=diagnostics,maxseq=32,blocks=blocks)
  d.run(str(root/'run_agent_round.sh'),tag+'_warm','warm')
  d.run('python3','boundary_bench.py',tag,'2048','memory32')
  d.analyze(tag,maps=False)
  if kind=='reclaim8':
   actual=json.loads((root/'results'/f'{tag}_pool_summary.json').read_text())['config']
   assert actual['groups']==paired['config']['groups'] and actual['num_blocks']==paired['config']['num_blocks'], 'memory counterfactual layout differs'
   d.record('memory32_identical_group_layout_verified',tag=tag,num_blocks=actual['num_blocks'])
  d.record('memory32_completed',tag=tag)
 d.run('python3','analyze_memory32_tokens.py')
 d.record('boundary_matrix_complete')
 d.start('retained_isocache_trained_window2048_reclaim8_graph',diagnostics='')
 response=requests.post('http://127.0.0.1:8873/v1/chat/completions',json=dict(model='dspark-trained-followup',messages=[dict(role='user',content='用一句话说明你已准备好提供服务。')],max_tokens=32,temperature=0,seed=42,chat_template_kwargs={'enable_thinking':False}),timeout=180)
 response.raise_for_status();out=response.json();assert out['choices'][0]['message']['content']
 (root/'retained_service_health.json').write_text(json.dumps(dict(time=time.time(),health=requests.get('http://127.0.0.1:8873/health').status_code,response=out),ensure_ascii=False,indent=2))
 d.record('healthy_service_retained',url='http://127.0.0.1:8873',devices=[4,5,6,7])
except BaseException as e:
 d.record('boundary_failed',error=repr(e));raise
print('BOUNDARIES_FINISHED_HEALTHY_SERVICE_RETAINED',flush=True)
d.server.wait()
