"""Summarize completed waves only; preserve raw per-request evidence."""
import json,re,itertools,statistics,hashlib
from pathlib import Path
root=Path(__file__).parent
result=root/'results'
measures=['acceptance','mean_acceptance_length','mean_ttft_seconds','weighted_tpot_stream_end_seconds','wave_output_tokens_per_second','mean_prompt_tokens','mean_output_tokens']
def metric(text,name):
 return sum(float(line.rsplit(' ',1)[1]) for line in text.splitlines() if line.startswith(name+'{') or line.startswith(name+' '))
rows=[]
for p in sorted(result.glob('*.summary.json')):
 s=json.loads(p.read_text());name=p.stem
 if '_warm_' in name:continue
 if '_perf_' in name and '_steady_perf_' not in name:continue
 m=re.match(r'(.+)_perf_r(\d+)_(.+)_c(\d+)_(tool_call|final_answer)_',name)
 if m:
  config,round_id,dataset,c,task=m.groups();config=config.removesuffix('_steady');kind='performance'
 else:
  m=re.match(r'(.+)_r(\d+)_(tool_call|final_answer)_',name)
  if not m:continue
  config,round_id,task=m.groups();dataset='original_agent_50';c=4;kind='business'
 before=Path(s['path']+'.metrics.0.txt').read_text();after=Path(s['path']+'.metrics.1.txt').read_text()
 metric_names=['vllm:num_preemptions_total','vllm:request_queue_time_seconds_sum','vllm:request_queue_time_seconds_count','vllm:request_success_total']
 delta={name:metric(after,name)-metric(before,name) for name in metric_names}
 s['server_metric_deltas']=delta
 s['queue_seconds_mean']=delta['vllm:request_queue_time_seconds_sum']/delta['vllm:request_queue_time_seconds_count'] if delta['vllm:request_queue_time_seconds_count'] else None
 s['ending_running']=metric(after,'vllm:num_requests_running');s['ending_waiting']=metric(after,'vllm:num_requests_waiting')
 assert delta['vllm:request_queue_time_seconds_count']==s['valid'],(p,delta,s['valid'])
 rows.append(dict(config=config,round=int(round_id),dataset=dataset,concurrency=int(c),kind=kind,**s))
# All speed contrasts must use the same rendered inputs and exactly 512 outputs.
performance_inputs={}
for wave in rows:
 if wave['kind']!='performance':continue
 for item in map(json.loads,Path(wave['path']).read_text().splitlines()[1:]):
  assert item['completion_tokens']==512,(wave['path'],item['req_id'],item['completion_tokens'])
  key=(wave['dataset'],item['req_id']);digest=hashlib.sha256(json.dumps(item['prompt_token_ids']).encode()).hexdigest()
  previous=performance_inputs.setdefault(key,digest)
  assert previous==digest,('Performance input changed',key,wave['path'])
(root/'performance_input_invariants.json').write_text(json.dumps({'unique_inputs':len(performance_inputs),'completed_waves':sum(w['kind']=='performance' for w in rows),'rendered_input_tokens_match_across_config_round_and_concurrency':True,'all_outputs_512':True},indent=2))
groups=[]
for key,ss in itertools.groupby(sorted(rows,key=lambda x:(x['kind'],x['config'],x['dataset'],x['concurrency'],x['task'])),key=lambda x:(x['kind'],x['config'],x['dataset'],x['concurrency'],x['task'])):
 ss=list(ss);g=dict(zip(['kind','config','dataset','concurrency','task'],key),rounds=len(ss),round_ids=[s['round'] for s in ss],valid=sum(s['valid'] for s in ss),failures=sum(s['failures'] for s in ss))
 g['measurements']={k:dict(values=[s[k] for s in ss],mean=statistics.mean(s[k] for s in ss),median=statistics.median(s[k] for s in ss),minimum=min(s[k] for s in ss),maximum=max(s[k] for s in ss)) for k in measures}
 groups.append(g)
comparisons=[]
business=[r for r in rows if r['kind']=='business']
loaded={r['path']:{x['req_id']:x for x in map(json.loads,Path(r['path']).read_text().splitlines()[1:])} for r in business}
for a,b in itertools.combinations(business,2):
 if a['task']!=b['task']:continue
 aa,bb=loaded[a['path']],loaded[b['path']];assert aa.keys()==bb.keys()
 detail=[]
 for rid,u in aa.items():
  v=bb[rid];assert u['prompt_token_ids']==v['prompt_token_ids'],(a['path'],b['path'],rid)
  x,y=u['output_token_ids'],v['output_token_ids'];n=next((i for i,(q,w) in enumerate(zip(x,y)) if q!=w),min(len(x),len(y)))
  detail.append(dict(id=rid,equal=x==y,lcp=n,prompt_tokens=len(u['prompt_token_ids']),output_a=len(x),output_b=len(y),token_a=x[n] if n<len(x) else None,token_b=y[n] if n<len(y) else None))
 comparisons.append(dict(a=a['path'],b=b['path'],task=a['task'],exact=sum(x['equal'] for x in detail),count=len(detail),mean_lcp=statistics.mean(x['lcp'] for x in detail),requests=detail))
(root/'aggregate_results.json').write_text(json.dumps(dict(waves=rows,groups=groups),indent=2))
(root/'business_token_comparisons.json').write_text(json.dumps(comparisons,indent=2))
print('AGGREGATED',len(rows),'waves',len(groups),'groups',len(comparisons),'business token comparisons')
for g in groups:
 if g['kind']=='business':print(g['config'],g['task'],g['round_ids'],'acceptance',g['measurements']['acceptance']['values'],'mean length',g['measurements']['mean_acceptance_length']['values'])
