#!/workspace/dspark_ctxwin_validation/runtime-baseline/bin/python
import sys
sys.path.insert(0,"/workspace/dspark_ctxwin_validation/round_20261031")
from vllm.entrypoints.cli.main import main
from startup_audit import install
install()
if __name__ == '__main__':
    main()
