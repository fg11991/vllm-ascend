import os,sys,json,time,signal,subprocess,requests
from pathlib import Path
root=Path(__file__).parent
configs={
 'isocache_trained_window_2048_readonly_graph_s8':('baseline','trained-window-2048','full',8),
 'isocache_trained_window_2048_reclaim_graph_s8':('tmp','trained-window-2048','full',8),
 'isocache_trained_window_none_full_graph_s8':('tmp','trained-window-none','full',8),
 'isocache_trained_window_2048_reclaim_graph_s16':('tmp','trained-window-2048','full',16),
 'isocache_trained_full_none_baseline_graph_s8':('baseline','trained-full-none','full',8),
 'isocache_trained_full_none_current_graph_s8':('tmp','trained-full-none','full',8),
 'isocache_trained_full_2048_reclaim_graph_s8':('tmp','trained-full-2048','full',8),
 'isocache_trained_window_128_reclaim_graph_s8':('tmp','trained-window-128','full',8),
 'isocache_trained_window_2048_reclaim_eager_s8':('tmp','trained-window-2048','eager',8),
}
keys=list(configs);primary=keys[:4]
orders=[primary,[primary[3],primary[2],primary[1],primary[0]],[primary[1],primary[0],primary[3],primary[2]]]
plan=[]
for round_id,order in enumerate(orders,1):
 for name in order:
  plan.append(dict(name=name,round=round_id,performance=True,agent=(name!=primary[2] or round_id==1),fixed=(round_id==1 and name in [primary[0],primary[1],primary[3]])))
for name in keys[4:]:plan.append(dict(name=name,round=1,performance=False,agent=True,fixed=name==keys[-1]))
(root/'matrix_plan.json').write_text(json.dumps(dict(configs=configs,plan=plan),indent=2))
server=None

def state(event,job,**extra):
 row=dict(event=event,time=time.time(),job=job,**extra)
 with (root/'matrix_progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 print('MATRIX_PROGRESS',json.dumps(row),flush=True)

def stop_owned_server():
 owned=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   cmd=(p/'cmdline').read_bytes();env=(p/'environ').read_bytes().split(b'\0')
  except (OSError,ProcessLookupError):continue
  if b'/workspace/dspark_ctxwin_validation/runtime-' in cmd and b'--served-model-name\0dspark-trained-followup\0' in cmd:
   assert b'ASCEND_RT_VISIBLE_DEVICES=4,5,6,7' in env,(p,cmd)
   owned.append(int(p.name))
 if not owned:
  prior=[json.loads(line) for line in (root/'matrix_progress.jsonl').read_text().splitlines()]
  assert any(row['event']=='startup_superseded_cache_cwd' for row in prior) and not any(row['event']=='healthy' for row in prior),prior[-1:]
  state('initial_task_service_already_stopped',{})
  time.sleep(5)
  return
 assert len(owned)==1,owned
 pid=owned[0];state('stop_verified_owned_api',{},pid=pid)
 os.kill(pid,signal.SIGTERM)
 for _ in range(60):
  if not Path('/proc',str(pid)).exists():break
  time.sleep(1)
 else:raise RuntimeError(f'owned API {pid} did not exit; no broad process kill attempted')
 time.sleep(5)

def start(job):
 global server
 name=job['name'];variant,model,mode,width=configs[name]
 stop_owned_server()
 tag=f"{name}_visit{job['round']}_startup2"
 log=Path('/opt/w00958190/log')/f'dspark_20261031_{tag}_serve.log'
 assert not log.exists(),log
 env=os.environ.copy()
 for key in ['DSPARK_FOLLOWUP_DIAGNOSTICS','DSPARK_FOLLOWUP_ENTRY','DSPARK_FOLLOWUP_TAG','DSPARK_GPU_BLOCKS']:
  env.pop(key,None)
 env['DSPARK_CACHE_TAG']=name+'_fully_isolated'
 server=subprocess.Popen([str(root/'serve.sh'),variant,model,mode,str(width),tag],env=env,start_new_session=True)
 state('starting',job,pid=server.pid,log=str(log))
 for i in range(240):
  if server.poll() is not None:raise RuntimeError(f'service exited {server.returncode}: {log}')
  try:
   if requests.get('http://127.0.0.1:8873/health',timeout=3).status_code==200:break
  except requests.RequestException:pass
  time.sleep(5)
 else:raise RuntimeError(f'service startup timeout: {log}')
 state('healthy',job)

def run(cmd):subprocess.run(cmd,cwd=root,check=True)
try:
 for job in plan:
  start(job)
  name=job['name'];round_id=job['round']
  run([str(root/'run_agent_round.sh'),f'{name}_visit{round_id}_warm','warm'])
  if job['agent']:run([str(root/'run_agent_round.sh'),f'{name}_r{round_id}','formal'])
  if job['performance']:run(['python3','-u',str(root/'run_performance.py'),name,str(round_id)])
  if job['fixed']:run(['python3','-u',str(root/'fixed_token_bench.py'),name])
  if job['fixed']:run(['python3','-u',str(root/'archive_token_bench.py'),name])
  state('completed',job)
 state('matrix_complete',{})
except BaseException as e:
 state('failed',job if 'job' in globals() else {},error=repr(e))
 raise
# Keep the final healthy service in this foreground session for the next phase.
print('MATRIX_FINISHED_SERVICE_RETAINED',flush=True)
server.wait()
