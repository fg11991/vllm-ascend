"""Compare only the first decision after identical, fully re-prefilled prefixes."""
import json,itertools,statistics,re
from pathlib import Path
root=Path(__file__).parent
rows=[]
for p in sorted((root/'results').glob('*_prefix_replay_c*_r*.json')):
 m=re.fullmatch(r'(.+)_prefix_replay_c(\d+)_r(\d+)\.json',p.name)
 if not m:continue
 tag,c,r=m.groups()
 for x in json.loads(p.read_text()):
  choice=x['response']['choices'][0];tokens=choice['token_ids'];log=choice['logprobs']
  rows.append(dict(tag=tag,concurrency=int(c),repeat=int(r),case=x['case'],prefix_length=x['prefix_length'],first_token=tokens[0],output_ids=tokens,top_logprobs=log['top_logprobs'][0],selected_logprob=log['token_logprobs'][0],server_request_id=x['response']['id'],source=str(p)))
comparisons=[]
for a,b in itertools.combinations(rows,2):
 if a['case']!=b['case'] or a['concurrency']!=b['concurrency']:continue
 if a['tag']!=b['tag'] and a['repeat']!=b['repeat']:continue
 assert a['prefix_length']==b['prefix_length']
 common=a['top_logprobs'].keys() & b['top_logprobs'].keys()
 comparisons.append(dict(case=a['case'],prefix_length=a['prefix_length'],concurrency=a['concurrency'],tag_a=a['tag'],tag_b=b['tag'],repeat_a=a['repeat'],repeat_b=b['repeat'],first_token_equal=a['first_token']==b['first_token'],first_token_a=a['first_token'],first_token_b=b['first_token'],top_candidates_equal=set(a['top_logprobs'])==set(b['top_logprobs']),common_candidates=len(common),max_common_logprob_difference=max((abs(a['top_logprobs'][t]-b['top_logprobs'][t]) for t in common),default=None)))
result=dict(rows=rows,comparisons=comparisons,note='Only token 0 is a controlled identical prefix across all comparisons. Later tokens are retained but not compared as if their prefixes were unchanged. This re-prefill path differs from the original incremental decode path.')
(root/'replay_comparisons.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('REPLAY_ANALYZED',len(rows),'decisions',len(comparisons),'pairs')
