import os,signal,time,json,subprocess
from pathlib import Path
root=Path(__file__).parent
pid=334959
while Path('/proc',str(pid)).exists():
 state=Path('/proc',str(pid),'stat').read_text().split(') ',1)[1].split()[0]
 if state=='Z':break
 time.sleep(2)
name='isocache_trained_window_2048_reclaim_graph_s16'
for task in ['tool_call','final_answer']:
 subprocess.run(['python3','check_agent.py',name+'_r2',task,'formal'],cwd=root,check=True)
p=Path('/proc/252236');assert b'matrix_driver.py' in (p/'cmdline').read_bytes()
os.kill(252236,signal.SIGTERM);os.kill(252236,signal.SIGCONT)
subprocess.run(['python3','-u','run_performance.py',name,'2'],cwd=root,check=True)
job=dict(name=name,round=2,performance=True,agent=True,fixed=False)
with (root/'matrix_progress.jsonl').open('a') as f:
 for event in ['completed','matrix_complete']:
  row=dict(event=event,time=time.time(),job=job if event=='completed' else {},scope='user_reduced_20261031',note='Only four first-round configs plus size16 round2 completed; original full matrix deferred by user.')
  f.write(json.dumps(row)+'\n');print('REDUCED_MATRIX_PROGRESS',json.dumps(row),flush=True)
print('Current round finished; supervisor may start reduced diagnosis. Healthy service retained.',flush=True)
