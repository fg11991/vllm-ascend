import json,subprocess,tempfile,shutil
from pathlib import Path
root=Path(__file__).parent;tmp=Path(tempfile.mkdtemp(prefix='ownership-cpu-',dir=root));(tmp/'results').mkdir();shutil.copy2(root/'analyze_ownership.py',tmp/'analyze_ownership.py')
base=[dict(kind='config',time=0,groups=[dict(block_size=896)]),dict(kind='allocate',time=1,ids=[5],context=dict(request='a',group=0)),dict(kind='free',time=2,after=[[5,0]],context=dict(request='a',group=0,method='free')),dict(kind='finished',time=2.1,request='a',status='FINISHED_LENGTH_CAPPED',inflight=8),dict(kind='draft',time=3,capture_time=2.2,pid=999999,step=1,requests=['a'],starts=[0],window_tables={'0':[[35]]},window_lengths=[1],kernel_blocks={'0':128},query_start_loc=[0,1],context_slots=[[4480]],query_slots={'0':[4480]*7})]
results=[]
for case in ['terminal','window_free','reallocated','not_finished']:
 events=json.loads(json.dumps(base))
 if case=='window_free':events[2]['context']['method']='remove_skipped_blocks'
 if case=='reallocated':events.insert(-1,dict(kind='allocate',time=2.15,ids=[5],context=dict(request='b',group=0)))
 if case=='not_finished':events=[x for x in events if x['kind']!='finished']
 tag='synthetic_'+tmp.name+'_'+case;p=Path('/opt/w00958190/log')/f'dspark_20261031_diag_{tag}_999999.jsonl';p.write_text('\n'.join(json.dumps(e) for e in events)+'\n')
 run=subprocess.run(['python3',str(tmp/'analyze_ownership.py'),tag],capture_output=True,text=True)
 expected=0 if case=='terminal' else 1
 assert run.returncode==expected,(case,run.stdout,run.stderr)
 results.append(dict(case=case,expected_exit=expected,actual_exit=run.returncode))
(root/'ownership_analysis_selftest.json').write_text(json.dumps(dict(kind='Synthetic CPU analysis, not NPU test',directory=str(tmp),cases=results,passed=True),indent=2));print('OWNERSHIP_ANALYSIS_REGRESSION_PASS',results)
