"""Audit the first target decision of each identical-prefix replay."""
import json,sys
from pathlib import Path
root=Path(__file__).parent;tag=sys.argv[1]
cases=json.loads((root/'divergence_prefixes.json').read_text())
frames={};trace_path=None
for p in sorted(Path('/opt/w00958190/log').glob(f'dspark_20261031_diag_{tag}_*.jsonl'),key=lambda p:int(p.stem.rsplit('_',1)[1])):
 frames={}
 for line in p.open():
  e=json.loads(line)
  if e['kind'] not in ['target_shape','draft','initial_target','verify']:continue
  step=e.get('step',e.get('context',{}).get('step'))
  frame=frames.setdefault(step,{})
  if e['kind']=='verify':frame.setdefault('verify',[]).append(e)
  else:frame[e['kind']]=e
 if frames:
  ranks={f['target_shape'].get('tp_rank',0 if tag.startswith('synthetic_') else None) for f in frames.values() if 'target_shape' in f}
  if ranks=={0}:trace_path=str(p);break
  frames={}
assert frames,tag
rows=[]
for concurrency in [1,4]:
 for repeat in range(1,4):
  replay=json.loads((root/'results'/f'{tag}_prefix_replay_c{concurrency}_r{repeat}.json').read_text())
  client={x['case']:x for x in replay}
  for case in cases:
   key=f"replay_{tag}_c{concurrency}_r{repeat}_{case['id']}";prefix=case['prefix_tokens'];history=[];decisions=[];observed={};mismatches=[]
   for step,f in sorted(frames.items()):
    shape=f.get('target_shape');draft=f.get('draft');initial=f.get('initial_target')
    if not shape:continue
    indices=[i for i,rid in enumerate(shape['requests']) if key in rid]
    if not indices:continue
    assert len(indices)==1
    i=indices[0]
    if shape['computed'][i]>=len(prefix):continue
    history.append(dict(step=step,computed=shape['computed'][i],scheduled=shape['scheduled'][i],padded_tokens=shape['padded_tokens'],tokens=shape['tokens'],batch_requests=shape['num_reqs'] if 'num_reqs' in shape else len(shape['requests']),mode=shape['mode']))
    if draft:
     lo,hi=draft['query_start_loc'][i:i+2]
     for pos,token in zip(draft['target_positions'][lo:hi],draft['target_input_ids'][lo:hi]):
      if 0<=pos<len(prefix):
       observed[pos]=token
       if token!=prefix[pos]:mismatches.append(dict(step=step,position=pos,actual=token,expected=prefix[pos]))
    if initial:
     for j,rid in enumerate(initial['requests']):
      if key in rid and initial['positions'][j]==len(prefix)-1:
       decisions.append(dict(step=step,top_ids=initial['top_ids'][j],top_logits=initial['top_logits'][j],margin=initial['top_logits'][j][0]-initial['top_logits'][j][1],sampled=initial['sampled'][j],padded_tokens=initial['padded_tokens'],mode=initial['mode']))
    for verification in f.get('verify',[]):
     state_idx=shape['idx'][i]
     if state_idx not in verification['idx']:continue
     vi=verification['idx'].index(state_idx)
     lo,hi=verification['cu'][vi:vi+2]
     for j in range(lo,hi):
      if verification['positions'][j]!=len(prefix)-1:continue
      decisions.append(dict(step=step,source='mixed_batch_rejection_sampler',top_ids=verification['top_ids'][j],top_logits=verification['top_logits'][j],margin=verification['top_logits'][j][0]-verification['top_logits'][j][1],processed_top_ids=verification.get('processed_top_ids',[[]]*len(verification['positions']))[j],processed_top_logits=verification.get('processed_top_logits',[[]]*len(verification['positions']))[j],sampled=verification['sampled'][vi],num_sampled=verification['num_sampled'][vi],padded_tokens=shape['padded_tokens'],mode=shape['mode']))
   rows.append(dict(case=case['id'],concurrency=concurrency,repeat=repeat,prefix_length=len(prefix),client=client[case['id']],prefill_history=history,covered_prefix_positions=len(observed),complete_prefix_coverage=len(observed)==len(prefix),input_mismatches=mismatches,first_target_decisions=decisions))
path=root/'results'/f'{tag}_prefix_trace_audit.json'
path.write_text(json.dumps(dict(trace=trace_path,tag=tag,rows=rows,note='Only first target decision at the end of the identical re-prefilled prefix. Different from replaying an incremental GDN state; no per-operator root cause claim.'),indent=2))
print('PREFIX_TRACE_AUDIT',tag,'cases',len(rows),'with_target',sum(bool(x['first_target_decisions']) for x in rows),'complete_input',sum(x['complete_prefix_coverage'] for x in rows),'mismatches',sum(len(x['input_mismatches']) for x in rows))
