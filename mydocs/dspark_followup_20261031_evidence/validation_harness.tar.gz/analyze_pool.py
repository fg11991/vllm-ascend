"""Read-only analysis of isolated BlockPool events, with explicit invariants."""
import json,sys,statistics,collections
from pathlib import Path
root=Path(__file__).parent;tag=sys.argv[1]
paths=sorted(Path('/opt/w00958190/log').glob(f'dspark_20261031_diag_{tag}_*.jsonl'))
assert paths,tag
counts=collections.Counter();violations=[];config=None;owners={};freed={};active=set();reuses=[];snapshots=[];skips=[];finished=[];preemptions=[];last_pool_count=None;latest_output={};maximum_output={}
def fail(kind,**kw):
 if len(violations)<100:violations.append(dict(kind=kind,**kw))
# CPU pool events live in the sole scheduler process. Worker traces are analyzed separately.
for path in paths:
 for line in path.open():
  e=json.loads(line);kind=e['kind'];counts[kind]+=1
  if kind=='config':
   assert config is None or config['groups']==e['groups'];config=e
  elif kind=='allocate':
   last_pool_count=dict(time=e['time'],free=e['free'])
   ctx=e.get('context') or {};who=(ctx.get('request'),ctx.get('group'))
   for bid in e['ids']:
    if bid in owners:fail('allocated_live_id',block=bid,old=owners[bid],new=who)
    if bid in freed:
     old=freed[bid];oldctx=old.get('context') or {}
     if oldctx.get('request')!=who[0]:
      reuses.append(dict(block=bid,old_request=oldctx.get('request'),new_request=who[0],old_group=oldctx.get('group'),new_group=who[1],old_free_method=oldctx.get('method'),old_still_running=oldctx.get('request') in active,old_output_at_reuse=latest_output.get(oldctx.get('request')),free_time=old['time'],allocate_time=e['time']))
    owners[bid]=who
  elif kind=='free':
   last_pool_count=dict(time=e['time'],free=e['free'])
   for bid,ref in e['after']:
    if ref==0:
     owners.pop(bid,None);freed[bid]=e
  elif kind in ['scheduler','finished']:
   if e['free']+len(e['live'])+1!=e['total']:fail('pool_conservation',time=e['time'],free=e['free'],live=len(e['live']),total=e['total'])
   if kind=='finished':
    finished.append(e);active.discard(e['request']);maximum_output[e['request']]=max(maximum_output.get(e['request'],0),e.get('output',0));continue
   active={r['id'] for r in e['requests']}
   for r in e['requests']:
    latest_output[r['id']]=r['output'];maximum_output[r['id']]=max(maximum_output.get(r['id'],0),r['output'])
   groups=config['groups'];null=config['null_id'];pergroup=[0]*len(groups);ids=[];swa_nulls=[0]*len(groups)
   for r in e['requests']:
    for i,table in enumerate(r['tables']):
     live=[v for v in table if v!=null];pergroup[i]+=len(live);ids+=live
     if 'SlidingWindow' in groups[i]['spec']:swa_nulls[i]+=len(table)-len(live)
   if len(ids)!=len(set(ids)):fail('duplicate_request_block',time=e['time'])
   # Deferred frees / preempted in-flight requests can remain in the pool but not self.running.
   extra=set(e['live'])-set(ids)
   missing=set(ids)-set(e['live'])
   if missing:fail('table_refers_unowned_block',time=e['time'],ids=sorted(missing))
   slot=max(sum(g['pages']) for g in groups)
   effective=sum(n*sum(g['pages']) for n,g in zip(pergroup,groups))
   held=len(ids)*slot
   reclaimed_slots=sum(swa_nulls)*slot
   reclaimed_layers=sum(n*sum(g['pages']) for n,g in zip(swa_nulls,groups))
   stable=bool(e['requests']) and all(r['computed']-r['inflight']>=r['prompt'] and r['output']>0 for r in e['requests'])
   snapshots.append(dict(time=e['time'],running=len(e['requests']),stable=stable,free=e['free'],pool_live=len(e['live']),request_blocks=len(ids),unattributed_deferred_blocks=len(extra),per_group=pergroup,pool_bytes=len(e['live'])*slot,held_bytes=held,effective_layer_pages_bytes=effective,group_empty_bytes=held-effective,swa_null_columns=sum(swa_nulls),same_group_full_counterfactual_bytes=held+reclaimed_slots,reclaimed_swa_slot_bytes=reclaimed_slots,reclaimed_swa_layer_pages_bytes=reclaimed_layers,reclaimed_swa_empty_bytes=reclaimed_slots-reclaimed_layers,min_output=min((r['output'] for r in e['requests']),default=0),max_output=max((r['output'] for r in e['requests']),default=0),max_inflight=max((r['inflight'] for r in e['requests']),default=0)))
  elif kind=='skip_boundary':
   before=e['before'];after=e['after'];dropped=[(i,b) for i,(b,c) in enumerate(zip(before,after)) if b!=0 and c==0]
   for i,b in dropped:
    if (i+1)*e['block_size']>max(0,e['computed']-e['retention']+1):fail('released_past_retention',request=e['request'],column=i,computed=e['computed'])
   if dropped:skips.append(dict(time=e['time'],request=e['request'],computed=e['computed'],retention=e['retention'],count=len(dropped),ids=[b for i,b in dropped]))
  elif kind=='preempt_before':preemptions.append(e)
assert config is not None,'no scheduler config'
steady={}
for n in sorted({s['running'] for s in snapshots if s['stable']}):
 ss=[s for s in snapshots if s['stable'] and s['running']==n]
 steady[n]=dict(samples=len(ss),**{key:dict(min=min(s[key] for s in ss),median=statistics.median(s[key] for s in ss),max=max(s[key] for s in ss)) for key in ['pool_bytes','held_bytes','effective_layer_pages_bytes','group_empty_bytes','unattributed_deferred_blocks','same_group_full_counterfactual_bytes','reclaimed_swa_slot_bytes','reclaimed_swa_layer_pages_bytes','reclaimed_swa_empty_bytes']})
for r in reuses:r['old_continued_after_reuse']=r['old_output_at_reuse'] is not None and maximum_output.get(r['old_request'],0)>r['old_output_at_reuse']
summary=dict(last_pool_count=last_pool_count,peak_pool_bytes=max((s['pool_bytes'] for s in snapshots),default=0),minimum_free_blocks=min((s['free'] for s in snapshots),default=None),scheduler_snapshots=len(snapshots),tag=tag,config=config,event_counts=dict(counts),violations=violations,preemptions=preemptions,skip_events=len(skips),released_by_window=sum(s['count'] for s in skips),cross_request_reuses=sum(r['old_request'] is not None and r['new_request'] is not None for r in reuses),window_reuses_with_old_continuing=sum(r['old_free_method']=='remove_skipped_blocks' and r['old_still_running'] and r['old_continued_after_reuse'] and r['old_request'] is not None and r['new_request'] is not None for r in reuses),window_reuses_while_old_running=sum(r['old_free_method']=='remove_skipped_blocks' and r['old_still_running'] and r['old_request'] is not None and r['new_request'] is not None for r in reuses),steady=steady,final_finished=finished[-1] if finished else None,max_inflight=max((s['max_inflight'] for s in snapshots),default=0))
(root/'results'/f'{tag}_pool_summary.json').write_text(json.dumps(summary,indent=2))
(root/'results'/f'{tag}_pool_evidence.json').write_text(json.dumps(dict(snapshots=snapshots,reuses=reuses,skips=skips,finished=finished),indent=2))
print(json.dumps({k:v for k,v in summary.items() if k not in ['config','steady','final_finished']},indent=2))
assert not violations,violations[:3]
