#!/usr/bin/env bash
set -euo pipefail
variant="$1"
model="$2"
mode="$3"
width="$4"
tag="$5"
root=/workspace/dspark_ctxwin_validation/round_20261031_isolated
export ASCEND_RT_VISIBLE_DEVICES=4,5,6,7
export VLLM_USE_V2_MODEL_RUNNER=1
export VLLM_ASCEND_ENABLE_DSPARK_FIA_SINK=2
export VLLM_ASCEND_KV_GROUP_MIN_SIZE="$width"
export VLLM_CACHE_ROOT="$root/cache-${DSPARK_CACHE_TAG:-$tag}"
export TRITON_CACHE_DIR="$VLLM_CACHE_ROOT/triton"
export TORCHINDUCTOR_CACHE_DIR="$VLLM_CACHE_ROOT/inductor"
export TORCH_EXTENSIONS_DIR="$VLLM_CACHE_ROOT/torch_extensions"
export ASCEND_CACHE_PATH="$VLLM_CACHE_ROOT/ascend"
export TORCHAIR_CACHE_HOME="$VLLM_CACHE_ROOT/torchair"
export OMP_NUM_THREADS=1
mkdir -p "$TRITON_CACHE_DIR" "$TORCHINDUCTOR_CACHE_DIR" "$TORCH_EXTENSIONS_DIR" "$ASCEND_CACHE_PATH" "$TORCHAIR_CACHE_HOME" "$VLLM_CACHE_ROOT/runtime"
export PYTHONPATH="/opt/w00958190/flash-attention-npu:${PYTHONPATH:-}"
export LD_LIBRARY_PATH="/opt/w00958190/vllm-ascend/vllm_ascend/lib64:${LD_LIBRARY_PATH:-}"
cd "$VLLM_CACHE_ROOT/runtime"
args=()
extra=()
if [ -n "${DSPARK_GPU_BLOCKS:-}" ]; then extra+=(--num-gpu-blocks-override "$DSPARK_GPU_BLOCKS"); fi
captures='[8,16,24,32,40,48,56,64]'
if [ "${6:-8}" -gt 8 ]; then captures='[8,16,32,64,128,256]'; fi
if [[ "$mode" == eager ]]; then args+=(--enforce-eager); else args+=(--compilation-config "{\"cudagraph_mode\":\"FULL\",\"cudagraph_capture_sizes\":$captures}"); fi
/workspace/dspark_ctxwin_validation/runtime-"$variant"/bin/"${DSPARK_FOLLOWUP_ENTRY:-vllm}" serve /opt/models/Qwen3.8-27B \
 --served-model-name dspark-trained-followup --host 127.0.0.1 --port 8873 \
 --dtype bfloat16 --seed 42 --max-model-len 32768 --max-num-seqs "${6:-8}" --max-num-batched-tokens 8192 \
 --tensor-parallel-size 4 --gpu-memory-utilization 0.9 --trust-remote-code \
 --no-enable-prefix-caching --async-scheduling \
 --tool-call-parser qwen3_coder --enable-auto-tool-choice --reasoning-parser qwen3 \
 --default-chat-template-kwargs '{"enable_thinking":false}' \
 --speculative-config "{\"num_speculative_tokens\":7,\"method\":\"dspark\",\"model\":\"$root/models/$model\"}" \
 "${args[@]}" "${extra[@]}" 2>&1 | tee "/opt/w00958190/log/dspark_20261031_${tag}_serve.log"
