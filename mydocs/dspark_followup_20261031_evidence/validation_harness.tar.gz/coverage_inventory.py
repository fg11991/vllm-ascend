"""Count completed artifacts against the explicit validation matrix."""
import json
from pathlib import Path
root=Path(__file__).parent
plan=json.loads((root/'matrix_plan.json').read_text())['plan'];rows=[]
for job in plan:
 name=job['name'];r=job['round'];done={}
 if job['agent']:
  for task in ['tool_call','final_answer']:
   files=list((root/'results').glob(f'{name}_r{r}_{task}_*.summary.json'));assert len(files)<=1
   done[task]=json.loads(files[0].read_text())['valid'] if files else 0
 if job['performance']:
  files=list((root/'results').glob(f'{name}_steady_perf_r{r}_*.summary.json'))
  done['steady_conditions']=len(files);done['performance_requests']=sum(json.loads(p.read_text())['valid'] for p in files)
 if job['fixed']:
  done['fixed_waves']=len(list((root/'results').glob(f'{name}_fixed_c*_r*.json')))
  done['archive_waves']=len(list((root/'results').glob(f'{name}_archive_fixed_c*_r*.json')))
 rows.append(dict(job=job,completed=done))
summary=dict(business_requests=sum(x['completed'].get('tool_call',0)+x['completed'].get('final_answer',0) for x in rows),business_expected=sum(j['agent'] for j in plan)*100,steady_conditions=sum(x['completed'].get('steady_conditions',0) for x in rows),steady_expected=sum(j['performance'] for j in plan)*6,fixed_waves=sum(x['completed'].get('fixed_waves',0)+x['completed'].get('archive_waves',0) for x in rows),fixed_expected=sum(j['fixed'] for j in plan)*12)
if (root/'scope_reduction.json').exists():
 summary['original_expected']=dict(business_requests=summary['business_expected'],steady_conditions=summary['steady_expected'],fixed_waves=summary['fixed_expected'])
 summary.update(business_expected=500,steady_expected=30,fixed_expected=36,scope='user_reduced_20261031; diagnostic/reuse/memory phases counted separately')
 for i,row in enumerate(rows):row['deferred_by_user']=i>=5
(root/'coverage_inventory.json').write_text(json.dumps(dict(summary=summary,jobs=rows),indent=2));print(json.dumps(summary))
