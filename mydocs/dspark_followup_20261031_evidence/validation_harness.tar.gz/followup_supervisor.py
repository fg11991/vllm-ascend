"""Foreground supervisor: wait for clean phase completion, halt on any failure."""
import json,time,subprocess
from pathlib import Path
root=Path(__file__).parent

def events(name):
 p=root/name
 if not p.exists():return []
 lines=p.read_text().splitlines();rows=[]
 for line in lines:
  try:rows.append(json.loads(line))
  except json.JSONDecodeError:pass # another process may be appending its last line
 return rows

def wait_phase(filename,complete,failed,child=None):
 while True:
  rows=events(filename)
  if any(r['event']==complete for r in rows):return
  errors=[r for r in rows if r['event'] in failed]
  if errors:raise RuntimeError(errors[-1])
  if child is not None and child.poll() is not None:raise RuntimeError(f'Phase exited {child.returncode} before {complete}')
  time.sleep(5)

print('WAITING_FOR_NO_PROBE_MATRIX; no inference requests will be issued meanwhile',flush=True)
wait_phase('matrix_progress.jsonl','matrix_complete',['failed'])
print('STARTING_ISOLATED_DIAGNOSTIC_PHASE',flush=True)
diagnostic=subprocess.Popen(['python3','-u','diagnostic_driver.py'],cwd=root)
wait_phase('diagnostic_progress.jsonl','diagnostic_matrix_complete',['failed'],diagnostic)
print('STARTING_BOUNDARY_REUSE_MEMORY_PHASE',flush=True)
boundary=subprocess.Popen(['python3','-u','boundary_driver.py'],cwd=root)
wait_phase('diagnostic_progress.jsonl','healthy_service_retained',['boundary_failed'],boundary)
print('ALL_DEVICE_PHASES_FINISHED; final healthy service remains in foreground',flush=True)
boundary.wait()
