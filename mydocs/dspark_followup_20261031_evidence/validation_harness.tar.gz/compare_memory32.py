"""Compare actual held pool slots, stratifying equal target/GDN page allocations."""
import json,statistics,collections,csv
from pathlib import Path
root=Path(__file__).parent;GiB=2**30
names=['readonly','samegroups_full8','reclaim8'];data={}
def dist(values):
 return dict(samples=len(values),min=min(values),median=statistics.median(values),max=max(values))
for name in names:
 tag='memory32_isocache_trained_window2048_'+name
 summary=json.loads((root/'results'/f'{tag}_pool_summary.json').read_text())
 evidence=json.loads((root/'results'/f'{tag}_pool_evidence.json').read_text())
 client=json.loads((root/'results'/f'{tag}_memory32.json').read_text())
 assert not summary['violations'] and not summary['preemptions']
 assert len(client['requests'])==64 and all(len(x['output_ids'])==1024 and x['prompt_tokens']==31744 for x in client['requests'])
 assert summary['last_pool_count']['free']==summary['config']['num_blocks']-1
 groups=summary['config']['groups'];indexed=collections.defaultdict(list);steady=[];waves={}
 for x in evidence['snapshots']:
  if not(x['stable'] and x['running']==32):continue
  assert not x['unattributed_deferred_blocks']
  target_pages=sum(n*sum(layer.startswith('language_model.') for layer in g['layers']) for n,g in zip(x['per_group'],groups) if g['spec']=='FullAttentionSpec')
  gdn_pages=sum(n*len(g['layers']) for n,g in zip(x['per_group'],groups) if g['spec']=='MambaSpec')
  assert target_pages%16==0
  key=(target_pages//16,gdn_pages)
  x=dict(x,allocation_state=key);indexed[key].append(x);steady.append(x)
 assert steady,'no all-prefilled simultaneous32 observations'
 for w in [0,1]:
  rr=[x for x in client['requests'] if x['name'].startswith(f'wave{w}_')];a=min(x['start'] for x in rr);b=max(x['end'] for x in rr)
  ss=[x for x in steady if a<=x['time']<=b];assert ss
  waves[str(w)]=dict(start=a,end=b,stable_samples=len(ss),**{k.removesuffix('_bytes')+'_GiB':dist([x[k]/GiB for x in ss]) for k in ['held_bytes','effective_layer_pages_bytes','group_empty_bytes']})
 data[name]=dict(tag=tag,summary=summary,indexed=indexed,steady=steady,waves=waves,memory_window_releases=sum(x['count'] for x in evidence['skips'] if tag+'_wave' in x['request']))
assert data['samegroups_full8']['summary']['config']['groups']==data['reclaim8']['summary']['config']['groups']
assert data['samegroups_full8']['summary']['config']['num_blocks']==data['reclaim8']['summary']['config']['num_blocks']
common=sorted(set.intersection(*(set(data[n]['indexed']) for n in names)));assert common
states=[]
for key in common:
 stats={name:{field.removesuffix('_bytes')+'_GiB':dist([x[field]/GiB for x in data[name]['indexed'][key]]) for field in ['held_bytes','effective_layer_pages_bytes','group_empty_bytes']} for name in names}
 # Counterfactual values are checked against a real same-group full-retention run.
 full={x['held_bytes'] for x in data['samegroups_full8']['indexed'][key]}
 cf={x['same_group_full_counterfactual_bytes'] for x in data['reclaim8']['indexed'][key]}
 assert full==cf,(key,full,cf)
 assert len(full)==1
 baseline={x['held_bytes'] for x in data['readonly']['indexed'][key]};assert len(baseline)==1
 b=next(iter(baseline));f=next(iter(full));rr=data['reclaim8']['indexed'][key]
 assert all(x['held_bytes']==x['effective_layer_pages_bytes']+x['group_empty_bytes'] for x in rr)
 assert all(len({x[field] for x in data['readonly']['indexed'][key]})==1 for field in ['effective_layer_pages_bytes','group_empty_bytes'])
 states.append(dict(target_full_columns=key[0],gdn_layer_pages=key[1],groups=stats,layout_only_saving_GiB=(b-f)/GiB,reclaim_at_same_layout_saving_GiB=dist([(f-x['held_bytes'])/GiB for x in rr]),net_saving_GiB=dist([(b-x['held_bytes'])/GiB for x in rr]),effective_page_saving_GiB=dist([(next(iter(data['readonly']['indexed'][key]))['effective_layer_pages_bytes']-x['effective_layer_pages_bytes'])/GiB for x in rr]),group_empty_saving_GiB=dist([(next(iter(data['readonly']['indexed'][key]))['group_empty_bytes']-x['group_empty_bytes'])/GiB for x in rr])))
result=dict(input_tokens=31744,output_tokens=1024,concurrency=32,waves_per_configuration=2,configurations={n:dict(tag=d['tag'],num_blocks=d['summary']['config']['num_blocks'],groups=d['summary']['config']['groups'],last_pool_count=d['summary']['last_pool_count'],released_by_window_service_total=d['summary']['released_by_window'],released_by_window_memory_requests=d['memory_window_releases'],steady32=d['summary']['steady']['32'],waves=d['waves']) for n,d in data.items()},matched_states=states,largest_common_state=states[-1],notes=['All bytes are per TP rank/card; pool slots remain reserved by process.','Steady means32 simultaneously running, all prefill complete after subtracting inflight, each already emitted output.','Min/median/max over scheduler observations are descriptive, not independent repeats or confidence intervals.','Allocation states match target FullAttention columns and GDN layer pages across actual runs; output trajectories can differ.','Same-layout full retention also removes SWA admission cap, so this is not a fully identical admission policy.'])
(root/'results'/'memory32_comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(common_states=len(states),largest_common_state=states[-1]),indent=2))
