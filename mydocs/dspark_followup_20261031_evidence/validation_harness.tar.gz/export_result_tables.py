"""Regenerate read-only report tables from completed wave evidence."""
import json,csv,subprocess,statistics
from collections import Counter
from pathlib import Path
root=Path(__file__).parent
subprocess.run(['python3',str(root/'aggregate_results.py')],check=True,cwd=root,capture_output=True,text=True)
a=json.loads((root/'aggregate_results.json').read_text())
paths=[x['path'] for x in a['waves'] if x['kind']=='business']
subprocess.run(['python3',str(root/'analyze_business.py'),*paths],check=True,cwd=root,capture_output=True,text=True)
labels={
 'isocache_trained_window_2048_readonly_graph_s8':('窗口增训','2048/128','否','21×1 Full +16×3 GDN','图','4a01608da'),
 'isocache_trained_window_2048_reclaim_graph_s8':('窗口增训','2048/128','是','8×2 Full +5×1 SWA +8×6 GDN；槽宽8','图','ed48548e8'),
 'isocache_trained_window_2048_reclaim_graph_s16':('窗口增训','2048/128','是','16×1 Full +5×1 SWA +16×3 GDN；槽宽16','图','ed48548e8'),
 'isocache_trained_window_none_full_graph_s8':('窗口增训','关闭','否','21×1 Full +16×3 GDN','图','ed48548e8'),
 'isocache_trained_full_none_baseline_graph_s8':('不开窗增训','关闭','否','待逐配置启动日志确认','图','4a01608da'),
 'isocache_trained_full_none_current_graph_s8':('不开窗增训','关闭','否','待逐配置启动日志确认','图','ed48548e8'),
 'isocache_trained_full_2048_reclaim_graph_s8':('不开窗增训','2048/128','是','待逐配置启动日志确认','图','ed48548e8'),
 'isocache_trained_window_128_reclaim_graph_s8':('窗口增训','128/128','是','待逐配置启动日志确认','图','ed48548e8'),
 'isocache_trained_window_2048_reclaim_eager_s8':('窗口增训','2048/128','是','待逐配置启动日志确认','eager','ed48548e8'),
}
# Labels for unstarted configurations intentionally do not assert their runtime layout.
metadata={k:dict(zip(['草稿训练','读窗口','回收','实际分组','模式','代码提交'],v),MRV='MRV2') for k,v in labels.items()}
subprocess.run(['python3',str(root/'collect_startup_audits.py')],check=True,cwd=root,capture_output=True,text=True)
runtime_by={}
for audit in json.loads((root/'startup_audits.json').read_text()):
 job=audit['start'].get('job',{});config=job.get('name')
 if config not in metadata or not audit['layouts']:continue
 layout=audit['layouts'][-1];groups=layout['groups']
 descriptions=[]
 for group in groups:
  kind='SWA' if 'SlidingWindow' in group['spec'] else 'GDN' if all('.linear_attn' in layer for layer in group['layers']) else group['spec']
  descriptions.append((kind,len(group['layers'])))
 counts=Counter(descriptions)
 text=' + '.join(f'{kind} {layers}层×{count}组' for (kind,layers),count in counts.items())
 pages=sorted({page for group in groups for page in group['pages']})
 slot=max(sum(group['pages']) for group in groups)
 info={'实际分组':text,'共享槽字节':slot,'每层page字节':str(pages),'scheduler块大小':str(sorted({group['block_size'] for group in groups})),'启动池块数':layout['num_blocks'],'分组日志':audit['log']}
 runtime_by[(config,job['round'])]=info
 metadata[config].update({key:value for key,value in info.items() if key not in ['启动池块数','分组日志']})
for config,meta in metadata.items():
 meta['草稿模型']='export_B_agent_nowindow_step50' if config.startswith('isocache_trained_full_') else 'export_A_agent_ctxwin2048_step50'
 meta['代码提交']='4a01608da7be1950eebc9902e3692d257f304759' if meta['代码提交']=='4a01608da' else 'ed48548e885aa37126e497c102124184385c636a'
(root/'report'/'configuration_labels.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
out=root/'report';out.mkdir(exist_ok=True)
for kind in ['business','performance']:
 rows=[]
 for wave in a['waves']:
  if wave['kind']!=kind:continue
  row=dict(配置=wave['config'],**metadata[wave['config']],轮次=wave['round'],任务=wave['task'],输入集=wave['dataset'],并发=wave['concurrency'],有效题数=wave['valid'],失败数=wave['failures'],draft步骤=wave['counters']['num_spec_steps'],draft提案=wave['counters']['num_draft_tokens'],accepted=wave['counters']['num_accepted_draft_tokens'],接受率=wave['acceptance'],平均接受长度=wave['mean_acceptance_length'],输入token均值=wave['mean_prompt_tokens'],输出token均值=wave['mean_output_tokens'],TTFT秒=wave['mean_ttft_seconds'],TPOT毫秒=1000*wave['weighted_tpot_stream_end_seconds'],整波输出token每秒=wave['wave_output_tokens_per_second'],抢占次数=wave['server_metric_deltas']['vllm:num_preemptions_total'],平均排队秒=wave['queue_seconds_mean'],原始结果=wave['path'])
  assert (wave['config'],wave['round']) in runtime_by,(wave['config'],wave['round'])
  row.update(runtime_by[(wave['config'],wave['round'])])
  if kind=='business':
   b=json.loads(Path(wave['path']).with_suffix('.business.json').read_text())['summary']
   row.update({k:b.get(k) for k in ['valid_json_arguments','argument_schema_valid','reference_function_and_skill_match','reference_arguments_exact_match','reference_text_exact_match','final_has_tool_calls','truncated']})
  rows.append(row)
 if rows:
  with (out/f'{kind}_rounds.csv').open('w',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
comparisons=[]
perf=[w for w in a['waves'] if w['kind']=='performance']
by={(w['config'],w['dataset'],w['concurrency'],w['round']):w for w in perf}
contrasts=[('裁读','isocache_trained_window_none_full_graph_s8','isocache_trained_window_2048_readonly_graph_s8'),('加入回收及size8布局','isocache_trained_window_2048_readonly_graph_s8','isocache_trained_window_2048_reclaim_graph_s8'),('加入回收及size16布局','isocache_trained_window_2048_readonly_graph_s8','isocache_trained_window_2048_reclaim_graph_s16'),('size16改size8','isocache_trained_window_2048_reclaim_graph_s16','isocache_trained_window_2048_reclaim_graph_s8')]
for label,before,after in contrasts:
 for dataset in ['agent_13k','long_24576','long_29696']:
  for c in [1,4]:
   samples=[]
   for r in [1,2,3]:
    b=by.get((before,dataset,c,r));d=by.get((after,dataset,c,r))
    if b is None or d is None:continue
    samples.append(dict(round=r,**{metric:(d[metric]/b[metric]-1)*100 for metric in ['mean_ttft_seconds','weighted_tpot_stream_end_seconds','wave_output_tokens_per_second']}))
   if samples:comparisons.append(dict(contrast=label,before=before,after=after,dataset=dataset,concurrency=c,rounds=samples,summary={m:dict(mean=statistics.mean(s[m] for s in samples),minimum=min(s[m] for s in samples),maximum=max(s[m] for s in samples)) for m in samples[0] if m!='round'}))
(out/'performance_relative_changes.json').write_text(json.dumps(comparisons,ensure_ascii=False,indent=2))
print('EXPORTED',len(paths),'business task waves;',len(perf),'performance waves; results may still be incomplete')
