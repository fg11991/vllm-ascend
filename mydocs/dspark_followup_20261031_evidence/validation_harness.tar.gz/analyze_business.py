import json,sys
import jsonschema
from pathlib import Path
root=Path(__file__).parent

def tool_signature(calls):
    result=[]
    for call in calls:
        fn=call.get('function',{})
        args=fn.get('arguments','')
        if isinstance(args,str):args=json.loads(args)
        result.append({'name':fn.get('name'),'arguments':args})
    return result

def analyze(path):
    rows=[json.loads(x) for x in path.read_text().splitlines()]
    meta=rows.pop(0)['__payload__'];task=meta['eval_target']
    source=[json.loads(x) for x in Path(meta['dataset']).read_text().splitlines()]
    detail=[]
    for row in rows:
        item=next(x for x in source if row['req_id'].startswith(x['session_id']+'_'))
        record={'id':row['req_id'],'error':row.get('error'),'finish_reason':row.get('finish_reason'),'output_tokens':row.get('completion_tokens')}
        if task=='tool_call':
            calls={}
            for delta in row.get('tool_call_deltas',[]):
                for call in delta:
                    acc=calls.setdefault(call['index'],{'function':{'name':'','arguments':''}})['function']
                    for key in ['name','arguments']:acc[key]+=call.get('function',{}).get(key) or ''
            ordered=[calls[i] for i in sorted(calls)]
            record['tool_calls']=ordered
            try:
                actual=tool_signature(ordered)
                record['valid_json_arguments']=bool(actual)
                allowed={x['function']['name'] for x in item['tools']}
                record['declared_tool_names']=bool(actual) and all(x['name'] in allowed for x in actual)
                ref=item.get('reference_answer',[])
                if isinstance(ref,str):ref=json.loads(ref)
                expected=tool_signature(ref)
                record['reference_function_names_match']=[x['name'] for x in actual]==[x['name'] for x in expected]
                record['reference_arguments_exact_match']=actual==expected
                schemas={t['function']['name']:t['function']['parameters'] for t in item['tools']}
                errors=[]
                for call in actual:
                    if call['name'] in schemas:
                        errors += [e.message for e in jsonschema.Draft202012Validator(schemas[call['name']]).iter_errors(call['arguments'])]
                    else:errors.append('undeclared function')
                record['argument_schema_valid']=bool(actual) and not errors
                record['schema_errors']=errors
                def route(calls):
                    return [(c['name'],c['arguments'].get('name') if c['name']=='Skill' else None) for c in calls]
                record['reference_function_and_skill_match']=route(actual)==route(expected)
            except (ValueError,TypeError,KeyError) as e:
                record['parse_error']=str(e)
        else:
            calls={}
            for delta in row.get('tool_call_deltas',[]):
                for call in delta:
                    acc=calls.setdefault(call['index'],{'function':{'name':'','arguments':''}})['function']
                    for key in ['name','arguments']:acc[key]+=call.get('function',{}).get(key) or ''
            record['final_tool_calls']=[calls[i] for i in sorted(calls)]
            record['final_has_tool_calls']=bool(calls)
            record['recorded_text_semantics']='Flattened reasoning/content/tool-call fields from original benchmark; not pure response.content.'
            text=row.get('prefill_token','')+''.join(row.get('decode_raw_texts',[]))
            record['text']=text;record['reference']=item.get('reference_answer','')
            record['reference_text_exact_match']=text.strip()==record['reference'].strip()
        detail.append(record)
    summary={'path':str(path),'task':task,'requests':len(detail),'failures':sum(bool(x.get('error')) for x in detail),'truncated':sum(x.get('finish_reason')=='length' for x in detail)}
    for key in ['valid_json_arguments','declared_tool_names','reference_function_names_match','reference_arguments_exact_match','reference_text_exact_match','argument_schema_valid','reference_function_and_skill_match','final_has_tool_calls']:
        if any(key in x for x in detail):summary[key]=sum(bool(x.get(key)) for x in detail)
    path.with_suffix('.business.json').write_text(json.dumps({'summary':summary,'requests':detail},ensure_ascii=False,indent=2))
    print(json.dumps(summary,ensure_ascii=False))
for arg in sys.argv[1:]:analyze(Path(arg))
