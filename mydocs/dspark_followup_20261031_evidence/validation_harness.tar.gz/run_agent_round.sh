#!/usr/bin/env bash
set -euo pipefail
root=/workspace/dspark_ctxwin_validation/round_20261031_isolated
tag="$1"
kind="${2:-formal}"
cd "$root/benchmark"
mkdir -p "$root/results"
for task in tool_call final_answer; do
  dataset="$root/testsets_300/${task}_eval/agent_top300.jsonl"
  output=1024
  if [ "$kind" = warm ]; then dataset="$root/warm_${task}.jsonl"; output=64; fi
  python3 -u agent_benchmark.py --ip 127.0.0.1 --port 8873 \
    --tokenizer_path /opt/models/Qwen3.8-27B --dataset "$dataset" \
    --model dspark-trained-followup --eval_target "$task" \
    --concurrency 4 --spec_step_num 7 --max_tokens "$output" \
    --temperature 0 --top_p 1 --request_timeout 900 --metrics-settle-seconds 12 \
    --output_file "$root/results/${tag}_${task}.jsonl" \
    2>&1 | tee "/opt/w00958190/log/dspark_20261031_${tag}_${task}.log"
  python3 "$root/check_agent.py" "$tag" "$task" "$kind"
done
