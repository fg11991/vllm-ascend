"""Collect actual layouts/import/cache paths from healthy official service startups."""
from pathlib import Path
import json,hashlib
root=Path(__file__).parent;healthy=[]
for filename in ['matrix_progress.jsonl','diagnostic_progress.jsonl']:
 p=root/filename
 if not p.exists():continue
 pending=None
 for line in p.read_text().splitlines():
  try:r=json.loads(line)
  except ValueError:continue
  if r['event']=='starting':pending=r
  elif r['event']=='healthy' and pending:
   if 'job' in pending:log=pending['log'];tag=Path(log).name.removeprefix('dspark_20261031_').removesuffix('_serve.log')
   else:tag=pending['tag'];log=f'/opt/w00958190/log/dspark_20261031_{tag}_serve.log'
   healthy.append(dict(tag=tag,log=log,start=pending,healthy_time=r['time']))
   pending=None
records=[]
for r in healthy:
 p=Path(r['log']);layouts=[];workers=[];args=[];backend=[]
 for line in p.read_text(errors='replace').splitlines():
  for marker,target in [('FOLLOWUP_STARTUP_CACHE_AUDIT ',layouts),('FOLLOWUP_WORKER_CACHE_AUDIT ',workers)]:
   if marker in line:target.append(json.loads(line.split(marker,1)[1]))
  if 'non-default args:' in line:args.append(line.strip())
  if 'FA4' in line or 'context window' in line.lower() or 'Mean acceptance' in line: 
   if 'Mean acceptance' not in line:backend.append(line.strip())
 records.append(dict(**r,layouts=layouts,worker_cache_audits=workers,argument_log_lines=args,backend_log_lines=backend))
(root/'startup_audits.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print('HEALTHY_STARTUPS_AUDITED',len(records))
