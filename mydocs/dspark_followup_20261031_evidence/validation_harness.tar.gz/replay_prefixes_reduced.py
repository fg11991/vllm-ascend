import json,sys,time,requests,concurrent.futures,math
from pathlib import Path
root=Path(__file__).parent;tag=sys.argv[1]
cases=json.loads((root/'divergence_prefixes.json').read_text())
def run(case):
    payload=dict(model='dspark-trained-followup',request_id=f"replay_{tag}_c{concurrency}_r{repeat}_{case['id']}",prompt=case['prefix_tokens'],max_tokens=8,temperature=0,top_p=1,seed=42,return_token_ids=True,return_tokens_as_token_ids=True,logprobs=5,ignore_eos=True)
    start=time.time();response=requests.post('http://127.0.0.1:8873/v1/completions',json=payload,timeout=900);response.raise_for_status();data=response.json()
    for value in data['choices'][0]['logprobs']['token_logprobs']:assert value is None or math.isfinite(value)
    return dict(case=case['id'],prefix_length=len(case['prefix_tokens']),start=start,end=time.time(),response=data)
for concurrency in [1]:
 for repeat in range(1,3):
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as ex:results=list(ex.map(run,cases))
    p=root/'results'/f'{tag}_prefix_replay_c{concurrency}_r{repeat}.json';assert not p.exists();p.write_text(json.dumps(results,ensure_ascii=False))
    print('REPLAY_DONE',p.name,flush=True)
