import json,subprocess,time
from pathlib import Path
import diagnostic_driver as d
root=Path(__file__).parent
first='diagnostic_isocache_trained_window2048_reclaim_s8_graph'
s=json.loads((root/'results'/f'{first}_ownership_summary.json').read_text());assert s['counts'].get('other',0)==0
assert json.loads((root/'ownership_analysis_selftest.json').read_text())['passed']
d.record('ownership_analysis_fixed',tag=first,terminal_observations=s['counts']['terminal_release'],unexplained=0,note='Original failed analysis and traces preserved; no production change or rerun of completed trajectories.')
d.record('completed',tag=first)
configs=[dict(tag='diagnostic_isocache_trained_window2048_samegroups_full_s8_graph',blocks=5616,diagnostics='pool,trace,keepfull'),dict(tag='diagnostic_isocache_trained_window2048_readonly_baseline_graph',variant='baseline')]
try:
 for c in configs:
  tag=c['tag'];d.start(**c)
  d.run(str(root/'run_agent_round.sh'),tag+'_warm','warm')
  d.run('python3','flush_trace.py')
  d.run('python3','replay_prefixes_reduced.py',tag)
  d.run('python3','flush_trace.py')
  d.run('python3','analyze_prefix_trace_reduced.py',tag)
  d.run('python3','archive_token_bench_reduced.py',tag,flush=True)
  d.run('python3','business_fixed_token_bench_reduced.py',tag,flush=True)
  d.analyze(tag)
  if 'samegroups_full_s8' in tag:
   a=json.loads((root/'results'/f'{first}_pool_summary.json').read_text())['config'];b=json.loads((root/'results'/f'{tag}_pool_summary.json').read_text())['config']
   assert a['groups']==b['groups'] and a['num_blocks']==b['num_blocks']
   d.record('identical_group_layout_verified',tag=tag,num_blocks=a['num_blocks'])
  d.record('completed',tag=tag)
 d.record('diagnostic_matrix_complete',scope='user_reduced_20261031')
except BaseException as e:
 d.record('resume_failed',error=repr(e));raise
subprocess.run(['python3','-u','boundary_driver.py'],cwd=root,check=True)
