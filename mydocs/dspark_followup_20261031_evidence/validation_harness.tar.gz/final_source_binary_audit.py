import json,hashlib,subprocess,time
from pathlib import Path
root=Path(__file__).parent
initial=json.loads((root/'binary_dependencies_initial.json').read_text());final=json.loads(json.dumps(initial));final['time']=time.time();changes=[]
for item in final['roots']:
 if 'commit' in item:
  base=item['root'];commit=subprocess.check_output(['git','-C',base,'rev-parse','HEAD'],text=True).strip();status=subprocess.check_output(['git','-C',base,'status','--porcelain'],text=True)
  if commit!=item['commit'] or status!=item['status']:changes.append(dict(root=base,commit=commit,status=status))
  item['commit']=commit;item['status']=status
 for b in item['binaries']:
  p=Path(b['path']);digest=hashlib.sha256(p.read_bytes()).hexdigest()
  if digest!=b['sha256']:changes.append(dict(path=str(p),old=b['sha256'],new=digest))
  b.update(realpath=str(p.resolve()),size=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns,sha256=digest)
final['changes_since_initial']=changes;(root/'binary_dependencies_final.json').write_text(json.dumps(final,indent=2));assert not changes,changes
expected=json.loads((root/'source_expected_git_blobs.json').read_text());source={}
initial_source=json.loads((root/'source_audit.json').read_text())
allowed={x['path']:x['actual'] for x in initial_source['4a01608da']['mismatches']}
for commit,d in expected.items():
 diffs=[]
 for path,blob in d['files'].items():
  content=(Path(d['root'])/path).read_bytes();actual=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
  if actual!=blob:
   sha=hashlib.sha256(content).hexdigest();assert commit.startswith('4a01608da') and allowed.get(path)==sha,(commit,path,sha)
   diffs.append(dict(path=path,sha256=sha,classification='unchanged initial startup group logging'))
 source[commit]=dict(root=d['root'],files=len(d['files']),differences=diffs)
source['upstream_vllm']=dict(commit=subprocess.check_output(['git','-C','/vllm-workspace/vllm','rev-parse','HEAD'],text=True).strip(),status=subprocess.check_output(['git','-C','/vllm-workspace/vllm','status','--porcelain'],text=True))
assert source['upstream_vllm']==dict(commit='ced6857afa0ea7b2e3f0846a62e1394e90f15607',status='')
(root/'source_audit_final.json').write_text(json.dumps(dict(time=time.time(),sources=source),indent=2))
print('SOURCE_AND_BINARY_FINAL_AUDIT_PASS')
