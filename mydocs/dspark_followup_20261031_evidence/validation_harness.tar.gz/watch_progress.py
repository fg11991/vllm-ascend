"""Read-only compact monitoring; never sends model requests."""
from pathlib import Path
import json,time
root=Path(__file__).parent
seen=set();offset={}
for p in (root/'results').glob('*.summary.json'):seen.add(str(p))
for name in ['matrix_progress.jsonl','diagnostic_progress.jsonl']:
 p=root/name;offset[name]=len(p.read_text().splitlines()) if p.exists() else 0
print('WATCH_READY',time.strftime('%H:%M:%S',time.gmtime()),flush=True)
while True:
 for name in ['matrix_progress.jsonl','diagnostic_progress.jsonl']:
  p=root/name
  if not p.exists():continue
  lines=p.read_text().splitlines()
  for line in lines[offset[name]:]:
   try:e=json.loads(line)
   except ValueError:continue
   print('PHASE',json.dumps(e),flush=True)
  offset[name]=len(lines)
 for p in sorted((root/'results').glob('*.summary.json')):
  if str(p) in seen:continue
  try:x=json.loads(p.read_text())
  except ValueError:continue
  seen.add(str(p))
  if '_warm_' in p.name:continue
  print('WAVE',json.dumps(dict(file=p.name,valid=x['valid'],failures=x['failures'],acceptance=round(x['acceptance'],6),accepted_length=round(x['mean_acceptance_length'],6),ttft=round(x['mean_ttft_seconds'],4),tpot_ms=round(1000*x['weighted_tpot_stream_end_seconds'],4),wave_tps=round(x['wave_output_tokens_per_second'],3))),flush=True)
 time.sleep(5)
