import requests,json,time
payload=dict(model='dspark-trained-followup',request_id='followup_flush_trace_'+str(time.time_ns()),prompt=[248044,100],max_tokens=8,temperature=0,top_p=1,seed=42,ignore_eos=True,return_token_ids=True)
r=requests.post('http://127.0.0.1:8873/v1/completions',json=payload,timeout=180);r.raise_for_status();print('FLUSH_REQUEST',r.json()['id'])
