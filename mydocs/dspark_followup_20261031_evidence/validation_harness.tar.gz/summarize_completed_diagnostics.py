from pathlib import Path
import json
root=Path(__file__).parent;tags=['diagnostic_isocache_trained_window2048_readonly_baseline_graph','diagnostic_isocache_trained_window2048_reclaim_s8_graph','diagnostic_isocache_trained_window2048_samegroups_full_s8_graph'];out=[]
for tag in tags:
 get=lambda suffix:json.loads((root/'results'/f'{tag}_{suffix}.json').read_text())
 pool=get('pool_summary');mapping=get('map_summary');ownership=get('ownership_summary');prefix=get('prefix_trace_audit')
 assert not pool['violations'] and not mapping['violations'] and not ownership['counts'].get('other',0)
 assert len(prefix['rows'])==12 and all(r['complete_prefix_coverage'] and not r['input_mismatches'] and len(r['first_target_decisions'])==1 for r in prefix['rows'])
 row=dict(tag=tag,num_blocks=pool['config']['num_blocks'],groups=pool['config']['groups'],slot_bytes=max(sum(g['pages']) for g in pool['config']['groups']),released_by_window=pool['released_by_window'],window_reuses_with_old_continuing=pool['window_reuses_with_old_continuing'],pool_violations=pool['violations'],map_stats=mapping['stats'],map_violations=mapping['violations'],ownership_counts=ownership['counts'],prefix_checks=12,prefix_mismatches=0,last_free=pool['last_pool_count']['free'],max_inflight=pool['max_inflight'])
 out.append(row)
 print(tag,'released',row['released_by_window'],'reused with continuation',row['window_reuses_with_old_continuing'],'terminal CPU observations',row['ownership_counts'].get('terminal_release',0))
(root/'results/diagnostic_overview.json').write_text(json.dumps(out,indent=2))
rows=[]
for p in sorted((root/'results').glob('trace_compare_*.json')):
 d=json.loads(p.read_text())
 for r in d['requests']:
  if r['equal']:continue
  a=[x for x in r['target_a'] if x.get('row_is_sampled') and x.get('sampled_at_position')==r['token_a']]
  b=[x for x in r['target_b'] if x.get('row_is_sampled') and x.get('sampled_at_position')==r['token_b']]
  assert len(a)==len(b)==1,(p.name,r['id'],len(a),len(b))
  aa,bb=a[0],b[0]
  rows.append(dict(file=p.name,configuration_a=d['a'],configuration_b=d['b'],repeat_a=d['repeat_a'],repeat_b=d['repeat_b'],input=r['id'],prompt_tokens=r['prompt_tokens'],output_first_divergence_zero_based=r['lcp'],client_token_a=r['token_a'],client_token_b=r['token_b'],target_top_ids_a=aa['top_ids'],target_top_ids_b=bb['top_ids'],target_top_logits_a=aa['top_logits'],target_top_logits_b=bb['top_logits'],target_shape_a=[aa['mode'],aa['tokens'],aa['padded_tokens'],aa['requests_in_batch']],target_shape_b=[bb['mode'],bb['tokens'],bb['padded_tokens'],bb['requests_in_batch']],actual_target_input_equal=aa['target_inputs']==bb['target_inputs'],previous_accepted_equal=aa.get('mamba_previous_accepted')==bb.get('mamba_previous_accepted'),window_start_a=aa['window_start'],window_start_b=bb['window_start'],earlier_draft_change=r['earliest_proposal_difference_no_later_than_output_divergence']))
(root/'results/incremental_divergence_case_summary.json').write_text(json.dumps(rows,indent=2));print('Verified incremental cases',len(rows))
