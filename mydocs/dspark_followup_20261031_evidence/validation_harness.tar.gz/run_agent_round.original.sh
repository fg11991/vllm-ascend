#!/bin/bash
set -eu
T=/opt/w00958190/specforge_tmp
ROUND=$1
cd "$T/dspark_repository/Magistral_Eagle3_Project/benchmark"
until grep -aq 'HTTP_STATUS=' "$T/logs/probe_final_answer_${ROUND}.log"; do sleep 10; done
for TARGET in tool_call final_answer; do
  if [ "$TARGET" = final_answer ] && ! grep -aq 'PROBE_EXIT=0' "$T/logs/probe_final_answer_${ROUND}.log"; then
    echo "FINAL_ANSWER_BLOCKED: 原始请求未通过；保留数据等待排查。"
    continue
  fi
  LOG="$T/logs/bench_${ROUND}_${TARGET}.log"
  PREFIX="$T/logs/bench_${ROUND}_${TARGET}"
  date -Is
  (
    set -x
    python3 -u agent_benchmark.py \
      --ip 127.0.0.1 --port 8861 \
      --tokenizer_path /opt/models/Qwen3.8-27B \
      --dataset "$T/testsets_300/${TARGET}_eval/agent_top300.jsonl" \
      --model qwen3.8-27b-bare --eval_target "$TARGET" \
      --concurrency 4 --spec_step_num 7 --max_tokens 1024 \
      --temperature 0 --top_p 1 --output_file "${PREFIX}.jsonl"
  ) > "$LOG" 2>&1
  python3 - "$PREFIX" <<'VALIDATE'
import glob, json, sys
paths = sorted(glob.glob(sys.argv[1] + "_*.jsonl"))
assert len(paths) == 1, paths
path = paths[0]
rows = [json.loads(line) for line in open(path) if line.strip()]
meta = next(row["__payload__"] for row in rows if row.get("__type__") == "meta")
results = [row for row in rows if row.get("__type__") != "meta"]
valid = [row for row in results if isinstance(row.get("completion_tokens"), int) and row["completion_tokens"] > 0 and row.get("prefill_latency", 0) > 0]
assert len(results) == len(valid) == meta["task_count"] == 50, (len(results), len(valid), meta["task_count"], path)
assert len({row["req_id"] for row in results}) == 50
delta = meta.get("server_spec_metrics_delta")
assert delta and delta["num_spec_steps"] > 0 and delta["num_draft_tokens"] > 0, delta
print("VALIDATION_OK", path, "valid=50", json.dumps(delta))
VALIDATE
  cat "$LOG"
  echo "BENCH_DONE=$ROUND/$TARGET"
done
echo "ROUND_DONE=$ROUND"
