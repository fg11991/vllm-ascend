"""Check captured effective reads and absolute writes, excluding padded columns."""
import json,sys,collections
from pathlib import Path
root=Path(__file__).parent;tag=sys.argv[1];window=int(sys.argv[2]);align=128;B=7;maxlen=32768
paths=sorted(Path('/opt/w00958190/log').glob(f'dspark_20261031_diag_{tag}_*.jsonl'))
config=None
for p in paths:
 for line in p.open():
  e=json.loads(line)
  if e['kind']=='config':config=e;break
 if config:break
assert config is not None
stats=collections.Counter();bad=[];starts=collections.defaultdict(list);samples=[]
def check(ok,kind,**details):
 stats[kind+'_checks']+=1
 if not ok:
  stats[kind+'_failures']+=1
  if len(bad)<100:bad.append(dict(kind=kind,**details))
for path in paths:
 for line in path.open():
  e=json.loads(line)
  if e['kind']!='draft' or 'starts' not in e:continue
  stats['draft_records']+=1
  for i,rid in enumerate(e['requests']):
   q0,q1=e['query_start_loc'][i:i+2];valid_end=q1-e['rejected'][i]
   # No accepted context is possible only for a degenerate/dummy step; retain evidence.
   if valid_end<=q0:stats['empty_valid_context']+=1;continue
   real_anchor=e['target_positions'][valid_end-1]+1
   seq=e['seq_lens'][i];start=e['starts'][i];length=e['window_lengths'][i]
   expected_seq=min(real_anchor+B,maxlen);expected_start=max(expected_seq-B-window,0)//align*align
   check(seq==expected_seq,'seq_len',request=rid,step=e['step'],actual=seq,expected=expected_seq)
   check(start==expected_start and length==seq-start,'window_formula',request=rid,step=e['step'],start=start,length=length,expected_start=expected_start,seq=seq)
   starts[(e['pid'],rid)].append(start)
   stats['rejected_tokens']+=e['rejected'][i]
   stats['prefill_steps']+=bool(e['prefill'][i]);stats['length_clamp_steps']+=real_anchor+B>maxlen
   for gi,gid in enumerate(e['window_tables']):
    kb=e['kernel_blocks'][gid];physical_size=config['groups'][int(gid)]['block_size'];ratio=physical_size//kb
    full=e['full_tables'][gid][i];n=(length+kb-1)//kb;view=e['window_tables'][gid][i][:n]
    check(view==full[start//kb:start//kb+n],'rebase',request=rid,step=e['step'],group=gid)
    check(all(b//ratio!=config['null_id'] for b in view),'read_resident',request=rid,step=e['step'],group=gid,blocks=view)
    stats['effective_read_columns']+=len(view)
    for j in range(q0,q1):
     slot=e['context_slots'][gi][j];pos=e['context_positions'][j]
     if j>=valid_end:
      check(slot==-1,'rejected_write_mask',request=rid,step=e['step'],slot=slot);continue
     check(pos==e['target_positions'][j],'context_position',request=rid,step=e['step'],pos=pos)
     block=full[min(pos//kb,len(full)-1)]
     check(block//ratio!=0 and slot==block*kb+pos%kb,'context_write_resident',request=rid,step=e['step'],pos=pos,slot=slot,block=block)
     stats['context_writes']+=1
    for j in range(B):
     actual_pos=e['draft_positions'][i*B+j];true_pos=real_anchor+j;slot=e['query_slots'][gid][i*B+j]
     check(actual_pos==min(true_pos,maxlen-1),'query_position',request=rid,step=e['step'],pos=actual_pos,true_pos=true_pos)
     block=full[min(true_pos//kb,len(full)-1)]
     check(block//ratio!=0 and slot==block*kb+true_pos%kb,'query_write_resident',request=rid,step=e['step'],pos=true_pos,slot=slot,block=block)
     stats['query_writes']+=1
     if true_pos>=maxlen:stats['query_positions_beyond_maxlen']+=1
   if len(samples)<20 and (real_anchor+B>maxlen or e['rejected'][i]>0):samples.append(dict(request=rid,step=e['step'],start=start,anchor=real_anchor,seq=seq,rejected=e['rejected'][i]))
for key,values in starts.items():
 stats['align_crossings']+=sum(a!=b for a,b in zip(values,values[1:]))
 stats['scheduler_block_crossings']+=sum(a//896!=b//896 for a,b in zip(values,values[1:]))
summary=dict(tag=tag,stats=dict(stats),violations=bad,examples=samples,note='Checks captured logical mappings; host timestamps are not hardware completion timestamps. Duplicate TP-rank observations are counted separately. Out-of-maxlen query positions are reported, not treated as new attention semantics.')
(root/'results'/f'{tag}_map_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2));assert stats['draft_records']>0,'trace was not flushed';assert not bad,bad[:3]
