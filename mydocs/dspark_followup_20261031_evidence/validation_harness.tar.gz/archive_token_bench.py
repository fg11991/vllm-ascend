import sys,json,time,requests,concurrent.futures,hashlib,os,subprocess
from pathlib import Path
root=Path(__file__).parent;tag=sys.argv[1]
fixture=root/'archive_token_inputs.json'
if not fixture.exists():
    paths=list((root/'results').glob('isocache_trained_window_2048_readonly_graph_s8_warm1_final_answer_*.jsonl'))
    assert len(paths)==1,paths
    rows=[json.loads(s) for s in paths[0].read_text().splitlines()]
    data=[dict(id=r['req_id'],tokens=r['prompt_token_ids']) for r in rows if r.get('__type__')!='meta']
    assert len(data)==4 and all(x['tokens'] for x in data)
    fixture.write_text(json.dumps(data))
inputs=json.loads(fixture.read_text())
def request(item):
    payload=dict(model='dspark-trained-followup',request_id=f'{tag}_c{concurrency}_r{repeat}_{item["id"]}',prompt=item['tokens'],max_tokens=1024,ignore_eos=True,temperature=0,top_p=1,seed=42,return_token_ids=True,stream=True,stream_options={'include_usage':True})
    start=time.perf_counter();ids=[];chunks=[];usage=None;finish=None
    with requests.post('http://127.0.0.1:8873/v1/completions',json=payload,stream=True,timeout=900) as response:
        response.raise_for_status()
        for line in response.iter_lines(decode_unicode=True):
            if not line.startswith('data:'):continue
            line=line[5:].strip()
            if line=='[DONE]':break
            obj=json.loads(line)
            if obj.get('error'):raise RuntimeError(obj)
            if obj.get('usage'):usage=obj['usage']
            for choice in obj.get('choices',[]):
                new=choice.get('token_ids') or [];ids+=new
                if new:chunks.append([time.perf_counter()-start,len(new)])
                if choice.get('finish_reason'):finish=choice['finish_reason']
    assert usage and len(ids)==usage['completion_tokens']==1024,(usage,len(ids))
    return dict(id=item['id'],sent_request_id=payload['request_id'],server_request_id=obj.get('id'),prompt_tokens=len(item['tokens']),output_ids=ids,events=chunks,seconds=time.perf_counter()-start,usage=usage,finish=finish)
for concurrency in [1,4]:
    for repeat in range(1,4):
        p=root/'results'/f'{tag}_archive_fixed_c{concurrency}_r{repeat}.json'
        assert not p.exists(),p
        start=time.time()
        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as ex:
            rows=list(ex.map(request,inputs))
        p.write_text(json.dumps(dict(concurrency=concurrency,repeat=repeat,start=start,end=time.time(),fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),requests=rows)))
        print('FIXED_DONE',p.name,flush=True)
        if os.environ.get('DSPARK_CLIENT_FLUSH_TRACE')=='1':subprocess.run(['python3',str(root/'flush_trace.py')],check=True)
