import csv,gzip,hashlib,json,shutil,tarfile,time
from pathlib import Path
root=Path(__file__).parent
out=root/'report'/'dspark_followup_20261031_evidence';out.mkdir(exist_ok=True)
for name in ['business_rounds.csv','performance_rounds.csv','configuration_labels.json','performance_descriptive_summary.json','formal_performance_cache_audit_summary.json']:
 shutil.copy2(root/'report'/name,out/name)
rows=[]
for name in ['business_rounds.csv','performance_rounds.csv']:
 for meta in csv.DictReader((root/'report'/name).open()):
  f=Path(meta['原始结果'])
  for line in f.open():
   d=json.loads(line)
   if '__type__' in d:continue
   keep={k:v for k,v in d.items() if k not in ['req_js','prompt_token_ids','decode_raw_latency','token_events']}
   keep['configuration']=meta['配置'];keep['round']=meta['轮次'];keep['task']=meta['任务'];keep['source']=str(f)
   keep['prompt_token_ids_sha256']=hashlib.sha256(json.dumps(d.get('prompt_token_ids'),separators=(',',':')).encode()).hexdigest()
   rows.append(keep)
assert len(rows)==620,len(rows)
with gzip.open(out/'formal_per_request_results.jsonl.gz','wt') as f:
 for row in rows:f.write(json.dumps(row,ensure_ascii=False)+'\n')
for name in ['diagnostic_overview.json','incremental_divergence_case_summary.json','boundary_poolonly_outcome.json','memory32_comparison.json','memory32_token_comparisons.json']:
 p=root/'results'/name
 if p.exists():shutil.copy2(p,out/name)
for name in ['scope_reduction.json','coverage_inventory.json','source_audit.json','source_audit_final.json','models_final_audit.json','startup_audits.json','binary_dependencies_initial.json','binary_dependencies_final.json','retained_service_health.json','retained_service_audit.json','device_health_after_exception.json','clock_observation.json','memory32_token_comparisons.json','ownership_analysis_selftest.json','prefix_mixed_trace_selftest.json','trace_request_match_selftest.json']:
 p=root/name
 if p.exists():shutil.copy2(p,out/name)
# Raw results remain remote; the manifest makes every referenced artifact verifiable.
paths=sorted(p for p in (root/'results').iterdir() if p.is_file())
manifest=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths]
(out/'remote_results_sha256.json').write_text(json.dumps(manifest,indent=2))
with tarfile.open(out/'validation_harness.tar.gz','w:gz') as tar:
 for p in sorted(root.iterdir()):
  if p.is_file() and p.suffix in ['.py','.sh']:tar.add(p,arcname=p.name)
 for p in sorted((root/'models').glob('*/config.json')):tar.add(p,arcname=str(p.relative_to(root)))
 for p in sorted((root/'failure_20261031_boundary_trace').glob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(root)))
(out/'README.md').write_text('2026-10-31\n\n# 补充实验的便携证据\n\n- 两张CSV分别保留500次业务请求与30个正式性能条件的原始计数、实际配置和日志路径。\n- `formal_per_request_results.jsonl.gz`含620条逐请求结果、输出token IDs与输入token散列；为避免重复存储，完整请求模板与输入IDs仍在远端原始结果。\n- JSON摘要提供分叉、复用、分组和健康检查证据；不存在的待完成项目不会凭空填入。\n- `validation_harness.tar.gz`保留本轮验证脚本、隔离模型配置与首次设备异常日志，不含模型权重、编译缓存或生产环境。\n- `remote_results_sha256.json`列出容器原始结果的完整路径、大小和SHA256。完整设备轨迹位于`/opt/w00958190/log/dspark_20261031_diag_*.jsonl`，不计入正式速度。\n\n所有正式结果根目录为`/workspace/dspark_ctxwin_validation/round_20261031_isolated`。先阅读正文与技术附件的范围和限制；探针检查通过不等于输出严格等价已被证明。\n')
(out/'bundle_manifest.json').write_text(json.dumps(dict(time=time.time(),formal_requests=len(rows),files=[dict(name=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.iterdir()) if p.is_file() and p.name!='bundle_manifest.json']),indent=2))
print('EVIDENCE_BUNDLE',str(out),len(rows))
