import sys,subprocess,json
from pathlib import Path
root=Path(__file__).parent
tag=sys.argv[1];round_id=int(sys.argv[2])
fixture=root/'datasets/agent_13k.jsonl'
if not fixture.exists():
    baseline=list((root/'results').glob('isocache_trained_window_2048_readonly_graph_s8_r1_final_answer_*.jsonl'))
    assert len(baseline)==1,baseline
    rows=[json.loads(x) for x in baseline[0].read_text().splitlines()]
    rows=[x for x in rows if x.get('__type__')!='meta']
    assert len(rows)==50
    selected=sorted(rows,key=lambda x:(abs(x['prompt_tokens']-13000),x['req_id']))[:4]
    source=[json.loads(x) for x in (root/'testsets_300/final_answer_eval/agent_top300.jsonl').read_text().splitlines()]
    chosen=[]
    for item in selected:
        chosen.append(next(x for x in source if x['session_id']+'_final'==item['req_id']))
    fixture.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in chosen)+'\n')
    (root/'datasets/agent_13k_selection.json').write_text(json.dumps([{'id':x['req_id'],'prompt_tokens':x['prompt_tokens']} for x in selected],indent=2))
conditions=[(label,c) for label in ['agent_13k','long_24576','long_29696'] for c in [1,4]]
shift=(round_id-1)*2; conditions=conditions[shift:]+conditions[:shift]
if round_id%2==0:conditions.reverse()
for label,c in conditions:
    name=f'{tag}_perf_r{round_id}_{label}_c{c}'
    cmd=['python3','-u',str(root/'benchmark/agent_benchmark.py'),'--ip','127.0.0.1','--port','8873','--tokenizer_path','/opt/models/Qwen3.8-27B','--dataset',str(root/'datasets'/f'{label}.jsonl'),'--model','dspark-trained-followup','--eval_target','final_answer','--concurrency',str(c),'--spec_step_num','7','--max_tokens','512','--force-output-tokens','512','--temperature','0','--top_p','1','--request_timeout','900','--metrics-settle-seconds','12','--output_file',str(root/'results'/f'{name}_final_answer.jsonl')]
    log=Path('/opt/w00958190/log')/f'dspark_20261031_{name}.log'
    with log.open('x') as f:
        print('PERF_START',name,flush=True)
        result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
    if result.returncode: raise RuntimeError(f'{name} failed: {log}')
    subprocess.run(['python3',str(root/'check_agent.py'),name,'final_answer','performance'],check=True)
    print('PERF_DONE',name,flush=True)
