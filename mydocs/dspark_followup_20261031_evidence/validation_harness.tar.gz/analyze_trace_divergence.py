"""Compare target decisions only where the actual token prefixes are identical."""
import json,sys,re
from pathlib import Path
root=Path(__file__).parent
A,B=sys.argv[1:3];c=int(sys.argv[3]) if len(sys.argv)>3 else 1;ra=int(sys.argv[4]) if len(sys.argv)>4 else 1;rb=int(sys.argv[5]) if len(sys.argv)>5 else 2
fixture_kind=sys.argv[6] if len(sys.argv)>6 else 'archive'
assert fixture_kind in ['archive','business']
fixture={x['id']:x['tokens'] for x in json.loads((root/f'{fixture_kind}_token_inputs.json').read_text())}

def load(tag):
 paths=sorted(Path('/opt/w00958190/log').glob(f'dspark_20261031_diag_{tag}_*.jsonl'),key=lambda p:int(p.stem.rsplit('_',1)[1]))
 for p in paths:
  frames={};found=False
  for line in p.open():
   e=json.loads(line);kind=e['kind']
   if kind not in ['target_shape','draft','verify','initial_target']:continue
   found=True;step=e.get('step',e.get('context',{}).get('step'))
   if step is None:continue
   f=frames.setdefault(step,{})
   if kind=='verify':f.setdefault(kind,[]).append(e)
   else:f[kind]=e
  if found:
   ranks={f['target_shape'].get('tp_rank') for f in frames.values() if 'target_shape' in f}
   if ranks=={0}:return str(p),frames
 raise AssertionError('No flushed worker trace '+tag)
pa,fa=load(A);pb,fb=(pa,fa) if A==B else load(B)
ua=json.loads((root/'results'/f'{A}_{fixture_kind}_fixed_c{c}_r{ra}.json').read_text())['requests'];ub=json.loads((root/'results'/f'{B}_{fixture_kind}_fixed_c{c}_r{rb}.json').read_text())['requests']

def rid_match(actual,tag,repeat,item):
 base=f'cmpl-{tag}_c{c}_r{repeat}_{item}'
 return re.fullmatch(re.escape(base)+r'(?:-\d+-[0-9a-f]+)?',actual) is not None

def decisions(frames,tag,repeat,item,tokens,position):
 out=[]
 for step,f in frames.items():
  shape=f.get('target_shape');draft=f.get('draft')
  if not shape or not draft:continue
  for i,rid in enumerate(shape['requests']):
   if not rid_match(rid,tag,repeat,item):continue
   q0,q1=draft['query_start_loc'][i:i+2]
   positions=draft['target_positions'][q0:q1];inputs=draft['target_input_ids'][q0:q1]
   # Ignore hypothetical target rows after an earlier rejected proposal.
   before=[(p,t) for p,t in zip(positions,inputs) if p<position]
   valid_prefix=all(p<len(tokens) and tokens[p]==t for p,t in before)
   if not valid_prefix:continue
   for v in f.get('verify',[]):
    stateidx=shape['idx'][i]
    if stateidx not in v['idx']:continue
    vi=v['idx'].index(stateidx);lo,hi=v['cu'][vi:vi+2]
    for j in range(lo,hi):
     if v['positions'][j]!=position-1:continue
     out.append(dict(step=step,request=rid,position=position,top_ids=v['top_ids'][j],top_logits=v['top_logits'][j],top_margin=v['top_logits'][j][0]-v['top_logits'][j][1],processed_top_ids=v.get('processed_top_ids',[[]]*len(v['positions']))[j],processed_top_logits=v.get('processed_top_logits',[[]]*len(v['positions']))[j],sampled=v['sampled'][vi],num_sampled=v['num_sampled'][vi],sample_offset=j-lo,row_is_sampled=(j-lo)<v['num_sampled'][vi],sampled_at_position=v['sampled'][vi][j-lo] if (j-lo)<v['num_sampled'][vi] else None,draft_inputs=v['draft'][lo:hi],target_input_positions=positions,target_inputs=inputs,mode=shape['mode'],tokens=shape['tokens'],padded_tokens=shape['padded_tokens'],requests_in_batch=len(shape['requests']),mamba_previous_accepted=shape.get('mamba_previous_accepted'),window_start=draft['starts'][i],window_length=draft['window_lengths'][i],window_tables={g:t[i][:(draft['window_lengths'][i]+draft['kernel_blocks'][g]-1)//draft['kernel_blocks'][g]] for g,t in draft['window_tables'].items()},prefix_rows_verified=len(before)))
   v=f.get('initial_target')
   if v:
    for j,p in enumerate(v['positions']):
     if p==position-1 and j==i:
      out.append(dict(step=step,request=rid,position=position,top_ids=v['top_ids'][j],top_logits=v['top_logits'][j],top_margin=v['top_logits'][j][0]-v['top_logits'][j][1],mode=shape['mode'],tokens=shape['tokens'],padded_tokens=shape['padded_tokens'],kind='initial_target',prefix_rows_verified=len(before)))
 return out

def proposals(frames,tag,repeat,item,tokens,max_position):
 out={}
 for step,f in frames.items():
  d=f.get('draft');shape=f.get('target_shape')
  if not d:continue
  for i,rid in enumerate(d['requests']):
   if not rid_match(rid,tag,repeat,item):continue
   # Proposals during an unfinished prefill chunk are not consumed for decode.
   if d['sampled'][i]<=0:continue
   lo,hi=d['query_start_loc'][i:i+2];valid=hi-d['rejected'][i]
   if valid<=lo:continue
   anchor=d['target_positions'][valid-1]+1
   if anchor>=max_position or anchor>=len(tokens):continue
   if d['draft_input_ids'][i*7]!=tokens[anchor]:continue
   if not all(p<len(tokens) and tokens[p]==t for p,t in zip(d['target_positions'][lo:valid],d['target_input_ids'][lo:valid])):continue
   out[anchor]=dict(step=step,anchor=anchor,proposals=d['proposals'][i],rejected=d['rejected'][i],window_start=d['starts'][i],window_length=d['window_lengths'][i],mode=d['mode'],target_padded_tokens=d['target_padded_tokens'])
 return out

rows=[]
for u,v in zip(ua,ub):
 assert u['id']==v['id'];x,y=u['output_ids'],v['output_ids'];lcp=next((i for i,(a,b) in enumerate(zip(x,y)) if a!=b),min(len(x),len(y)))
 item=u['id'];prompt=fixture[item];pos=len(prompt)+lcp
 row=dict(id=item,equal=x==y,prompt_tokens=len(prompt),lcp=lcp,absolute_divergence_position=pos)
 if x!=y:
  tx,ty=prompt+x,prompt+y;assert tx[:pos]==ty[:pos]
  row.update(token_a=x[lcp] if lcp<len(x) else None,token_b=y[lcp] if lcp<len(y) else None,target_a=decisions(fa,A,ra,item,tx,pos),target_b=decisions(fb,B,rb,item,ty,pos))
  p1,p2=proposals(fa,A,ra,item,tx,pos),proposals(fb,B,rb,item,ty,pos)
  common=sorted(p1.keys()&p2.keys());changed=[n for n in common if p1[n]['proposals']!=p2[n]['proposals']]
  row['common_draft_anchors_before_divergence']=len(common)
  differences=[]
  for anchor in changed:
   j=next(j for j,(a,b) in enumerate(zip(p1[anchor]['proposals'],p2[anchor]['proposals'])) if a!=b)
   differences.append(dict(anchor=anchor,proposal_index=j,predicted_position=anchor+1+j,before_or_at_output_divergence=anchor+1+j<=pos,a=p1[anchor],b=p2[anchor]))
  row['earliest_draft_proposal_difference']=differences[0] if differences else None
  relevant=[x for x in differences if x['before_or_at_output_divergence']]
  row['earliest_proposal_difference_no_later_than_output_divergence']=relevant[0] if relevant else None
  row['first_common_draft_anchor']=dict(a=p1[common[0]],b=p2[common[0]]) if common else None
 rows.append(row)
result=dict(a=A,b=B,concurrency=c,repeat_a=ra,repeat_b=rb,trace_a=pa,trace_b=pb,requests=rows,note='Target rows compared only when their current-step input prefix matches the actual common client trajectory. Same-prefix decisions do not alone identify the originating operator.')
path=root/'results'/f'trace_compare_{fixture_kind}_{A}_r{ra}_vs_{B}_r{rb}_c{c}.json';path.write_text(json.dumps(result,indent=2));print(path)
for r in rows:print(r['id'],'LCP',r['lcp'],'target rows',len(r.get('target_a',[])),len(r.get('target_b',[])),'draft common',r.get('common_draft_anchors_before_divergence'))
