"""Separate foreground phase, invoked only after the no-probe matrix finishes."""
import os,json,time,signal,subprocess,requests
from pathlib import Path
root=Path(__file__).parent
assert any(json.loads(x)['event']=='matrix_complete' for x in (root/'matrix_progress.jsonl').read_text().splitlines()),'formal matrix must finish first'
server=None

def record(event,**kw):
 row=dict(event=event,time=time.time(),**kw)
 with (root/'diagnostic_progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 print('DIAGNOSTIC_PROGRESS',json.dumps(row),flush=True)

def stop_owned():
 owned=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:cmd=(p/'cmdline').read_bytes();env=(p/'environ').read_bytes().split(b'\0')
  except OSError:continue
  if b'/workspace/dspark_ctxwin_validation/runtime-' in cmd and b'--served-model-name\0dspark-trained-followup\0' in cmd:
   assert b'ASCEND_RT_VISIBLE_DEVICES=4,5,6,7' in env;owned.append(int(p.name))
 assert len(owned)==1,owned
 pid=owned[0];record('stop_verified_owned_api',pid=pid);os.kill(pid,signal.SIGTERM)
 for i in range(90):
  if not Path('/proc',str(pid)).exists():break
  time.sleep(1)
 else:raise RuntimeError('Owned API did not exit')
 time.sleep(5)

def start(tag,variant='tmp',model='trained-window-2048',mode='full',width=8,diagnostics='pool,trace',blocks=None,maxseq=8):
 global server
 stop_owned()
 env=os.environ.copy();env.update(DSPARK_FOLLOWUP_TAG=tag,DSPARK_FOLLOWUP_DIAGNOSTICS=diagnostics,DSPARK_FOLLOWUP_ENTRY='vllm-followup-diagnostic' if diagnostics else 'vllm',DSPARK_CACHE_TAG=tag)
 if blocks:env['DSPARK_GPU_BLOCKS']=str(blocks)
 else:env.pop('DSPARK_GPU_BLOCKS',None)
 log=Path('/opt/w00958190/log')/f'dspark_20261031_{tag}_serve.log';assert not log.exists()
 server=subprocess.Popen([str(root/'serve.sh'),variant,model,mode,str(width),tag,str(maxseq)],env=env,start_new_session=True)
 record('starting',tag=tag,variant=variant,model=model,mode=mode,width=width,diagnostics=diagnostics,blocks=blocks,maxseq=maxseq,pid=server.pid)
 for _ in range(240):
  if server.poll() is not None:raise RuntimeError(f'server exited: {log}')
  try:
   if requests.get('http://127.0.0.1:8873/health',timeout=3).status_code==200:break
  except requests.RequestException:pass
  time.sleep(5)
 else:raise RuntimeError(f'start timeout: {log}')
 record('healthy',tag=tag)

def run(*args,flush=False):
 env=os.environ.copy()
 if flush:env['DSPARK_CLIENT_FLUSH_TRACE']='1'
 subprocess.run(list(args),cwd=root,env=env,check=True)

def analyze(tag,W=2048,maps=True):
 run('python3','flush_trace.py')
 time.sleep(3)
 run('python3','analyze_pool.py',tag)
 if maps:
  run('python3','analyze_maps.py',tag,str(W))
  run('python3','analyze_ownership.py',tag)

if __name__=='__main__':
 subprocess.run(['python3',str(root/'build_divergence_prefixes.py')],cwd=root,check=True)
 configs=[
  dict(tag='diagnostic_isocache_trained_window2048_reclaim_s8_graph',blocks=5616),
  dict(tag='diagnostic_isocache_trained_window2048_samegroups_full_s8_graph',blocks=5616,diagnostics='pool,trace,keepfull'),
  dict(tag='diagnostic_isocache_trained_window2048_readonly_baseline_graph',variant='baseline'),
 ]
 try:
  for c in configs:
   tag=c['tag'];start(**c)
   run(str(root/'run_agent_round.sh'),tag+'_warm','warm')
   run('python3','flush_trace.py')
   run('python3','replay_prefixes_reduced.py',tag)
   run('python3','flush_trace.py')
   run('python3','analyze_prefix_trace_reduced.py',tag)
   run('python3','archive_token_bench_reduced.py',tag,flush=True)
   run('python3','business_fixed_token_bench_reduced.py',tag,flush=True)
   analyze(tag)
   if 'samegroups_full_s8' in tag:
    a=json.loads((root/'results'/'diagnostic_isocache_trained_window2048_reclaim_s8_graph_pool_summary.json').read_text())['config']
    b=json.loads((root/'results'/f'{tag}_pool_summary.json').read_text())['config']
    assert a['groups']==b['groups'] and a['num_blocks']==b['num_blocks'], 'same-group counterfactual changed actual layout'
    record('identical_group_layout_verified',tag=tag,num_blocks=a['num_blocks'])
   record('completed',tag=tag)
  record('diagnostic_matrix_complete')
 except BaseException as e:
  record('failed',error=repr(e));raise
 print('DIAGNOSTIC_SERVICE_RETAINED',flush=True);server.wait()
