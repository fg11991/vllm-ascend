"""Choose same-prefix replays from this isolated series, never from preliminary results."""
import json,shutil,itertools
from pathlib import Path
root=Path(__file__).parent
fixtures={r['id']:r['tokens'] for r in json.loads((root/'archive_token_inputs.json').read_text())}
chosen={};examined=[]
configs=['isocache_trained_window_2048_readonly_graph_s8','isocache_trained_window_2048_reclaim_graph_s8','isocache_trained_window_2048_reclaim_graph_s16','isocache_trained_window_2048_reclaim_eager_s8']
for config in configs:
 for concurrency in [1,4]:
  for ra,rb in [(1,2),(1,3),(2,3)]:
   pa=root/'results'/f'{config}_archive_fixed_c{concurrency}_r{ra}.json';pb=root/'results'/f'{config}_archive_fixed_c{concurrency}_r{rb}.json'
   if not pa.exists() or not pb.exists():continue
   aa=json.loads(pa.read_text())['requests'];bb=json.loads(pb.read_text())['requests']
   for a,b in zip(aa,bb):
    assert a['id']==b['id'];item=a['id'];x,y=a['output_ids'],b['output_ids'];n=next((i for i,(q,w) in enumerate(zip(x,y)) if q!=w),min(len(x),len(y)))
    if x==y or n==min(len(x),len(y)):continue
    ea=next((i for i,t in enumerate(x) if t in [248044,248046]),None);eb=next((i for i,t in enumerate(y) if t in [248044,248046]),None)
    if any(e is not None and n>e for e in [ea,eb]):continue
    prefix=fixtures[item]+x[:n]
    if len(prefix)+8>32768:continue
    r=dict(id=f'{item}_at_{n}',source_a=pa.stem,source_b=pb.stem,prompt_tokens=len(fixtures[item]),lcp=n,token_a=x[n],token_b=y[n],first_eos_a=ea,first_eos_b=eb,prefix_tokens=prefix)
    examined.append({k:v for k,v in r.items() if k!='prefix_tokens'})
    chosen.setdefault(item,r)
assert len(chosen)>=3,('Need at least 3 pre-EOS divergent input examples',list(chosen))
# A baseline-only first-token fork is useful: no draft proposal has yet
# contributed to that output. Preserve this independent prefill diagnostic.
agent_inputs={r['id']:r['tokens'] for r in json.loads((root/'fixed_token_inputs.json').read_text())}
config=configs[0]
pa=root/'results'/f'{config}_fixed_c1_r1.json';pb=root/'results'/f'{config}_fixed_c1_r2.json'
if pa.exists() and pb.exists():
 for a,b in zip(json.loads(pa.read_text())['requests'],json.loads(pb.read_text())['requests']):
  if a['output_ids'][0]==b['output_ids'][0]:continue
  item=a['id'];prefix=agent_inputs[item]
  chosen['initial_'+item]=dict(id='initial_'+item,source_a=pa.stem,source_b=pb.stem,prompt_tokens=len(prefix),lcp=0,token_a=a['output_ids'][0],token_b=b['output_ids'][0],prefix_tokens=prefix,diagnostic_purpose='First target token before draft candidates are used')
  break
# Include the observed business-level chart expansion/truncation, not only
# unconstrained free-writing examples.
pa=next((root/'results').glob('isocache_trained_window_2048_readonly_graph_s8_r1_final_answer_*.jsonl'))
pb=next((root/'results').glob('isocache_trained_window_2048_reclaim_graph_s8_r1_final_answer_*.jsonl'))
aa={x['req_id']:x for x in map(json.loads,pa.read_text().splitlines()[1:])}
bb={x['req_id']:x for x in map(json.loads,pb.read_text().splitlines()[1:])}
for item,a in aa.items():
 if '1e9955ad-9111-465b-af6d-ea512d07d154' not in item:continue
 b=bb[item];assert a['prompt_token_ids']==b['prompt_token_ids']
 x,y=a['output_token_ids'],b['output_token_ids'];n=next((i for i,(q,w) in enumerate(zip(x,y)) if q!=w),min(len(x),len(y)))
 assert n<min(len(x),len(y))
 prefix=a['prompt_token_ids']+x[:n]
 chosen['business_chart']=dict(id=f'business_chart_at_{n}',source_a=pa.stem,source_b=pb.stem,source_request_id=item,prompt_tokens=len(a['prompt_token_ids']),lcp=n,token_a=x[n],token_b=y[n],prefix_tokens=prefix,diagnostic_purpose='Business response changed from 112-token summary to truncated 1024-token chart JSON')
p=root/'divergence_prefixes.json';backup=root/'divergence_prefixes.preliminary.json'
assert not (root/'official_prefix_selection.json').exists(),'selection already frozen'
if p.exists():shutil.copy2(p,backup)
p.write_text(json.dumps(list(chosen.values()),ensure_ascii=False))
(root/'official_prefix_selection.json').write_text(json.dumps(dict(method='For each input, first pre-EOS self-divergence in ordered config/concurrency/repeat pairs; baseline first, c1 first, pairs (1,2),(1,3),(2,3). At most one archive prefix per unique input, plus the first baseline c1 initial-token divergence and the observed business chart truncation.',selected=[{k:v for k,v in r.items() if k!='prefix_tokens'} for r in chosen.values()],all_eligible=examined),indent=2))
print('OFFICIAL_DIVERGENCE_PREFIXES_FROZEN',[(r['id'],len(r['prefix_tokens'])) for r in chosen.values()],flush=True)
