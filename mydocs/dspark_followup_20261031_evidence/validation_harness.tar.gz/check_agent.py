import json,sys,statistics
from pathlib import Path
root=Path(__file__).parent
paths=list((root/'results').glob(f'{sys.argv[1]}_{sys.argv[2]}_*.jsonl'))
assert len(paths)==1,paths
p=paths[0];rows=[json.loads(x) for x in p.read_text().splitlines()]
meta=rows.pop(0)['__payload__'];expected=50 if sys.argv[3]=='formal' else 4
assert len(rows)==expected,(len(rows),expected)
fail=[r['req_id'] for r in rows if r.get('error') or not r.get('token_count_matches_usage') or not r.get('prompt_token_ids') or not r.get('finish_reason')]
assert not fail,fail
if sys.argv[3]=='performance':
    assert all(r['completion_tokens']==512 for r in rows),[(r['req_id'],r['completion_tokens']) for r in rows]
d=meta['server_spec_metrics_delta']; assert d and d['num_spec_steps']>0,d
summary=dict(path=str(p),task=sys.argv[2],valid=len(rows),failures=len(fail),counters=d,acceptance=d['num_accepted_draft_tokens']/d['num_draft_tokens'],mean_acceptance_length=1+d['num_accepted_draft_tokens']/d['num_spec_steps'],mean_prompt_tokens=statistics.mean(r['prompt_tokens'] for r in rows),mean_output_tokens=statistics.mean(r['completion_tokens'] for r in rows),mean_ttft_seconds=statistics.mean(r['first_token_seconds'] for r in rows),weighted_tpot_stream_end_seconds=sum(r['stream_end_seconds']-r['first_token_seconds'] for r in rows)/sum(r['completion_tokens']-1 for r in rows),wave_seconds=meta['wave_seconds'],wave_output_tokens_per_second=sum(r['completion_tokens'] for r in rows)/meta['wave_seconds'])
p.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2))
print('NEW_SUMMARY',json.dumps(summary))
